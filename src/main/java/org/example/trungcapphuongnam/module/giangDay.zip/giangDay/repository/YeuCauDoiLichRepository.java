package org.example.trungcapphuongnam.module.giangDay.repository;

import org.example.trungcapphuongnam.module.giangDay.entity.YeuCauDoiLich;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface YeuCauDoiLichRepository extends JpaRepository<YeuCauDoiLich, Long>, JpaSpecificationExecutor<YeuCauDoiLich> {
}