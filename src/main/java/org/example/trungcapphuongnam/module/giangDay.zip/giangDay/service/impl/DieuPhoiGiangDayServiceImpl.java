package org.example.trungcapphuongnam.module.giangDay.service.impl;

import lombok.RequiredArgsConstructor;
import org.example.trungcapphuongnam.module.chuongTrinh.entity.SyllabusChuongBai;
import org.example.trungcapphuongnam.module.chuongTrinh.repository.SyllabusChuongBaiRepository;
import org.example.trungcapphuongnam.module.chuongTrinh.repository.SyllabusMonHocRepository;
import org.example.trungcapphuongnam.module.giangDay.GiangDayException;
import org.example.trungcapphuongnam.module.giangDay.dto.request.LichHocRequest;
import org.example.trungcapphuongnam.module.giangDay.dto.request.SinhLichHocRequest;
import org.example.trungcapphuongnam.module.giangDay.dto.request.XepLichHangLoatRequest;
import org.example.trungcapphuongnam.module.giangDay.dto.response.GoiYLichHocResponse;
import org.example.trungcapphuongnam.module.giangDay.dto.response.LichHocPreviewItemResponse;
import org.example.trungcapphuongnam.module.giangDay.dto.response.LichHocResponse;
import org.example.trungcapphuongnam.module.giangDay.dto.response.SinhLichHocPreviewResponse;
import org.example.trungcapphuongnam.module.giangDay.dto.response.XepLichHangLoatItemResponse;
import org.example.trungcapphuongnam.module.giangDay.dto.response.XepLichHangLoatResponse;
import org.example.trungcapphuongnam.module.giangDay.entity.CaHoc;
import org.example.trungcapphuongnam.module.giangDay.entity.GiaoVien;
import org.example.trungcapphuongnam.module.giangDay.entity.LopHocPhan;
import org.example.trungcapphuongnam.module.giangDay.entity.PhongHoc;
import org.example.trungcapphuongnam.module.giangDay.enums.TrangThaiGiaoVien;
import org.example.trungcapphuongnam.module.giangDay.enums.TrangThaiLichHoc;
import org.example.trungcapphuongnam.module.giangDay.enums.TrangThaiLopHocPhan;
import org.example.trungcapphuongnam.module.giangDay.enums.TrangThaiPhongHoc;
import org.example.trungcapphuongnam.module.giangDay.enums.TrangThaiSinhVienLopHocPhan;
import org.example.trungcapphuongnam.module.giangDay.enums.VaiTroGiangDay;
import org.example.trungcapphuongnam.module.giangDay.repository.CaHocRepository;
import org.example.trungcapphuongnam.module.giangDay.repository.GiaoVienKhaDungRepository;
import org.example.trungcapphuongnam.module.giangDay.repository.GiaoVienRepository;
import org.example.trungcapphuongnam.module.giangDay.repository.LichHocRepository;
import org.example.trungcapphuongnam.module.giangDay.repository.LopHocPhanRepository;
import org.example.trungcapphuongnam.module.giangDay.repository.NgayNghiRepository;
import org.example.trungcapphuongnam.module.giangDay.repository.PhanCongGiangDayRepository;
import org.example.trungcapphuongnam.module.giangDay.repository.PhongHocRepository;
import org.example.trungcapphuongnam.module.giangDay.repository.SinhVienLopHocPhanRepository;
import org.example.trungcapphuongnam.module.giangDay.service.DieuPhoiGiangDayService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;

@Service
@RequiredArgsConstructor
public class DieuPhoiGiangDayServiceImpl implements DieuPhoiGiangDayService {

    private static final List<TrangThaiSinhVienLopHocPhan> TRANG_THAI_SINH_VIEN_DANG_HOC = List.of(
            TrangThaiSinhVienLopHocPhan.da_dang_ky,
            TrangThaiSinhVienLopHocPhan.dang_hoc,
            TrangThaiSinhVienLopHocPhan.hoc_lai
    );

    private final LopHocPhanRepository lopHocPhanRepository;
    private final GiaoVienRepository giaoVienRepository;
    private final PhongHocRepository phongHocRepository;
    private final CaHocRepository caHocRepository;
    private final LichHocRepository lichHocRepository;
    private final SinhVienLopHocPhanRepository sinhVienLopHocPhanRepository;
    private final PhanCongGiangDayRepository phanCongGiangDayRepository;
    private final NgayNghiRepository ngayNghiRepository;
    private final GiaoVienKhaDungRepository giaoVienKhaDungRepository;
    private final SyllabusMonHocRepository syllabusMonHocRepository;
    private final SyllabusChuongBaiRepository syllabusChuongBaiRepository;
    private final LichHocTuDongTransactionService lichHocTuDongTransactionService;

    @Override
    @Transactional(readOnly = true)
    public SinhLichHocPreviewResponse previewSinhLich(Long lopHocPhanId, SinhLichHocRequest request) {
        LopHocPhan lop = lopHocPhanRepository.findById(lopHocPhanId)
                .orElseThrow(() -> new GiangDayException("Lớp học phần không tồn tại"));

        validateRequest(lop, request);
        List<Long> caHocIds = layCaHocIds(request);

        int soBuoiCanXep = lop.getSoBuoiHoc();
        int soBuoiDaXep = (int) lichHocRepository.countSoBuoiDangTinh(
                lopHocPhanId,
                TrangThaiLichHoc.nghi,
                null
        );
        int soBuoiConLai = Math.max(soBuoiCanXep - soBuoiDaXep, 0);

        List<LichHocPreviewItemResponse> items = new ArrayList<>();
        List<String> canhBaoTong = new ArrayList<>();

        LocalDate ngay = request.getTuNgay();
        while (!ngay.isAfter(request.getDenNgay()) && items.size() < soBuoiConLai) {
            int thu = tinhThuTrongTuan(ngay);

            if (request.getThuTrongTuan().contains(thu)) {
                for (Long caHocId : caHocIds) {
                    if (items.size() >= soBuoiConLai) {
                        break;
                    }

                    List<String> canhBao = taoCanhBaoSlot(lopHocPhanId, request, ngay, thu, caHocId);

                    if (canhBao.isEmpty()) {
                        int stt = soBuoiDaXep + items.size() + 1;
                        items.add(LichHocPreviewItemResponse.builder()
                                .stt(stt)
                                .ngayHoc(ngay)
                                .caHocId(caHocId)
                                .phongHocId(request.getPhongHocId())
                                .giaoVienId(request.getGiaoVienId())
                                .noiDungBuoiHoc(taoNoiDungBuoiHoc(lop, stt, soBuoiCanXep, request.getTuDongGanNoiDungSyllabus()))
                                .canhBao(List.of())
                                .build());
                    } else {
                        canhBaoTong.add("Ngày " + ngay + " - ca " + caHocId + ": " + String.join(", ", canhBao));
                    }
                }
            }

            ngay = ngay.plusDays(1);
        }

        boolean hopLe = items.size() == soBuoiConLai;
        if (!hopLe) {
            canhBaoTong.add("Không xếp đủ số buổi còn lại trong khoảng ngày đã chọn");
        }

        return SinhLichHocPreviewResponse.builder()
                .hopLe(hopLe)
                .soBuoiCanXep(soBuoiCanXep)
                .soBuoiDaXep(soBuoiDaXep)
                .soBuoiConLai(soBuoiConLai)
                .soBuoiXepDuoc(items.size())
                .canhBao(canhBaoTong)
                .items(items)
                .build();
    }

    @Override
    public List<LichHocResponse> taoLichTuDong(Long lopHocPhanId, SinhLichHocRequest request) {
        SinhLichHocPreviewResponse preview = previewSinhLich(lopHocPhanId, request);
        return lichHocTuDongTransactionService.luuLichTuDongTuPreview(lopHocPhanId, preview);
    }


    @Override
    @Transactional(readOnly = true)
    public List<GoiYLichHocResponse> goiYLichHoc(Long lopHocPhanId, SinhLichHocRequest request) {
        LopHocPhan lop = lopHocPhanRepository.findById(lopHocPhanId)
                .orElseThrow(() -> new GiangDayException("Lớp học phần không tồn tại"));

        validateRequestCoBan(lop, request);

        List<PhongHoc> danhSachPhong = danhSachPhongUngVien(lop, request);
        List<List<Long>> danhSachNhomCa = danhSachNhomCaUngVien(request);

        List<Integer> danhSachThu = request.getThuTrongTuan() == null || request.getThuTrongTuan().isEmpty()
                ? List.of(2, 3, 4, 5, 6, 7)
                : request.getThuTrongTuan();

        int gioiHan = request.getSoPhuongAn() == null || request.getSoPhuongAn() < 1
                ? 5
                : Math.min(request.getSoPhuongAn(), 20);

        List<GoiYLichHocResponse> ketQua = new ArrayList<>();
        for (PhongHoc phong : danhSachPhong) {
            for (List<Long> nhomCaHocIds : danhSachNhomCa) {
                SinhLichHocRequest thuRequest = saoChepRequest(request);
                thuRequest.setPhongHocId(phong.getId());
                thuRequest.setCaHocId(nhomCaHocIds.isEmpty() ? null : nhomCaHocIds.get(0));
                thuRequest.setCaHocIds(new ArrayList<>(nhomCaHocIds));
                thuRequest.setThuTrongTuan(danhSachThu);

                SinhLichHocPreviewResponse preview;
                try {
                    preview = previewSinhLich(lopHocPhanId, thuRequest);
                } catch (RuntimeException ex) {
                    continue;
                }

                int soCanhBao = preview.getCanhBao() == null ? 0 : preview.getCanhBao().size();
                int diemSucChua = phong.getSucChua() == null || lop.getSoLuongHienTai() == null
                        ? 0
                        : Math.max(0, 200 - Math.abs(phong.getSucChua() - lop.getSoLuongHienTai()));
                int diemUuTien = preview.getSoBuoiXepDuoc() * 1000
                        + diemSucChua
                        - soCanhBao * 25;

                ketQua.add(GoiYLichHocResponse.builder()
                        .hopLe(preview.getHopLe())
                        .diemUuTien(diemUuTien)
                        .phongHocId(phong.getId())
                        .caHocId(nhomCaHocIds.isEmpty() ? null : nhomCaHocIds.get(0))
                        .thuTrongTuan(danhSachThu)
                        .soBuoiCanXep(preview.getSoBuoiConLai())
                        .soBuoiXepDuoc(preview.getSoBuoiXepDuoc())
                        .soCanhBao(soCanhBao)
                        .canhBao(preview.getCanhBao())
                        .items(preview.getItems())
                        .build());
            }
        }

        ketQua.sort(Comparator
                .comparing((GoiYLichHocResponse item) -> Boolean.TRUE.equals(item.getHopLe())).reversed()
                .thenComparing(GoiYLichHocResponse::getDiemUuTien, Comparator.reverseOrder())
                .thenComparing(GoiYLichHocResponse::getSoCanhBao)
        );

        List<GoiYLichHocResponse> rutGon = ketQua.stream().limit(gioiHan).toList();
        for (int i = 0; i < rutGon.size(); i++) {
            rutGon.get(i).setThuTuPhuongAn(i + 1);
        }
        return rutGon;
    }

    @Override
    @Transactional(propagation = Propagation.NOT_SUPPORTED)
    public XepLichHangLoatResponse xepLichHangLoat(XepLichHangLoatRequest request) {
        if (request == null || request.getLopHocPhanIds() == null || request.getLopHocPhanIds().isEmpty()) {
            throw new GiangDayException("Phải chọn ít nhất một lớp học phần để xếp hàng loạt");
        }

        boolean chiPreview = !Boolean.FALSE.equals(request.getChiPreview());
        List<XepLichHangLoatItemResponse> items = new ArrayList<>();

        for (Long lopHocPhanId : request.getLopHocPhanIds()) {
            LopHocPhan lop = lopHocPhanRepository.findById(lopHocPhanId).orElse(null);
            if (lop == null) {
                items.add(XepLichHangLoatItemResponse.builder()
                        .lopHocPhanId(lopHocPhanId)
                        .thanhCong(false)
                        .thongBao("Lớp học phần không tồn tại")
                        .build());
                continue;
            }

            try {
                SinhLichHocRequest lopRequest = chuanBiRequestXepHangLoat(lopHocPhanId, lop, request);

                SinhLichHocPreviewResponse preview = previewSinhLich(lopHocPhanId, lopRequest);
                if (!Boolean.TRUE.equals(preview.getHopLe())) {
                    items.add(XepLichHangLoatItemResponse.builder()
                            .lopHocPhanId(lop.getId())
                            .maLop(lop.getMaLop())
                            .tenLop(lop.getTenLop())
                            .thanhCong(false)
                            .thongBao(preview.getCanhBao() == null || preview.getCanhBao().isEmpty()
                                    ? "Không xếp đủ số buổi còn lại"
                                    : String.join("; ", preview.getCanhBao()))
                            .build());
                    continue;
                }

                List<LichHocResponse> lichDaTao = List.of();
                if (!chiPreview) {
                    // Luu theo preview da kiem tra, trong transaction rieng cho tung lop.
                    // Co che nay chi bo sung lich con thieu vao o trong hop le, khong xoa/ghi de lich cu.
                    lichDaTao = lichHocTuDongTransactionService.luuLichTuDongTuPreview(lopHocPhanId, preview);
                }

                items.add(XepLichHangLoatItemResponse.builder()
                        .lopHocPhanId(lop.getId())
                        .maLop(lop.getMaLop())
                        .tenLop(lop.getTenLop())
                        .thanhCong(true)
                        .thongBao(chiPreview
                                ? "Preview hợp lệ: có thể tạo " + preview.getSoBuoiXepDuoc() + " buổi"
                                : "Đã tạo " + lichDaTao.size() + " buổi lịch học")
                        .lichDaTao(lichDaTao)
                        .build());
            } catch (RuntimeException ex) {
                items.add(XepLichHangLoatItemResponse.builder()
                        .lopHocPhanId(lop.getId())
                        .maLop(lop.getMaLop())
                        .tenLop(lop.getTenLop())
                        .thanhCong(false)
                        .thongBao(ex.getMessage() == null ? "Không xếp được lịch cho lớp này" : ex.getMessage())
                        .build());
            }
        }

        int thanhCong = (int) items.stream().filter(item -> Boolean.TRUE.equals(item.getThanhCong())).count();
        return XepLichHangLoatResponse.builder()
                .tongLop(items.size())
                .soLopThanhCong(thanhCong)
                .soLopLoi(items.size() - thanhCong)
                .chiPreview(chiPreview)
                .items(items)
                .build();
    }

    private SinhLichHocRequest chuanBiRequestXepHangLoat(Long lopHocPhanId, LopHocPhan lop, XepLichHangLoatRequest request) {
        SinhLichHocRequest lopRequest = saoChepRequest(request);

        if (lopRequest.getGiaoVienId() == null) {
            phanCongGiangDayRepository.findFirstByLopHocPhanIdAndVaiTro(lopHocPhanId, VaiTroGiangDay.giang_vien_chinh)
                    .ifPresent(phanCong -> lopRequest.setGiaoVienId(phanCong.getGiaoVienId()));
        }

        if (lopRequest.getGiaoVienId() == null) {
            throw new GiangDayException("Lớp học phần chưa có giáo viên chính để xếp tự động");
        }

        validateRequestCoBan(lop, lopRequest);

        boolean thieuPhong = lopRequest.getPhongHocId() == null;
        boolean thieuCa = !coCaHoc(lopRequest);

        if (thieuPhong || thieuCa || Boolean.TRUE.equals(lopRequest.getTuDongChonPhong()) || Boolean.TRUE.equals(lopRequest.getTuDongChonCa())) {
            List<GoiYLichHocResponse> goiY = goiYLichHoc(lopHocPhanId, lopRequest);
            GoiYLichHocResponse phuongAn = goiY.stream()
                    .filter(item -> Boolean.TRUE.equals(item.getHopLe()))
                    .findFirst()
                    .orElse(null);

            if (phuongAn == null) {
                String lyDo = goiY.isEmpty()
                        ? "Không tìm được phòng/ca phù hợp"
                        : (goiY.get(0).getCanhBao() == null || goiY.get(0).getCanhBao().isEmpty()
                        ? "Không tìm được phương án hợp lệ"
                        : String.join("; ", goiY.get(0).getCanhBao()));
                throw new GiangDayException(lyDo);
            }

            if (thieuPhong || Boolean.TRUE.equals(lopRequest.getTuDongChonPhong())) {
                lopRequest.setPhongHocId(phuongAn.getPhongHocId());
            }
            if (thieuCa || Boolean.TRUE.equals(lopRequest.getTuDongChonCa())) {
                Long caHocId = phuongAn.getCaHocId();
                lopRequest.setCaHocId(caHocId);
                lopRequest.setCaHocIds(caHocId == null ? null : List.of(caHocId));
            }
        }

        return lopRequest;
    }

    private boolean coCaHoc(SinhLichHocRequest request) {
        return (request.getCaHocIds() != null && request.getCaHocIds().stream().anyMatch(java.util.Objects::nonNull))
                || request.getCaHocId() != null;
    }

    private List<PhongHoc> danhSachPhongUngVien(LopHocPhan lop, SinhLichHocRequest request) {
        if (request.getPhongHocId() != null) {
            PhongHoc phong = phongHocRepository.findById(request.getPhongHocId())
                    .orElseThrow(() -> new GiangDayException("Phòng học không tồn tại"));
            if (phong.getTrangThai() != TrangThaiPhongHoc.dang_su_dung) {
                throw new GiangDayException("Chỉ phòng học đang sử dụng mới được xếp lịch");
            }
            if (phong.getSucChua() != null
                    && lop.getSoLuongHienTai() != null
                    && phong.getSucChua() < lop.getSoLuongHienTai()) {
                throw new GiangDayException("Phòng học không đủ sức chứa");
            }
            return List.of(phong);
        }

        return phongHocRepository.findAll().stream()
                .filter(phong -> phong.getTrangThai() == TrangThaiPhongHoc.dang_su_dung)
                .filter(phong -> phong.getSucChua() == null
                        || lop.getSoLuongHienTai() == null
                        || phong.getSucChua() >= lop.getSoLuongHienTai())
                .toList();
    }

    private List<List<Long>> danhSachNhomCaUngVien(SinhLichHocRequest request) {
        if (coCaHoc(request)) {
            return List.of(layCaHocIds(request));
        }

        return caHocRepository.findAll().stream()
                .sorted(Comparator.comparing(CaHoc::getGioBatDau))
                .map(ca -> List.of(ca.getId()))
                .toList();
    }

    private SinhLichHocRequest saoChepRequest(SinhLichHocRequest source) {
        SinhLichHocRequest target = new SinhLichHocRequest();
        target.setGiaoVienId(source.getGiaoVienId());
        target.setPhongHocId(source.getPhongHocId());
        target.setCaHocId(source.getCaHocId());
        target.setCaHocIds(source.getCaHocIds() == null ? null : new ArrayList<>(source.getCaHocIds()));
        target.setTuNgay(source.getTuNgay());
        target.setDenNgay(source.getDenNgay());
        target.setThuTrongTuan(source.getThuTrongTuan() == null ? null : new ArrayList<>(source.getThuTrongTuan()));
        target.setTuDongGanNoiDungSyllabus(source.getTuDongGanNoiDungSyllabus());
        target.setTuDongChonPhong(source.getTuDongChonPhong());
        target.setTuDongChonCa(source.getTuDongChonCa());
        target.setSoPhuongAn(source.getSoPhuongAn());
        return target;
    }

    private void validateRequestCoBan(LopHocPhan lop, SinhLichHocRequest request) {
        if (request == null) {
            throw new GiangDayException("Dữ liệu sinh lịch không hợp lệ");
        }

        if (lop.getTrangThai() == TrangThaiLopHocPhan.huy) {
            throw new GiangDayException("Lớp học phần đã hủy, không được sinh lịch");
        }

        if (lop.getTrangThai() == TrangThaiLopHocPhan.da_ket_thuc) {
            throw new GiangDayException("Lớp học phần đã kết thúc, không được sinh lịch");
        }

        if (lop.getSoBuoiHoc() == null || lop.getSoBuoiHoc() < 1) {
            throw new GiangDayException("Lớp học phần chưa cấu hình số buổi học");
        }

        long soSinhVien = sinhVienLopHocPhanRepository.countByLopHocPhanIdAndTrangThaiIn(
                lop.getId(),
                TRANG_THAI_SINH_VIEN_DANG_HOC
        );
        if (soSinhVien < 1) {
            throw new GiangDayException("Lớp học phần chưa có sinh viên đang học, không được sinh lịch");
        }

        if (request.getGiaoVienId() == null) {
            throw new GiangDayException("Giáo viên không được để trống");
        }

        GiaoVien giaoVien = giaoVienRepository.findById(request.getGiaoVienId())
                .orElseThrow(() -> new GiangDayException("Giáo viên không tồn tại"));
        if (giaoVien.getTrangThai() != TrangThaiGiaoVien.dang_day) {
            throw new GiangDayException("Chỉ giáo viên đang dạy mới được xếp lịch");
        }
        if (!phanCongGiangDayRepository.existsByLopHocPhanIdAndGiaoVienId(lop.getId(), request.getGiaoVienId())) {
            throw new GiangDayException("Giáo viên chưa được phân công cho lớp học phần này");
        }

        if (request.getTuNgay() == null || request.getDenNgay() == null) {
            throw new GiangDayException("Từ ngày và đến ngày không được để trống");
        }
        if (request.getTuNgay().isAfter(request.getDenNgay())) {
            throw new GiangDayException("Từ ngày không được sau đến ngày");
        }
        if (lop.getNgayBatDau() != null && request.getTuNgay().isBefore(lop.getNgayBatDau())) {
            throw new GiangDayException("Từ ngày không được trước ngày bắt đầu của lớp học phần");
        }
        if (lop.getNgayKetThuc() != null && request.getDenNgay().isAfter(lop.getNgayKetThuc())) {
            throw new GiangDayException("Đến ngày không được sau ngày kết thúc của lớp học phần");
        }
    }

    private void validateRequest(LopHocPhan lop, SinhLichHocRequest request) {
        if (request == null) {
            throw new GiangDayException("Dữ liệu sinh lịch không hợp lệ");
        }

        if (lop.getTrangThai() == TrangThaiLopHocPhan.huy) {
            throw new GiangDayException("Lớp học phần đã hủy, không được sinh lịch");
        }

        if (lop.getTrangThai() == TrangThaiLopHocPhan.da_ket_thuc) {
            throw new GiangDayException("Lớp học phần đã kết thúc, không được sinh lịch");
        }

        if (lop.getSoBuoiHoc() == null || lop.getSoBuoiHoc() < 1) {
            throw new GiangDayException("Lớp học phần chưa cấu hình số buổi học");
        }

        long soSinhVien = sinhVienLopHocPhanRepository.countByLopHocPhanIdAndTrangThaiIn(
                lop.getId(),
                TRANG_THAI_SINH_VIEN_DANG_HOC
        );
        if (soSinhVien < 1) {
            throw new GiangDayException("Lớp học phần chưa có sinh viên đang học, không được sinh lịch");
        }

        if (request.getGiaoVienId() == null) {
            throw new GiangDayException("Giáo viên không được để trống");
        }

        GiaoVien giaoVien = giaoVienRepository.findById(request.getGiaoVienId())
                .orElseThrow(() -> new GiangDayException("Giáo viên không tồn tại"));
        if (giaoVien.getTrangThai() != TrangThaiGiaoVien.dang_day) {
            throw new GiangDayException("Chỉ giáo viên đang dạy mới được xếp lịch");
        }
        if (!phanCongGiangDayRepository.existsByLopHocPhanIdAndGiaoVienId(lop.getId(), request.getGiaoVienId())) {
            throw new GiangDayException("Giáo viên chưa được phân công cho lớp học phần này");
        }

        if (request.getPhongHocId() == null) {
            throw new GiangDayException("Phòng học không được để trống");
        }

        PhongHoc phongHoc = phongHocRepository.findById(request.getPhongHocId())
                .orElseThrow(() -> new GiangDayException("Phòng học không tồn tại"));
        if (phongHoc.getTrangThai() != TrangThaiPhongHoc.dang_su_dung) {
            throw new GiangDayException("Chỉ phòng học đang sử dụng mới được xếp lịch");
        }
        if (phongHoc.getSucChua() != null
                && lop.getSoLuongHienTai() != null
                && phongHoc.getSucChua() < lop.getSoLuongHienTai()) {
            throw new GiangDayException("Phòng học không đủ sức chứa");
        }

        List<Long> caHocIds = layCaHocIds(request);
        List<CaHoc> caHocs = caHocRepository.findAllById(caHocIds);
        if (caHocs.size() != caHocIds.size()) {
            throw new GiangDayException("Ca học không tồn tại");
        }
        if (request.getTuNgay() == null || request.getDenNgay() == null) {
            throw new GiangDayException("Từ ngày và đến ngày không được để trống");
        }
        if (request.getTuNgay().isAfter(request.getDenNgay())) {
            throw new GiangDayException("Từ ngày không được sau đến ngày");
        }
        if (lop.getNgayBatDau() != null && request.getTuNgay().isBefore(lop.getNgayBatDau())) {
            throw new GiangDayException("Từ ngày không được trước ngày bắt đầu của lớp học phần");
        }
        if (lop.getNgayKetThuc() != null && request.getDenNgay().isAfter(lop.getNgayKetThuc())) {
            throw new GiangDayException("Đến ngày không được sau ngày kết thúc của lớp học phần");
        }

        if (request.getThuTrongTuan() == null || request.getThuTrongTuan().isEmpty()) {
            throw new GiangDayException("Phải chọn ít nhất một thứ trong tuần");
        }
        for (Integer thu : request.getThuTrongTuan()) {
            if (thu == null || thu < 2 || thu > 8) {
                throw new GiangDayException("Thứ trong tuần không hợp lệ");
            }
        }
    }

    private List<String> taoCanhBaoSlot(Long lopHocPhanId, SinhLichHocRequest request, LocalDate ngay, int thu, Long caHocId) {
        List<String> canhBao = new ArrayList<>();

        if (ngayNghiRepository.existsByNgay(ngay)) {
            canhBao.add("Ngày nghỉ");
        }

        if (lichHocRepository.existsByLopHocPhanIdAndNgayHocAndCaHocIdAndTrangThaiNot(
                lopHocPhanId,
                ngay,
                caHocId,
                TrangThaiLichHoc.nghi
        )) {
            canhBao.add("Lớp đã có lịch");
        }

        if (lichHocRepository.existsByGiaoVienIdAndNgayHocAndCaHocIdAndTrangThaiNot(
                request.getGiaoVienId(),
                ngay,
                caHocId,
                TrangThaiLichHoc.nghi
        )) {
            canhBao.add("Giáo viên bận");
        }

        if (giaoVienKhaDungRepository.existsGiaoVienKhongKhaDung(
                request.getGiaoVienId(),
                thu,
                caHocId,
                ngay
        )) {
            canhBao.add("Giáo viên không khả dụng");
        }

        if (lichHocRepository.existsByPhongHocIdAndNgayHocAndCaHocIdAndTrangThaiNot(
                request.getPhongHocId(),
                ngay,
                caHocId,
                TrangThaiLichHoc.nghi
        )) {
            canhBao.add("Phòng bận");
        }

        if (lichHocRepository.existsTrungLichSinhVien(
                lopHocPhanId,
                ngay,
                caHocId,
                null
        )) {
            canhBao.add("Sinh viên trùng lịch");
        }

        return canhBao;
    }

    private List<Long> layCaHocIds(SinhLichHocRequest request) {
        LinkedHashSet<Long> ids = new LinkedHashSet<>();
        if (request.getCaHocIds() != null) {
            request.getCaHocIds().stream()
                    .filter(java.util.Objects::nonNull)
                    .forEach(ids::add);
        }
        if (ids.isEmpty() && request.getCaHocId() != null) {
            ids.add(request.getCaHocId());
        }
        if (ids.isEmpty()) {
            throw new GiangDayException("Ca học không được để trống");
        }
        return new ArrayList<>(ids);
    }

    private Integer tinhThuTrongTuan(LocalDate ngayHoc) {
        if (ngayHoc == null) return null;
        int dayOfWeek = ngayHoc.getDayOfWeek().getValue();
        return dayOfWeek == 7 ? 8 : dayOfWeek + 1;
    }

    private String taoNoiDungBuoiHoc(LopHocPhan lop, int stt, int tongBuoi, Boolean tuDongGanNoiDungSyllabus) {
        if (!Boolean.TRUE.equals(tuDongGanNoiDungSyllabus) || lop.getChuongTrinhMonId() == null) {
            return "Buổi " + stt;
        }

        return syllabusMonHocRepository.findFirstIdByChuongTrinhMonId(lop.getChuongTrinhMonId())
                .map(syllabusMonHocId -> {
                    List<SyllabusChuongBai> chuongBai = syllabusChuongBaiRepository
                            .findBySyllabusMonIdOrderByThuTuAsc(syllabusMonHocId);
                    if (chuongBai.isEmpty()) {
                        return "Buổi " + stt;
                    }

                    int index = Math.min(
                            chuongBai.size() - 1,
                            (int) Math.floor(((double) (stt - 1) / Math.max(tongBuoi, 1)) * chuongBai.size())
                    );
                    SyllabusChuongBai item = chuongBai.get(index);
                    return "Buổi " + stt + ": " + item.getTen();
                })
                .orElse("Buổi " + stt);
    }
}
