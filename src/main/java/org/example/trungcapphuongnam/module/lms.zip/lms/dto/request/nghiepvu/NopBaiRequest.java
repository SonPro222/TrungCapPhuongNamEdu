package org.example.trungcapphuongnam.module.lms.dto.request.nghiepvu;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NopBaiRequest {

    @Valid
    @Builder.Default
    private List<CauTraLoiRequest> cauTraLois = new ArrayList<>();

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class CauTraLoiRequest {
        @NotNull
        private Long cauHoiId;

        private String noiDungTraLoi;

        @Builder.Default
        private List<Long> dapAnIds = new ArrayList<>();
    }
}
