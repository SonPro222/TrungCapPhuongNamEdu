package org.example.trungcapphuongnam.module.chuongTrinh.service.impl;


import lombok.RequiredArgsConstructor;
import org.example.trungcapphuongnam.common.exception.ResourceNotFoundException;
import org.example.trungcapphuongnam.common.spec.LocJpa;
import org.example.trungcapphuongnam.module.chuongTrinh.enums.LoaiDieuKienMonHoc;
import org.example.trungcapphuongnam.module.chuongTrinh.dto.request.DieuKienMonHocMauRequest;
import org.example.trungcapphuongnam.module.chuongTrinh.dto.response.DieuKienMonHocMauResponse;
import org.example.trungcapphuongnam.module.chuongTrinh.entity.DieuKienMonHocMau;
import org.example.trungcapphuongnam.module.chuongTrinh.mapper.DieuKienMonHocMauMapper;
import org.example.trungcapphuongnam.module.chuongTrinh.repository.DieuKienMonHocMauRepository;
import org.example.trungcapphuongnam.module.chuongTrinh.validator.ChuongTrinhNghiepVuValidator;
import org.example.trungcapphuongnam.module.chuongTrinh.service.DieuKienMonHocMauService;
import org.example.trungcapphuongnam.module.chuongTrinh.service.XoaChuongTrinhCascadeService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class DieuKienMonHocMauServiceImpl implements DieuKienMonHocMauService {
    private final ChuongTrinhNghiepVuValidator validator;

    private final DieuKienMonHocMauRepository repository;
    private final DieuKienMonHocMauMapper mapper;
    private final XoaChuongTrinhCascadeService xoaChuongTrinhCascadeService;

    @Override
    @Transactional(readOnly = true)
    public Page<DieuKienMonHocMauResponse> findAll(String ma, String loai, String keyword, Pageable pageable) {
        LoaiDieuKienMonHoc loaiEnum = isBlank(loai) ? null : LoaiDieuKienMonHoc.fromValue(loai);

        return repository.findAll(
                LocJpa.<DieuKienMonHocMau>empty()
                        .and(LocJpa.like("ma", ma))
                        .and(LocJpa.eq("loai", loaiEnum))
                        .and(LocJpa.keyword(keyword, "ma", "noiDung", "ghiChu")),
                pageable
        ).map(mapper::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public DieuKienMonHocMauResponse findById(Long id) {
        return repository.findById(id)
                .map(mapper::toResponse)
                .orElseThrow(() -> new ResourceNotFoundException("Điều kiện môn học gốc không tồn tại: " + id));
    }

    @Override
    public DieuKienMonHocMauResponse create(DieuKienMonHocMauRequest request) {
        validator.validateDieuKienMonHocMau(request, null);
        DieuKienMonHocMau entity = mapper.toEntity(request);
        return mapper.toResponse(repository.save(entity));
    }

    @Override
    public DieuKienMonHocMauResponse update(Long id, DieuKienMonHocMauRequest request) {
        DieuKienMonHocMau entity = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Điều kiện môn học gốc không tồn tại: " + id));

        validator.validateDieuKienMonHocMau(request, id);

        mapper.updateEntity(entity, request);
        return mapper.toResponse(repository.save(entity));
    }

    @Override
    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Điều kiện môn học gốc không tồn tại: " + id);
        }

        xoaChuongTrinhCascadeService.xoaTheoDieuKienMonHocMauId(id);

        repository.deleteById(id);
    }


    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}