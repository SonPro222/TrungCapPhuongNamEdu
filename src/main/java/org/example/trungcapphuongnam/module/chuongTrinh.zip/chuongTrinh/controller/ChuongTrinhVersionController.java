package org.example.trungcapphuongnam.module.chuongTrinh.controller;

import org.example.trungcapphuongnam.common.response.ApiResponse;
import org.example.trungcapphuongnam.module.chuongTrinh.dto.request.ChuyenTrangThaiChuongTrinhVersionRequest;
import org.example.trungcapphuongnam.module.chuongTrinh.dto.request.ChuongTrinhVersionRequest;
import org.example.trungcapphuongnam.module.chuongTrinh.dto.response.ChuongTrinhVersionResponse;
import org.example.trungcapphuongnam.module.chuongTrinh.enums.TrangThaiChuongTrinhVersion;
import org.example.trungcapphuongnam.module.chuongTrinh.service.ChuongTrinhVersionService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.example.trungcapphuongnam.common.constant.Path.ChuongTrinhPath;

@RestController
@RequestMapping(ChuongTrinhPath.VERSION)
@RequiredArgsConstructor
public class ChuongTrinhVersionController {

    private final ChuongTrinhVersionService service;

    @GetMapping
    public ResponseEntity<ApiResponse<Page<ChuongTrinhVersionResponse>>> findAll(
            Pageable pageable,
            @RequestParam(required = false) Long chuongTrinhId,
            @RequestParam(required = false) Boolean laHienHanh,
            @RequestParam(required = false) TrangThaiChuongTrinhVersion trangThai,
            @RequestParam(required = false) String keyword
    ) {
        return ResponseEntity.ok(ApiResponse.ok(service.findAll(chuongTrinhId, laHienHanh, trangThai, keyword, pageable)));
    }

    @GetMapping(ChuongTrinhPath.ID)
    public ResponseEntity<ApiResponse<ChuongTrinhVersionResponse>> findById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok(service.findById(id)));
    }

    @PostMapping
    public ResponseEntity<ApiResponse<ChuongTrinhVersionResponse>> create(@Valid @RequestBody ChuongTrinhVersionRequest request) {
        return ResponseEntity.status(201).body(ApiResponse.created(service.create(request)));
    }

    @PutMapping(ChuongTrinhPath.ID)
    public ResponseEntity<ApiResponse<ChuongTrinhVersionResponse>> update(@PathVariable Long id, @Valid @RequestBody ChuongTrinhVersionRequest request) {
        return ResponseEntity.ok(ApiResponse.ok(service.update(id, request)));
    }

    @PatchMapping(ChuongTrinhPath.ID + "/trang-thai")
    public ResponseEntity<ApiResponse<ChuongTrinhVersionResponse>> chuyenTrangThai(
            @PathVariable Long id,
            @Valid @RequestBody ChuyenTrangThaiChuongTrinhVersionRequest request
    ) {
        return ResponseEntity.ok(ApiResponse.ok(service.chuyenTrangThai(id, request)));
    }

    @DeleteMapping(ChuongTrinhPath.ID)
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.ok(ApiResponse.deleted());
    }
}
