package org.example.trungcapphuongnam.module.chuongTrinh.controller;

import org.example.trungcapphuongnam.common.response.ApiResponse;
import org.example.trungcapphuongnam.module.chuongTrinh.dto.request.MonTienQuyetRequest;
import org.example.trungcapphuongnam.module.chuongTrinh.dto.response.MonTienQuyetResponse;
import org.example.trungcapphuongnam.module.chuongTrinh.service.MonTienQuyetService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.example.trungcapphuongnam.common.constant.Path.ChuongTrinhPath;

@RestController
@RequestMapping(ChuongTrinhPath.MON_TIEN_QUYET)
@RequiredArgsConstructor
public class MonTienQuyetController {

    private final MonTienQuyetService service;

    @GetMapping
    public ResponseEntity<ApiResponse<Page<MonTienQuyetResponse>>> findAll(
            Pageable pageable,
            @RequestParam(required = false) Long monId,
            @RequestParam(required = false) Long monDieuKienId,
            @RequestParam(required = false) String loai,
            @RequestParam(required = false) String keyword
    ) {
        return ResponseEntity.ok(ApiResponse.ok(service.findAll(monId, monDieuKienId, loai, keyword, pageable)));
    }

    @GetMapping(ChuongTrinhPath.ID)
    public ResponseEntity<ApiResponse<MonTienQuyetResponse>> findById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok(service.findById(id)));
    }

    @PostMapping
    public ResponseEntity<ApiResponse<MonTienQuyetResponse>> create(@Valid @RequestBody MonTienQuyetRequest request) {
        return ResponseEntity.status(201).body(ApiResponse.created(service.create(request)));
    }

    @PutMapping(ChuongTrinhPath.ID)
    public ResponseEntity<ApiResponse<MonTienQuyetResponse>> update(@PathVariable Long id, @Valid @RequestBody MonTienQuyetRequest request) {
        return ResponseEntity.ok(ApiResponse.ok(service.update(id, request)));
    }


    @DeleteMapping(ChuongTrinhPath.ID)
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.ok(ApiResponse.deleted());
    }
}
