<template>
  <section class="dsv-page">

    <!-- BỘ LỌC -->
    <div class="dsv-filter-card">
      <div class="dsv-filter-title">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></svg>
        Bộ lọc
      </div>

      <div class="dsv-filter-grid">
        <label class="dsv-label">
          Ngành
          <select v-model="locNganhId" @change="khiDoiNganh" class="dsv-select">
            <option value="">— Tất cả ngành —</option>
            <option v-for="ng in danhSachNganh" :key="ng.id" :value="ng.id">
              {{ ng.maNganh }} – {{ ng.tenNganh }}
            </option>
          </select>
        </label>

        <label class="dsv-label">
          Chương trình
          <select v-model="locChuongTrinhId" @change="khiDoiChuongTrinh" class="dsv-select" :disabled="!locNganhId">
            <option value="">— Tất cả chương trình —</option>
            <option v-for="ct in chuongTrinhTheoNganh" :key="ct.id" :value="ct.id">
              {{ ct.maChuongTrinh }} – {{ ct.tenChuongTrinh }}
            </option>
          </select>
        </label>

        <label class="dsv-label">
          Version
          <select v-model="locVersionId" class="dsv-select" :disabled="!locChuongTrinhId">
            <option value="">— Tất cả version —</option>
            <option v-for="v in versionTheoCT" :key="v.id" :value="v.id">
              {{ v.maVersion }} – {{ v.tenVersion }}
            </option>
          </select>
        </label>

        <label class="dsv-label">
          Mã sinh viên
          <input v-model.trim="locMaSV" class="dsv-input" placeholder="Nhập mã SV..." />
        </label>

        <label class="dsv-label">
          Họ tên
          <input v-model.trim="locTen" class="dsv-input" placeholder="Nhập họ tên..." />
        </label>
      </div>

      <div class="dsv-filter-actions">
        <button class="dsv-btn-primary" @click="timKiem" :disabled="dangTai">
          <svg v-if="!dangTai" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <span v-if="dangTai" class="dsv-spinner"></span>
          {{ dangTai ? 'Đang tìm...' : 'Tìm kiếm' }}
        </button>
        <button class="dsv-btn-ghost" @click="datLaiLoc">Đặt lại</button>
        <span v-if="daTim" class="dsv-result-count">
          Tìm thấy <strong>{{ svHienThi.length }}</strong> sinh viên
        </span>
      </div>
    </div>

    <!-- THÔNG BÁO LỖI -->
    <div v-if="loiTai" class="dsv-error">{{ loiTai }}</div>

    <!-- BẢNG DỮ LIỆU -->
    <div class="dsv-table-card" v-if="daTim">
      <div class="dsv-table-header">
        <h2 class="dsv-table-title">Danh sách sinh viên toàn trường</h2>
        <span class="dsv-badge">{{ svHienThi.length }} sinh viên</span>
      </div>

      <div class="dsv-table-wrap">
        <table class="dsv-table">
          <thead>
          <tr>
            <th class="col-stt">STT</th>
            <th class="col-id">ID</th>
            <th class="col-masv">Mã SV</th>
            <th class="col-ten">Họ và tên</th>
            <th class="col-email">Gmail</th>
            <th class="col-nganh">Ngành</th>
            <th class="col-ct">Chương trình</th>
            <th class="col-ver">Version</th>
            <th class="col-ngay">Ngày nhập học</th>
            <th class="col-action"></th>
          </tr>
          </thead>
          <tbody>
          <tr v-for="(sv, idx) in svHienThi" :key="sv.id" class="dsv-row">
            <td class="col-stt td-center">{{ idx + 1 }}</td>
            <td class="col-id td-mono">{{ sv.id }}</td>
            <td class="col-masv">
              <span class="dsv-masv-chip">{{ sv.maSinhVien || '—' }}</span>
            </td>
            <td class="col-ten">
              <div class="dsv-name-cell">
                <span class="dsv-avatar-init">{{ layChuCai(sv.hoTen) }}</span>
                <span class="dsv-name-text">{{ sv.hoTen || '—' }}</span>
              </div>
            </td>
            <td class="col-email td-secondary">{{ sv.email || '—' }}</td>
            <td class="col-nganh">
              <span class="dsv-tag dsv-tag-nganh">{{ layTenNganh(sv) }}</span>
            </td>
            <td class="col-ct">
              <span class="dsv-tag dsv-tag-ct">{{ layTenChuongTrinh(sv) }}</span>
            </td>
            <td class="col-ver">
              <span class="dsv-tag dsv-tag-ver">{{ layTenVersion(sv) }}</span>
            </td>
            <td class="col-ngay td-secondary">{{ dinhDangNgay(sv.ngayNhapHoc) }}</td>
            <td class="col-action">
              <RouterLink
                  :to="{ name: 'AdminSinhVienChiTiet', params: { id: sv.id } }"
                  class="dsv-btn-xem"
              >
                Xem hồ sơ
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg>
              </RouterLink>
            </td>
          </tr>

          <tr v-if="!svHienThi.length">
            <td colspan="10" class="dsv-empty">
              <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="#cbd5e1" stroke-width="1.5"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
              <p>Không tìm thấy sinh viên nào.<br/>Thử điều chỉnh bộ lọc.</p>
            </td>
          </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- TRẠNG THÁI CHƯA TÌM -->
    <div v-else-if="!dangTai" class="dsv-welcome">
      <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#bfdbfe" stroke-width="1.2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
      <p>Chọn bộ lọc và nhấn <strong>Tìm kiếm</strong> để xem danh sách sinh viên</p>
    </div>

  </section>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { sinhVienService } from '../services/sinhVienService'

// ─── STATE ────────────────────────────────────────────────────────────────────
const danhSachNganh      = ref([])
const danhSachChuongTrinh = ref([])
const danhSachVersion    = ref([])

const locNganhId       = ref('')
const locChuongTrinhId = ref('')
const locVersionId     = ref('')
const locMaSV          = ref('')
const locTen           = ref('')

const danhSachSV = ref([])
const dangTai    = ref(false)
const daTim      = ref(false)
const loiTai     = ref('')

// ─── COMPUTED ─────────────────────────────────────────────────────────────────
const chuongTrinhTheoNganh = computed(() => {
  if (!locNganhId.value) return danhSachChuongTrinh.value
  return danhSachChuongTrinh.value.filter(
      ct => String(ct.nganhId) === String(locNganhId.value)
  )
})

const versionTheoCT = computed(() => {
  if (!locChuongTrinhId.value) return danhSachVersion.value
  return danhSachVersion.value.filter(
      v => String(v.chuongTrinhId) === String(locChuongTrinhId.value)
  )
})

const svHienThi = computed(() => {
  let ds = danhSachSV.value
  if (locMaSV.value) {
    const kw = locMaSV.value.toLowerCase()
    ds = ds.filter(sv => String(sv.maSinhVien || '').toLowerCase().includes(kw))
  }
  if (locTen.value) {
    const kw = locTen.value.toLowerCase()
    ds = ds.filter(sv => String(sv.hoTen || '').toLowerCase().includes(kw))
  }
  return ds
})

// ─── HELPERS ──────────────────────────────────────────────────────────────────
function layTenNganh(sv) {
  const id = sv.nganhId
  if (!id) return '—'
  const ng = danhSachNganh.value.find(n => String(n.id) === String(id))
  return ng ? (ng.tenNganh || ng.maNganh) : String(id)
}

function layTenChuongTrinh(sv) {
  const id = sv.chuongTrinhId
  if (!id) return '—'
  const ct = danhSachChuongTrinh.value.find(c => String(c.id) === String(id))
  return ct ? (ct.tenChuongTrinh || ct.maChuongTrinh) : String(id)
}

function layTenVersion(sv) {
  const id = sv.chuongTrinhVersionId
  if (!id) return '—'
  const ver = danhSachVersion.value.find(v => String(v.id) === String(id))
  return ver ? (ver.maVersion || ver.tenVersion || String(id)) : String(id)
}

function layTenNganhById(id) {
  if (!id) return '—'
  const ng = danhSachNganh.value.find(n => String(n.id) === String(id))
  return ng ? ng.tenNganh : '—'
}

function layTenChuongTrinhById(id) {
  if (!id) return '—'
  const ct = danhSachChuongTrinh.value.find(c => String(c.id) === String(id))
  return ct ? ct.tenChuongTrinh : '—'
}

function layTenVersionById(id) {
  if (!id) return '—'
  const ver = danhSachVersion.value.find(v => String(v.id) === String(id))
  return ver ? (ver.maVersion || ver.tenVersion || String(id)) : '—'
}

function layNganhIdTuVersion(versionId) {
  const ver = danhSachVersion.value.find(v => String(v.id) === String(versionId))
  if (!ver) return null
  const ct = danhSachChuongTrinh.value.find(c => String(c.id) === String(ver.chuongTrinhId))
  return ct ? ct.nganhId : null
}

function dinhDangNgay(val) {
  if (!val) return '—'
  try {
    const d = new Date(val)
    if (isNaN(d)) return val
    return d.toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit', year: 'numeric' })
  } catch {
    return val
  }
}

function layChuCai(hoTen) {
  if (!hoTen) return '?'
  const parts = hoTen.trim().split(' ')
  return parts[parts.length - 1].charAt(0).toUpperCase()
}

// ─── ACTIONS ──────────────────────────────────────────────────────────────────
function khiDoiNganh() {
  locChuongTrinhId.value = ''
  locVersionId.value = ''
}

function khiDoiChuongTrinh() {
  locVersionId.value = ''
}

function datLaiLoc() {
  locNganhId.value = ''
  locChuongTrinhId.value = ''
  locVersionId.value = ''
  locMaSV.value = ''
  locTen.value = ''
  danhSachSV.value = []
  daTim.value = false
  loiTai.value = ''
}

async function timKiem() {
  dangTai.value = true
  loiTai.value = ''
  try {
    const ds = await sinhVienService.laySinhVienTheoNganhChuongTrinhVersion(
        locNganhId.value || null,
        locChuongTrinhId.value || null,
        locVersionId.value || null,
        0,
        500
    )
    danhSachSV.value = ds
    daTim.value = true
  } catch (e) {
    loiTai.value = 'Lỗi tải dữ liệu: ' + (e?.message || 'Không xác định')
  } finally {
    dangTai.value = false
  }
}

// ─── MOUNTED ──────────────────────────────────────────────────────────────────
onMounted(async () => {
  try {
    const [nganh, ct, ver] = await Promise.all([
      sinhVienService.layNganh(),
      sinhVienService.layChuongTrinh(),
      sinhVienService.layVersion(),
    ])
    danhSachNganh.value = nganh
    danhSachChuongTrinh.value = ct
    danhSachVersion.value = ver
  } catch (e) {
    loiTai.value = 'Lỗi tải danh sách ngành / chương trình: ' + e.message
  }
})
</script>

<style scoped>
/* ── LAYOUT ── */
.dsv-page {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

/* ── FILTER CARD ── */
.dsv-filter-card {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 14px;
  padding: 18px 20px;
  box-shadow: 0 2px 10px rgba(15, 23, 42, 0.04);
}

.dsv-filter-title {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 13px;
  font-weight: 700;
  color: #64748b;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  margin-bottom: 14px;
}

.dsv-filter-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 12px;
  margin-bottom: 14px;
}

.dsv-label {
  display: flex;
  flex-direction: column;
  gap: 5px;
  font-size: 12px;
  font-weight: 600;
  color: #475569;
}

.dsv-select,
.dsv-input {
  height: 36px;
  padding: 0 10px;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  font-size: 13px;
  color: #1e293b;
  background: #f8fafc;
  transition: border-color 0.15s, box-shadow 0.15s;
  width: 100%;
  box-sizing: border-box;
}

.dsv-select:focus,
.dsv-input:focus {
  outline: none;
  border-color: #3b82f6;
  box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.12);
  background: #fff;
}

.dsv-select:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.dsv-filter-actions {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
}

.dsv-btn-primary {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 36px;
  padding: 0 16px;
  background: #1d4ed8;
  color: #fff;
  border: none;
  border-radius: 8px;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  transition: background 0.15s, transform 0.1s;
}
.dsv-btn-primary:hover:not(:disabled) { background: #1e40af; }
.dsv-btn-primary:active { transform: scale(0.97); }
.dsv-btn-primary:disabled { opacity: 0.6; cursor: not-allowed; }

.dsv-btn-ghost {
  height: 36px;
  padding: 0 14px;
  background: transparent;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  font-size: 13px;
  font-weight: 500;
  color: #64748b;
  cursor: pointer;
  transition: background 0.15s, border-color 0.15s;
}
.dsv-btn-ghost:hover { background: #f1f5f9; border-color: #cbd5e1; }

.dsv-result-count {
  font-size: 13px;
  color: #64748b;
}
.dsv-result-count strong { color: #1d4ed8; }

.dsv-spinner {
  display: inline-block;
  width: 13px;
  height: 13px;
  border: 2px solid rgba(255,255,255,0.4);
  border-top-color: #fff;
  border-radius: 50%;
  animation: dsv-spin 0.7s linear infinite;
}
@keyframes dsv-spin { to { transform: rotate(360deg); } }

/* ── ERROR ── */
.dsv-error {
  background: #fef2f2;
  border: 1px solid #fecaca;
  border-radius: 10px;
  padding: 12px 16px;
  font-size: 13px;
  color: #dc2626;
}

/* ── TABLE CARD ── */
.dsv-table-card {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 14px;
  overflow: hidden;
  box-shadow: 0 2px 10px rgba(15, 23, 42, 0.04);
}

.dsv-table-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 20px 14px;
  border-bottom: 1px solid #f1f5f9;
}

.dsv-table-title {
  font-size: 15px;
  font-weight: 700;
  color: #0f172a;
  margin: 0;
}

.dsv-badge {
  display: inline-flex;
  align-items: center;
  height: 24px;
  padding: 0 10px;
  background: #eff6ff;
  border: 1px solid #bfdbfe;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
  color: #1d4ed8;
}

.dsv-table-wrap {
  overflow-x: auto;
}

/* ── TABLE ── */
.dsv-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
}

.dsv-table thead tr {
  background: #f8fafc;
}

.dsv-table th {
  padding: 10px 14px;
  text-align: left;
  font-size: 11.5px;
  font-weight: 700;
  color: #64748b;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  border-bottom: 1px solid #e2e8f0;
  white-space: nowrap;
}

.dsv-table td {
  padding: 11px 14px;
  color: #1e293b;
  border-bottom: 1px solid #f1f5f9;
  vertical-align: middle;
}

.dsv-row:last-child td {
  border-bottom: none;
}

.dsv-row:hover td {
  background: #f8fafc;
}

/* ── COL WIDTHS ── */
.col-stt    { width: 44px; }
.col-id     { width: 60px; }
.col-masv   { width: 110px; }
.col-ten    { min-width: 160px; }
.col-email  { min-width: 180px; }
.col-nganh  { min-width: 130px; }
.col-ct     { min-width: 140px; }
.col-ver    { width: 110px; }
.col-ngay   { width: 120px; }
.col-action { width: 110px; text-align: right; padding-right: 16px; }

.td-center   { text-align: center; color: #94a3b8; font-size: 12px; }
.td-mono     { font-family: 'Courier New', monospace; font-size: 12px; color: #64748b; }
.td-secondary { color: #64748b; }

/* ── CELLS ── */
.dsv-masv-chip {
  display: inline-block;
  padding: 2px 8px;
  background: #f1f5f9;
  border: 1px solid #e2e8f0;
  border-radius: 6px;
  font-family: 'Courier New', monospace;
  font-size: 12px;
  font-weight: 600;
  color: #334155;
  letter-spacing: 0.03em;
}

.dsv-name-cell {
  display: flex;
  align-items: center;
  gap: 9px;
}

.dsv-avatar-init {
  flex-shrink: 0;
  width: 30px;
  height: 30px;
  border-radius: 50%;
  background: linear-gradient(135deg, #1d4ed8, #3b82f6);
  color: #fff;
  font-size: 12px;
  font-weight: 700;
  display: flex;
  align-items: center;
  justify-content: center;
}

.dsv-name-text {
  font-weight: 500;
  color: #0f172a;
}

.dsv-tag {
  display: inline-block;
  padding: 3px 8px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 500;
  max-width: 150px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.dsv-tag-nganh { background: #f0fdf4; color: #15803d; border: 1px solid #bbf7d0; }
.dsv-tag-ct    { background: #fef9c3; color: #854d0e; border: 1px solid #fde68a; }
.dsv-tag-ver   { background: #faf5ff; color: #7e22ce; border: 1px solid #e9d5ff; }

.dsv-btn-xem {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 30px;
  padding: 0 10px;
  background: #eff6ff;
  border: 1px solid #bfdbfe;
  border-radius: 7px;
  font-size: 12px;
  font-weight: 600;
  color: #1d4ed8;
  text-decoration: none;
  white-space: nowrap;
  transition: background 0.15s, border-color 0.15s, color 0.15s;
  cursor: pointer;
}
.dsv-btn-xem:hover {
  background: #dbeafe;
  border-color: #93c5fd;
  color: #1e40af;
}

/* ── EMPTY ── */
.dsv-empty {
  text-align: center;
  padding: 48px 24px !important;
  color: #94a3b8;
}
.dsv-empty svg { display: block; margin: 0 auto 12px; }
.dsv-empty p { margin: 0; font-size: 14px; line-height: 1.6; }

/* ── WELCOME STATE ── */
.dsv-welcome {
  text-align: center;
  padding: 56px 24px;
  background: #fff;
  border: 1px dashed #bfdbfe;
  border-radius: 14px;
  color: #94a3b8;
}
.dsv-welcome svg { display: block; margin: 0 auto 16px; }
.dsv-welcome p { margin: 0; font-size: 14px; line-height: 1.6; color: #64748b; }
.dsv-welcome strong { color: #1d4ed8; }

/* ── RESPONSIVE ── */
@media (max-width: 700px) {
  .dsv-filter-grid { grid-template-columns: 1fr; }
  .dsv-table-wrap { font-size: 12px; }
  .col-id, .col-stt, .td-mono { display: none; }
}
</style>