<template>
  <section class="ct-page">

    <!-- BACK + BREADCRUMB -->
    <nav class="ct-back-bar">
      <RouterLink :to="{ name: 'AdminSinhVienDanhSach' }" class="ct-back-link">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
          <polyline points="15 18 9 12 15 6"/>
        </svg>
        Danh sách sinh viên
      </RouterLink>
      <span class="ct-breadcrumb-sep">›</span>
      <span class="ct-breadcrumb-cur">{{ sinhVien?.hoTen || 'Chi tiết sinh viên' }}</span>
    </nav>

    <!-- LOADING -->
    <div v-if="dangTai" class="ct-loading">
      <div class="ct-spinner"></div>
      <span>Đang tải hồ sơ sinh viên...</span>
    </div>

    <!-- LỖI -->
    <div v-else-if="loiTai" class="ct-error">{{ loiTai }}</div>

    <template v-else-if="sinhVien">

      <!-- HERO CARD -->
      <div class="ct-hero">
        <div class="ct-hero-left">
          <div class="ct-big-avatar" :style="{ background: avatarColor(sinhVien.hoTen) }">
            {{ layChuCai(sinhVien.hoTen) }}
          </div>
          <div class="ct-hero-info">
            <h1 class="ct-hero-name">{{ sinhVien.hoTen }}</h1>
            <div class="ct-hero-meta">
              <span class="ct-masv-chip">{{ sinhVien.maSinhVien }}</span>
              <span class="ct-dot">·</span>
              <span class="ct-email">{{ sinhVien.email }}</span>
              <span class="ct-dot">·</span>
              <span class="ct-status" :class="trangThaiClass(sinhVien.trangThai)">
                {{ trangThaiLabel(sinhVien.trangThai) }}
              </span>
            </div>
            <div class="ct-hero-ct" v-if="infoHoc">
              <span class="ct-tag-nganh">{{ infoHoc.tenNganh }}</span>
              <span class="ct-tag-ct">{{ infoHoc.tenChuongTrinh }}</span>
              <span class="ct-tag-ver">{{ infoHoc.maVersion }}</span>
            </div>
          </div>
        </div>

        <!-- STATS -->
        <div class="ct-stats">
          <div class="ct-stat">
            <div class="ct-stat-val ct-stat-blue">{{ stats.dangHoc }}</div>
            <div class="ct-stat-lbl">Đang học</div>
          </div>
          <div class="ct-stat">
            <div class="ct-stat-val ct-stat-green">{{ stats.hoanThanh }}</div>
            <div class="ct-stat-lbl">Hoàn thành</div>
          </div>
          <div class="ct-stat">
            <div class="ct-stat-val ct-stat-red">{{ stats.rot }}</div>
            <div class="ct-stat-lbl">Rớt môn</div>
          </div>
          <div class="ct-stat">
            <div class="ct-stat-val ct-stat-gray">{{ stats.huy }}</div>
            <div class="ct-stat-lbl">Đã hủy</div>
          </div>
        </div>
      </div>

      <!-- TABS -->
      <div class="ct-tabs">
        <button
          v-for="tab in tabs"
          :key="tab.key"
          class="ct-tab"
          :class="{ active: tabActive === tab.key }"
          @click="tabActive = tab.key"
        >
          <span v-html="tab.icon"></span>
          {{ tab.label }}
          <span v-if="tab.count !== undefined" class="ct-tab-count">{{ tab.count }}</span>
        </button>
      </div>

      <!-- TAB: HỒ SƠ -->
      <div v-if="tabActive === 'hoSo'" class="ct-tab-panel">
        <div class="ct-section-grid">

          <div class="ct-section">
            <div class="ct-section-title">Thông tin cá nhân</div>
            <div class="ct-info-grid">
              <div class="ct-info-row">
                <span class="ct-info-lbl">Họ và tên</span>
                <span class="ct-info-val">{{ sinhVien.hoTen || '—' }}</span>
              </div>
              <div class="ct-info-row">
                <span class="ct-info-lbl">Ngày sinh</span>
                <span class="ct-info-val">{{ dinhDangNgay(sinhVien.ngaySinh) }}</span>
              </div>
              <div class="ct-info-row">
                <span class="ct-info-lbl">Giới tính</span>
                <span class="ct-info-val">{{ gioiTinhLabel(sinhVien.gioiTinh) }}</span>
              </div>
              <div class="ct-info-row">
                <span class="ct-info-lbl">CCCD/CMND</span>
                <span class="ct-info-val ct-mono">{{ sinhVien.soCccd || '—' }}</span>
              </div>
              <div class="ct-info-row">
                <span class="ct-info-lbl">Ngày cấp CCCD</span>
                <span class="ct-info-val">{{ dinhDangNgay(sinhVien.ngayCapCccd) }}</span>
              </div>
              <div class="ct-info-row">
                <span class="ct-info-lbl">Nơi cấp</span>
                <span class="ct-info-val">{{ sinhVien.noiCapCccd || '—' }}</span>
              </div>
              <div class="ct-info-row">
                <span class="ct-info-lbl">Số điện thoại</span>
                <span class="ct-info-val ct-mono">{{ sinhVien.soDienThoai || '—' }}</span>
              </div>
              <div class="ct-info-row">
                <span class="ct-info-lbl">Địa chỉ</span>
                <span class="ct-info-val">{{ sinhVien.diaChi || '—' }}</span>
              </div>
              <div class="ct-info-row">
                <span class="ct-info-lbl">Địa chỉ thường trú</span>
                <span class="ct-info-val">{{ sinhVien.diaChiThuongTru || '—' }}</span>
              </div>
            </div>
          </div>

          <div class="ct-section">
            <div class="ct-section-title">Thông tin học tập</div>
            <div class="ct-info-grid">
              <div class="ct-info-row">
                <span class="ct-info-lbl">Mã sinh viên</span>
                <span class="ct-info-val"><span class="ct-masv-chip">{{ sinhVien.maSinhVien }}</span></span>
              </div>
              <div class="ct-info-row">
                <span class="ct-info-lbl">Gmail</span>
                <span class="ct-info-val">{{ sinhVien.email || '—' }}</span>
              </div>
              <div class="ct-info-row" v-if="svChuongTrinh">
                <span class="ct-info-lbl">Ngày nhập học</span>
                <span class="ct-info-val">{{ dinhDangNgay(svChuongTrinh.ngayNhapHoc) }}</span>
              </div>
              <div class="ct-info-row" v-if="svChuongTrinh">
                <span class="ct-info-lbl">Ngày đăng ký</span>
                <span class="ct-info-val">{{ dinhDangNgay(svChuongTrinh.ngayDangKy) }}</span>
              </div>
              <div class="ct-info-row" v-if="infoHoc">
                <span class="ct-info-lbl">Ngành</span>
                <span class="ct-info-val">{{ infoHoc.tenNganh }}</span>
              </div>
              <div class="ct-info-row" v-if="infoHoc">
                <span class="ct-info-lbl">Chương trình</span>
                <span class="ct-info-val">{{ infoHoc.tenChuongTrinh }}</span>
              </div>
              <div class="ct-info-row" v-if="infoHoc">
                <span class="ct-info-lbl">Version</span>
                <span class="ct-info-val">{{ infoHoc.maVersion }}</span>
              </div>
              <div class="ct-info-row">
                <span class="ct-info-lbl">Bằng cấp đầu vào</span>
                <span class="ct-info-val">{{ sinhVien.bangCap || '—' }}</span>
              </div>
              <div class="ct-info-row">
                <span class="ct-info-lbl">Năm tốt nghiệp THPT</span>
                <span class="ct-info-val">{{ sinhVien.namTotNghiep || '—' }}</span>
              </div>
              <div class="ct-info-row">
                <span class="ct-info-lbl">Trường THPT</span>
                <span class="ct-info-val">{{ sinhVien.truongTotNghiep || '—' }}</span>
              </div>
            </div>
          </div>

          <div class="ct-section ct-section-full">
            <div class="ct-section-title">Thông tin gia đình</div>
            <div class="ct-family-grid">
              <div class="ct-family-block">
                <div class="ct-family-head">Cha</div>
                <div class="ct-info-grid">
                  <div class="ct-info-row"><span class="ct-info-lbl">Họ tên</span><span class="ct-info-val">{{ sinhVien.hoTenCha || '—' }}</span></div>
                  <div class="ct-info-row"><span class="ct-info-lbl">Nghề nghiệp</span><span class="ct-info-val">{{ sinhVien.ngheNghiepCha || '—' }}</span></div>
                  <div class="ct-info-row"><span class="ct-info-lbl">SĐT</span><span class="ct-info-val ct-mono">{{ sinhVien.sdtCha || '—' }}</span></div>
                  <div class="ct-info-row"><span class="ct-info-lbl">Email</span><span class="ct-info-val">{{ sinhVien.emailCha || '—' }}</span></div>
                </div>
              </div>
              <div class="ct-family-block">
                <div class="ct-family-head">Mẹ</div>
                <div class="ct-info-grid">
                  <div class="ct-info-row"><span class="ct-info-lbl">Họ tên</span><span class="ct-info-val">{{ sinhVien.hoTenMe || '—' }}</span></div>
                  <div class="ct-info-row"><span class="ct-info-lbl">Nghề nghiệp</span><span class="ct-info-val">{{ sinhVien.ngheNghiepMe || '—' }}</span></div>
                  <div class="ct-info-row"><span class="ct-info-lbl">SĐT</span><span class="ct-info-val ct-mono">{{ sinhVien.sdtMe || '—' }}</span></div>
                  <div class="ct-info-row"><span class="ct-info-lbl">Email</span><span class="ct-info-val">{{ sinhVien.emailMe || '—' }}</span></div>
                </div>
              </div>
              <div class="ct-family-block">
                <div class="ct-family-head">Người thân khẩn cấp</div>
                <div class="ct-info-grid">
                  <div class="ct-info-row"><span class="ct-info-lbl">Họ tên</span><span class="ct-info-val">{{ sinhVien.hoTenNguoiThan || '—' }}</span></div>
                  <div class="ct-info-row"><span class="ct-info-lbl">Quan hệ</span><span class="ct-info-val">{{ sinhVien.quanHeNguoiThan || '—' }}</span></div>
                  <div class="ct-info-row"><span class="ct-info-lbl">SĐT</span><span class="ct-info-val ct-mono">{{ sinhVien.sdtNguoiThan || '—' }}</span></div>
                  <div class="ct-info-row"><span class="ct-info-lbl">Email</span><span class="ct-info-val">{{ sinhVien.emailNguoiThan || '—' }}</span></div>
                </div>
              </div>
            </div>
          </div>

          <div class="ct-section ct-section-full" v-if="sinhVien.ghiChuHoSo">
            <div class="ct-section-title">Ghi chú hồ sơ</div>
            <p class="ct-ghi-chu">{{ sinhVien.ghiChuHoSo }}</p>
          </div>

        </div>
      </div>

      <!-- TAB: MÔN HỌC -->
      <div v-if="tabActive === 'monHoc'" class="ct-tab-panel">
        <div v-if="dangTaiMonHoc" class="ct-loading-sm">
          <div class="ct-spinner-sm"></div> Đang tải dữ liệu môn học...
        </div>
        <div v-else class="ct-table-card">
          <div class="ct-table-wrap">
            <table class="ct-table">
              <thead>
                <tr>
                  <th>STT</th>
                  <th>Mã lớp</th>
                  <th>Tên lớp học phần</th>
                  <th>Ngày đăng ký</th>
                  <th>Trạng thái</th>
                  <th>Điểm TK</th>
                  <th>Kết quả</th>
                  <th>Điểm chữ</th>
                  <th>Học lại</th>
                </tr>
              </thead>
              <tbody>
                <tr
                  v-for="(row, i) in danhSachMonHienThi"
                  :key="row.svlhp.id"
                  class="ct-table-row"
                >
                  <td class="td-center td-muted">{{ i + 1 }}</td>
                  <td><span class="ct-ma-chip">{{ row.lhp?.maLop || '—' }}</span></td>
                  <td class="td-bold">{{ row.lhp?.tenLop || '—' }}</td>
                  <td class="td-muted">{{ dinhDangNgayGio(row.svlhp.ngayDangKy) }}</td>
                  <td>
                    <span class="ct-mon-status" :class="monStatusClass(row.svlhp.trangThai)">
                      {{ monStatusLabel(row.svlhp.trangThai) }}
                    </span>
                  </td>
                  <td class="td-center">
                    <span v-if="row.kq" class="ct-diem" :class="diemClass(row.kq.diemTongKet)">
                      {{ row.kq.diemTongKet != null ? Number(row.kq.diemTongKet).toFixed(1) : '—' }}
                    </span>
                    <span v-else class="td-muted">—</span>
                  </td>
                  <td class="td-center">
                    <span v-if="row.kq?.ketQua" class="ct-ketqua" :class="ketQuaClass(row.kq.ketQua)">
                      {{ row.kq.ketQua }}
                    </span>
                    <span v-else class="td-muted">—</span>
                  </td>
                  <td class="td-center">
                    <span v-if="row.kq?.diemQuyDoi != null" class="td-muted">
                      {{ row.kq.diemQuyDoi }}
                    </span>
                    <span v-else class="td-muted">—</span>
                  </td>
                  <td class="td-center">
                    <span v-if="row.svlhp.laHocLai" class="ct-hoc-lai-tag">Học lại</span>
                    <span v-else class="td-muted">—</span>
                  </td>
                </tr>
                <tr v-if="!danhSachMonHienThi.length">
                  <td colspan="9" class="ct-empty">Chưa có dữ liệu môn học.</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- TAB: LỊCH HỌC -->
      <div v-if="tabActive === 'lichHoc'" class="ct-tab-panel">
        <div class="ct-lh-toolbar">
          <label class="ct-label-inline">
            Lớp học phần:
            <select v-model="lopHocPhanChon" @change="taiLichHoc" class="ct-select-sm">
              <option value="">— Chọn lớp —</option>
              <option
                v-for="lhp in danhSachLHPCuaSV"
                :key="lhp.lopHocPhanId"
                :value="lhp.lopHocPhanId"
              >
                {{ layTenLHP(lhp.lopHocPhanId) }}
              </option>
            </select>
          </label>
        </div>

        <div v-if="dangTaiLichHoc" class="ct-loading-sm">
          <div class="ct-spinner-sm"></div> Đang tải lịch học...
        </div>

        <div v-else-if="!lopHocPhanChon" class="ct-empty-hint">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#bfdbfe" stroke-width="1.4"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
          <p>Chọn lớp học phần để xem lịch học.</p>
        </div>

        <div v-else class="ct-table-card">
          <div class="ct-table-wrap">
            <table class="ct-table">
              <thead>
                <tr>
                  <th>STT</th>
                  <th>Ngày học</th>
                  <th>Ca học</th>
                  <th>Giờ</th>
                  <th>Phòng học</th>
                  <th>Giáo viên</th>
                  <th>Nội dung</th>
                  <th>Trạng thái</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(lh, i) in danhSachLichHoc" :key="lh.id" class="ct-table-row">
                  <td class="td-center td-muted">{{ i + 1 }}</td>
                  <td class="td-bold">{{ dinhDangNgay(lh.ngayHoc) }}</td>
                  <td>{{ lh.tenCa || lh.maCa || '—' }}</td>
                  <td class="td-muted ct-mono">
                    {{ lh.gioBatDau ? lh.gioBatDau.substring(0, 5) : '—' }}
                    {{ lh.gioKetThuc ? '– ' + lh.gioKetThuc.substring(0, 5) : '' }}
                  </td>
                  <td>{{ lh.tenPhong || lh.maPhong || '—' }}</td>
                  <td>{{ lh.tenGiaoVien || '—' }}</td>
                  <td class="td-muted lh-noidung">{{ lh.noiDungBuoiHoc || '—' }}</td>
                  <td>
                    <span class="ct-lh-status" :class="lichHocStatusClass(lh.trangThai)">
                      {{ lichHocStatusLabel(lh.trangThai) }}
                    </span>
                  </td>
                </tr>
                <tr v-if="!danhSachLichHoc.length">
                  <td colspan="8" class="ct-empty">Chưa có lịch học cho lớp này.</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

    </template>
  </section>
</template>

<script setup>
import { ref, computed, onMounted, watch } from 'vue'
import { useRoute } from 'vue-router'
import { sinhVienService } from '../services/sinhVienService'

const route = useRoute()
const sinhVienId = computed(() => Number(route.params.id))

// ─── STATE ────────────────────────────────────────────────────────────────────
const sinhVien     = ref(null)
const svChuongTrinh = ref(null)   // SinhVienChuongTrinhResponse
const danhSachNganh = ref([])
const danhSachChuongTrinh = ref([])
const danhSachVersion = ref([])
const danhSachLopHocPhan = ref([])   // LopHocPhanResponse[] for lookup

const danhSachSVLHP  = ref([])   // SinhVienLopHocPhan của SV này
const danhSachKetQua = ref([])   // KetQuaLopHocPhan của SV này
const danhSachLichHoc = ref([])

const dangTai = ref(false)
const dangTaiMonHoc = ref(false)
const dangTaiLichHoc = ref(false)
const loiTai  = ref('')

const tabActive = ref('hoSo')
const lopHocPhanChon = ref('')

// ─── TABS ─────────────────────────────────────────────────────────────────────
const tabs = computed(() => [
  { key: 'hoSo',   label: 'Hồ sơ',     icon: '👤' },
  { key: 'monHoc', label: 'Môn học',   icon: '📚', count: danhSachSVLHP.value.length },
  { key: 'lichHoc',label: 'Lịch học',  icon: '📅' },
])

// ─── DERIVED INFO ─────────────────────────────────────────────────────────────
const infoHoc = computed(() => {
  if (!svChuongTrinh.value) return null
  const verId = svChuongTrinh.value.chuongTrinhVersionId
  const ver = danhSachVersion.value.find(v => String(v.id) === String(verId))
  if (!ver) return null
  const ct  = danhSachChuongTrinh.value.find(c => String(c.id) === String(ver.chuongTrinhId))
  const ng  = ct ? danhSachNganh.value.find(n => String(n.id) === String(ct.nganhId)) : null
  return {
    maVersion:     ver.maVersion || ver.tenVersion || '—',
    tenChuongTrinh: ct?.tenChuongTrinh || ct?.maChuongTrinh || '—',
    tenNganh:       ng?.tenNganh || ng?.maNganh || '—',
  }
})

// ─── STATS ────────────────────────────────────────────────────────────────────
const stats = computed(() => ({
  dangHoc:    danhSachSVLHP.value.filter(x => ['da_dang_ky','dang_hoc'].includes(x.trangThai)).length,
  hoanThanh:  danhSachSVLHP.value.filter(x => x.trangThai === 'hoan_thanh').length,
  rot:        danhSachSVLHP.value.filter(x => x.trangThai === 'rot').length,
  huy:        danhSachSVLHP.value.filter(x => x.trangThai === 'huy').length,
}))

// ─── MON HOC MERGED ───────────────────────────────────────────────────────────
const danhSachLHPCuaSV = computed(() => danhSachSVLHP.value)

const ketQuaMap = computed(() => {
  const m = {}
  danhSachKetQua.value.forEach(kq => { m[kq.lopHocPhanId] = kq })
  return m
})
const lhpMap = computed(() => {
  const m = {}
  danhSachLopHocPhan.value.forEach(lhp => { m[lhp.id] = lhp })
  return m
})

const danhSachMonHienThi = computed(() =>
  danhSachSVLHP.value.map(svlhp => ({
    svlhp,
    lhp: lhpMap.value[svlhp.lopHocPhanId] || null,
    kq:  ketQuaMap.value[svlhp.lopHocPhanId] || null,
  }))
)

// ─── HELPERS ──────────────────────────────────────────────────────────────────
function layChuCai(hoTen) {
  if (!hoTen) return '?'
  const parts = hoTen.trim().split(' ')
  return parts[parts.length - 1].charAt(0).toUpperCase()
}
const COLORS = ['#1d4ed8','#0891b2','#7c3aed','#be185d','#b45309','#047857','#9333ea']
function avatarColor(name) {
  if (!name) return '#1d4ed8'
  let h = 0; for (let c of name) h = c.charCodeAt(0) + ((h << 5) - h)
  return COLORS[Math.abs(h) % COLORS.length]
}
function dinhDangNgay(val) {
  if (!val) return '—'
  try { const d = new Date(val); return isNaN(d) ? val : d.toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit', year: 'numeric' }) }
  catch { return val }
}
function dinhDangNgayGio(val) {
  if (!val) return '—'
  try { const d = new Date(val); return isNaN(d) ? val : d.toLocaleDateString('vi-VN') }
  catch { return val }
}
function gioiTinhLabel(gt) {
  return gt === 'NAM' ? 'Nam' : gt === 'NU' ? 'Nữ' : gt === 'KHAC' ? 'Khác' : gt || '—'
}
function trangThaiLabel(tt) {
  const m = { dang_hoc: 'Đang học', bao_luu: 'Bảo lưu', thoi_hoc: 'Thôi học', tot_nghiep: 'Tốt nghiệp' }
  return m[tt] || tt || '—'
}
function trangThaiClass(tt) {
  return { 'tt-dh': tt==='dang_hoc', 'tt-bl': tt==='bao_luu', 'tt-th': tt==='thoi_hoc', 'tt-tn': tt==='tot_nghiep' }
}
function monStatusLabel(tt) {
  const m = { da_dang_ky: 'Đã đăng ký', dang_hoc: 'Đang học', hoan_thanh: 'Hoàn thành', rot: 'Rớt', huy: 'Đã hủy', hoc_lai: 'Học lại' }
  return m[tt] || tt || '—'
}
function monStatusClass(tt) {
  return { 'ms-ddk': tt==='da_dang_ky', 'ms-dh': tt==='dang_hoc', 'ms-ht': tt==='hoan_thanh', 'ms-rot': tt==='rot', 'ms-huy': tt==='huy', 'ms-hl': tt==='hoc_lai' }
}
function diemClass(diem) {
  if (diem == null) return ''
  const d = Number(diem)
  if (d >= 8) return 'diem-tot'
  if (d >= 5) return 'diem-tb'
  return 'diem-yeu'
}
function ketQuaClass(kq) {
  if (!kq) return ''
  const u = kq.toString().toUpperCase()
  if (u === 'DAT' || u === 'PASS') return 'kq-dat'
  if (u === 'KHONG_DAT' || u === 'FAIL') return 'kq-khong-dat'
  return ''
}
function lichHocStatusLabel(tt) {
  const m = { da_day: 'Đã dạy', chua_day: 'Chưa dạy', vang: 'Vắng', huy: 'Đã hủy', bu_lich: 'Bù lịch' }
  return m[tt] || tt || '—'
}
function lichHocStatusClass(tt) {
  return { 'lhs-dd': tt==='da_day', 'lhs-cd': tt==='chua_day', 'lhs-v': tt==='vang', 'lhs-h': tt==='huy' }
}
function layTenLHP(id) {
  const lhp = lhpMap.value[id]
  return lhp ? `${lhp.maLop} – ${lhp.tenLop}` : `LHP #${id}`
}

// ─── LOAD DATA ────────────────────────────────────────────────────────────────
onMounted(async () => {
  dangTai.value = true
  loiTai.value  = ''
  try {
    const id = sinhVienId.value
    const [sv, nganh, ct, ver, svct, svlhp, kqList, lhpAll] = await Promise.all([
      sinhVienService.laySinhVienTheoId(id),
      sinhVienService.layNganh(),
      sinhVienService.layChuongTrinh(),
      sinhVienService.layVersion(),
      sinhVienService.laySinhVienChuongTrinhTheoSinhVienId(id),
      sinhVienService.laySinhVienLopHocPhanTheoSinhVien(id),
      sinhVienService.layKetQuaLopHocPhanTheoSinhVien(id),
      sinhVienService.layLopHocPhan({ page: 0, size: 500 }),
    ])
    sinhVien.value           = sv
    danhSachNganh.value       = nganh
    danhSachChuongTrinh.value = ct
    danhSachVersion.value     = ver
    svChuongTrinh.value       = svct?.[0] || null
    danhSachSVLHP.value       = svlhp
    danhSachKetQua.value      = kqList
    danhSachLopHocPhan.value  = lhpAll
  } catch (e) {
    loiTai.value = 'Lỗi tải hồ sơ: ' + (e?.message || 'Không xác định')
  } finally {
    dangTai.value = false
  }
})

async function taiLichHoc() {
  if (!lopHocPhanChon.value) return
  dangTaiLichHoc.value = true
  try {
    danhSachLichHoc.value = await sinhVienService.layLichHocTheoLop(lopHocPhanChon.value)
  } catch (e) {
    danhSachLichHoc.value = []
  } finally {
    dangTaiLichHoc.value = false
  }
}
</script>

<style scoped>
.ct-page { display: flex; flex-direction: column; gap: 14px; }

/* ── BACK ── */
.ct-back-bar { display: flex; align-items: center; gap: 6px; font-size: 13px; }
.ct-back-link { display: inline-flex; align-items: center; gap: 4px; color: #1d4ed8; text-decoration: none; font-weight: 500; }
.ct-back-link:hover { text-decoration: underline; }
.ct-breadcrumb-sep { color: #94a3b8; }
.ct-breadcrumb-cur { color: #475569; font-weight: 600; }

/* ── LOADING / ERROR ── */
.ct-loading { display: flex; align-items: center; justify-content: center; gap: 10px; padding: 60px; font-size: 14px; color: #64748b; }
.ct-spinner { width: 22px; height: 22px; border: 2.5px solid #e2e8f0; border-top-color: #3b82f6; border-radius: 50%; animation: spin .7s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }
.ct-spinner-sm { width: 14px; height: 14px; border: 2px solid #e2e8f0; border-top-color: #3b82f6; border-radius: 50%; animation: spin .7s linear infinite; }
.ct-loading-sm { display: flex; align-items: center; gap: 8px; padding: 20px; font-size: 13px; color: #64748b; }
.ct-error { background: #fef2f2; border: 1px solid #fecaca; border-radius: 10px; padding: 12px 16px; font-size: 13px; color: #dc2626; }

/* ── HERO ── */
.ct-hero {
  background: linear-gradient(135deg, #0f172a 0%, #1e3a8a 100%);
  border-radius: 16px; padding: 24px 28px;
  display: flex; align-items: flex-start; justify-content: space-between; gap: 20px;
  flex-wrap: wrap;
  box-shadow: 0 8px 24px rgba(15,23,42,.18);
}
.ct-hero-left { display: flex; align-items: flex-start; gap: 18px; flex: 1; min-width: 260px; }
.ct-big-avatar {
  flex-shrink: 0; width: 64px; height: 64px; border-radius: 50%;
  color: #fff; font-size: 26px; font-weight: 700;
  display: flex; align-items: center; justify-content: center;
  border: 3px solid rgba(255,255,255,.25);
}
.ct-hero-info { flex: 1; }
.ct-hero-name { margin: 0 0 6px; font-size: 22px; font-weight: 700; color: #fff; line-height: 1.2; }
.ct-hero-meta { display: flex; align-items: center; flex-wrap: wrap; gap: 8px; margin-bottom: 10px; }
.ct-masv-chip {
  display: inline-block; padding: 2px 8px;
  background: rgba(255,255,255,.15); border: 1px solid rgba(255,255,255,.2);
  border-radius: 6px; font-family: monospace; font-size: 12px; font-weight: 600; color: #fff;
}
.ct-dot { color: rgba(255,255,255,.4); }
.ct-email { font-size: 13px; color: #bfdbfe; }
.ct-status {
  display: inline-flex; align-items: center; gap: 4px;
  padding: 2px 8px; border-radius: 20px; font-size: 11.5px; font-weight: 600;
}
.tt-dh  { background: rgba(16,185,129,.2); color: #6ee7b7; }
.tt-bl  { background: rgba(245,158,11,.2); color: #fde68a; }
.tt-th  { background: rgba(239,68,68,.2);  color: #fca5a5; }
.tt-tn  { background: rgba(59,130,246,.2); color: #93c5fd; }
.ct-hero-ct { display: flex; align-items: center; flex-wrap: wrap; gap: 6px; }
.ct-tag-nganh, .ct-tag-ct, .ct-tag-ver {
  display: inline-block; padding: 3px 8px; border-radius: 6px;
  font-size: 11.5px; font-weight: 500;
}
.ct-tag-nganh { background: rgba(16,185,129,.15); color: #6ee7b7; border: 1px solid rgba(16,185,129,.2); }
.ct-tag-ct    { background: rgba(251,191,36,.15); color: #fde68a; border: 1px solid rgba(251,191,36,.2); }
.ct-tag-ver   { background: rgba(167,139,250,.15);color: #c4b5fd; border: 1px solid rgba(167,139,250,.2); }

/* ── STATS ── */
.ct-stats { display: flex; gap: 10px; flex-wrap: wrap; }
.ct-stat {
  background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.1);
  border-radius: 12px; padding: 14px 20px; text-align: center; min-width: 80px;
}
.ct-stat-val { font-size: 28px; font-weight: 700; line-height: 1; margin-bottom: 4px; }
.ct-stat-lbl { font-size: 11px; color: rgba(255,255,255,.5); text-transform: uppercase; letter-spacing: .05em; }
.ct-stat-blue  { color: #60a5fa; }
.ct-stat-green { color: #4ade80; }
.ct-stat-red   { color: #f87171; }
.ct-stat-gray  { color: #94a3b8; }

/* ── TABS ── */
.ct-tabs {
  display: flex; gap: 4px; padding: 6px;
  background: #fff; border: 1px solid #e2e8f0; border-radius: 12px;
  box-shadow: 0 1px 4px rgba(15,23,42,.04);
}
.ct-tab {
  display: inline-flex; align-items: center; gap: 6px;
  height: 36px; padding: 0 14px;
  background: transparent; border: 1px solid transparent; border-radius: 8px;
  font-size: 13px; font-weight: 600; color: #64748b; cursor: pointer;
  transition: all .14s;
}
.ct-tab:hover { background: #f8fafc; }
.ct-tab.active { background: #eff6ff; border-color: #bfdbfe; color: #1d4ed8; }
.ct-tab-count {
  display: inline-flex; align-items: center; justify-content: center;
  min-width: 20px; height: 18px; padding: 0 5px;
  background: #e2e8f0; border-radius: 10px; font-size: 11px; font-weight: 700; color: #64748b;
}
.ct-tab.active .ct-tab-count { background: #bfdbfe; color: #1d4ed8; }

/* ── TAB PANEL ── */
.ct-tab-panel { animation: fadeIn .2s ease; }
@keyframes fadeIn { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: none; } }

/* ── SECTION ── */
.ct-section-grid {
  display: grid; grid-template-columns: 1fr 1fr; gap: 14px;
}
.ct-section {
  background: #fff; border: 1px solid #e2e8f0; border-radius: 14px; padding: 18px 20px;
  box-shadow: 0 1px 4px rgba(15,23,42,.04);
}
.ct-section-full { grid-column: 1 / -1; }
.ct-section-title {
  font-size: 12px; font-weight: 700; color: #64748b;
  text-transform: uppercase; letter-spacing: .06em; margin-bottom: 14px;
  padding-bottom: 8px; border-bottom: 1px solid #f1f5f9;
}
.ct-info-grid { display: flex; flex-direction: column; gap: 8px; }
.ct-info-row { display: flex; gap: 12px; }
.ct-info-lbl { flex-shrink: 0; width: 140px; font-size: 12px; color: #94a3b8; font-weight: 500; padding-top: 1px; }
.ct-info-val { flex: 1; font-size: 13px; color: #1e293b; font-weight: 500; line-height: 1.4; word-break: break-word; }
.ct-mono { font-family: 'Courier New', monospace; }
.ct-ghi-chu { margin: 0; font-size: 13px; color: #475569; line-height: 1.6; white-space: pre-wrap; }

.ct-family-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 14px; }
.ct-family-block { background: #f8fafc; border-radius: 10px; padding: 12px 14px; }
.ct-family-head { font-size: 12px; font-weight: 700; color: #334155; margin-bottom: 10px; }

/* ── TABLE CARD ── */
.ct-table-card { background: #fff; border: 1px solid #e2e8f0; border-radius: 14px; overflow: hidden; box-shadow: 0 1px 4px rgba(15,23,42,.04); }
.ct-table-wrap { overflow-x: auto; }
.ct-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.ct-table thead tr { background: #f8fafc; }
.ct-table th { padding: 9px 14px; text-align: left; font-size: 11px; font-weight: 700; color: #94a3b8; text-transform: uppercase; letter-spacing: .05em; border-bottom: 1px solid #e2e8f0; white-space: nowrap; }
.ct-table td { padding: 11px 14px; color: #1e293b; border-bottom: 1px solid #f1f5f9; vertical-align: middle; }
.ct-table-row:last-child td { border-bottom: none; }
.ct-table-row:hover td { background: #f8fafc; }
.td-center { text-align: center; }
.td-muted  { color: #64748b; }
.td-bold   { font-weight: 600; }
.lh-noidung { max-width: 200px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

.ct-ma-chip { display: inline-block; padding: 2px 7px; background: #f1f5f9; border: 1px solid #e2e8f0; border-radius: 5px; font-family: monospace; font-size: 12px; font-weight: 600; color: #334155; }
.ct-diem { display: inline-block; padding: 2px 8px; border-radius: 6px; font-size: 13px; font-weight: 700; }
.diem-tot  { background: #dcfce7; color: #15803d; }
.diem-tb   { background: #fef9c3; color: #92400e; }
.diem-yeu  { background: #fee2e2; color: #b91c1c; }
.ct-ketqua { display: inline-block; padding: 2px 8px; border-radius: 6px; font-size: 12px; font-weight: 600; }
.kq-dat        { background: #dcfce7; color: #15803d; }
.kq-khong-dat  { background: #fee2e2; color: #b91c1c; }
.ct-hoc-lai-tag { display: inline-block; padding: 2px 7px; background: #fef9c3; border: 1px solid #fde68a; border-radius: 5px; font-size: 11px; font-weight: 600; color: #92400e; }

.ct-mon-status { display: inline-flex; align-items: center; padding: 3px 8px; border-radius: 20px; font-size: 11.5px; font-weight: 600; }
.ms-ddk { background: #f1f5f9; color: #475569; }
.ms-dh  { background: #eff6ff; color: #1d4ed8; }
.ms-ht  { background: #dcfce7; color: #15803d; }
.ms-rot { background: #fee2e2; color: #b91c1c; }
.ms-huy { background: #f1f5f9; color: #94a3b8; }
.ms-hl  { background: #fef9c3; color: #92400e; }

/* ── LỊCH HỌC ── */
.ct-lh-toolbar { display: flex; align-items: center; gap: 10px; margin-bottom: 12px; }
.ct-label-inline { display: flex; align-items: center; gap: 8px; font-size: 13px; font-weight: 600; color: #475569; }
.ct-select-sm { height: 34px; padding: 0 10px; border: 1px solid #e2e8f0; border-radius: 8px; font-size: 13px; color: #1e293b; background: #f8fafc; min-width: 260px; }
.ct-lh-status { display: inline-flex; align-items: center; padding: 3px 8px; border-radius: 20px; font-size: 11.5px; font-weight: 600; }
.lhs-dd { background: #dcfce7; color: #15803d; }
.lhs-cd { background: #f1f5f9; color: #64748b; }
.lhs-v  { background: #fef9c3; color: #92400e; }
.lhs-h  { background: #fee2e2; color: #b91c1c; }

.ct-empty-hint { display: flex; flex-direction: column; align-items: center; gap: 10px; padding: 48px; background: #fff; border: 1px dashed #bfdbfe; border-radius: 14px; color: #94a3b8; text-align: center; }
.ct-empty-hint p { margin: 0; font-size: 13px; }
.ct-empty { text-align: center; padding: 36px !important; color: #94a3b8; font-size: 13px; }

@media (max-width: 768px) {
  .ct-hero { flex-direction: column; }
  .ct-section-grid { grid-template-columns: 1fr; }
  .ct-stats { justify-content: stretch; }
  .ct-stat { flex: 1; }
}
</style>
