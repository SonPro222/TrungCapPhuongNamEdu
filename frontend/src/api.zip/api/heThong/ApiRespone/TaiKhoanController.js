import apiClient from '../../apiConfig';

const ENDPOINT = '/api/he-thong/tai-khoan';

export const getAllTaiKhoan = (params = {}) => apiClient.get(ENDPOINT, { params });
export const getTaiKhoanById = (id) => apiClient.get(`${ENDPOINT}/${id}`);

export default { getAllTaiKhoan, getTaiKhoanById };
