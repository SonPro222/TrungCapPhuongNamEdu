<template>
  <section class="module-layout">
    <aside class="module-menu">
      <div class="menu-head">
        <h2>Hệ thống</h2>
        <p>Quản lý tài khoản, vai trò, quyền và phân quyền</p>
      </div>

      <RouterLink :to="{ name: 'he-thong-quan-ly-tai-khoan' }">
        Tài khoản & phân quyền
      </RouterLink>
    </aside>

    <main class="module-content">
      <RouterView />
    </main>
  </section>
</template>

<script setup>
import { RouterLink, RouterView } from 'vue-router';
</script>