<template>
  <section class="page-wrap">
    <header class="page-header">
      <div>
        <h1>Quản lý tài khoản và phân quyền</h1>
        <p>Quản lý tài khoản, sinh viên, giảng viên, nhân viên, vai trò, quyền và liên kết phân quyền.</p>
      </div>

      <button class="btn btn-secondary btn-sm" type="button" @click="loadAll">Tải lại</button>
    </header>

    <nav class="tabs">
      <button
          v-for="tab in tabs"
          :key="tab.key"
          type="button"
          :class="['tab', { active: activeTab === tab.key }]"
          @click="changeTab(tab.key)"
      >
        {{ tab.label }}
      </button>
    </nav>

    <div v-if="error" class="alert">{{ error }}</div>

    <section v-show="activeTab === 'taiKhoan'" class="stack">
      <FilterBar
          :filters="accountFilters"
          :filter-state="filters.taiKhoan"
          @search="loadTaiKhoan"
          @reset="resetTaiKhoanFilter"
          @change="loadTaiKhoan"
      />

      <DataTable
          title="Tài khoản"
          :columns="accountColumns"
          :items="taiKhoanViewItems"
          :loading="loading.taiKhoan"
          @edit="editTaiKhoan"
          @remove="deleteTaiKhoan"
      />
    </section>

    <section v-show="activeTab === 'sinhVien'" class="stack">
      <FilterBar
          :filters="studentFilters"
          :filter-state="filters.sinhVien"
          @search="loadSinhVien"
          @reset="resetSinhVienFilter"
          @change="loadSinhVien"
      />

      <DataTable
          title="Tài khoản sinh viên"
          :columns="studentColumns"
          :items="sinhVienItems"
          :loading="loading.sinhVien"
          @edit="editSinhVien"
          @remove="deleteSinhVien"
      />

      <PaginationBar
          :page="pagination.sinhVien.page"
          :size="pagination.sinhVien.size"
          :total-pages="pagination.sinhVien.totalPages"
          :total-elements="pagination.sinhVien.totalElements"
          @change-page="changeSinhVienPage"
          @change-size="changeSinhVienSize"
      />
    </section>

    <section v-show="activeTab === 'giaoVien'" class="stack">
      <FilterBar
          :filters="teacherFilters"
          :filter-state="filters.giaoVien"
          @search="loadGiaoVien"
          @reset="resetGiaoVienFilter"
          @change="loadGiaoVien"
      />

      <DataTable
          title="Tài khoản giảng viên"
          :columns="teacherColumns"
          :items="giaoVienItems"
          :loading="loading.giaoVien"
          @edit="editGiaoVien"
          @remove="deleteGiaoVien"
      />
    </section>

    <section v-show="activeTab === 'nhanVien'" class="stack">
      <FilterBar
          :filters="staffFilters"
          :filter-state="filters.nhanVien"
          @search="loadNhanVien"
          @reset="resetNhanVienFilter"
          @change="loadNhanVien"
      />

      <DataTable
          title="Tài khoản nhân viên, đào tạo và admin"
          :columns="staffColumns"
          :items="nhanVienItems"
          :loading="loading.nhanVien"
          @edit="editNhanVien"
          @remove="deleteNhanVien"
      />
    </section>

    <section v-show="activeTab === 'vaiTroQuyen'" class="stack">
      <div class="grid-2">
        <div class="stack">
          <FilterBar
              :filters="roleFilters"
              :filter-state="filters.vaiTro"
              @search="loadVaiTro"
              @reset="resetVaiTroFilter"
              @change="loadVaiTro"
          />

          <DataTable
              title="Vai trò"
              :columns="roleColumns"
              :items="vaiTroItems"
              :loading="loading.vaiTro"
              @edit="editVaiTro"
              @remove="deleteVaiTro"
          />
        </div>

        <div class="stack">
          <FilterBar
              :filters="permissionFilters"
              :filter-state="filters.quyen"
              @search="loadQuyen"
              @reset="resetQuyenFilter"
              @change="loadQuyen"
          />

          <DataTable
              title="Quyền"
              :columns="permissionColumns"
              :items="quyenItems"
              :loading="loading.quyen"
              @edit="editQuyen"
              @remove="deleteQuyen"
          />
        </div>
      </div>
    </section>

    <section v-show="activeTab === 'lienKet'" class="stack">
      <div class="grid-2">
        <div class="stack">
          <FilterBar
              :filters="accountRoleFilters"
              :filter-state="filters.taiKhoanVaiTro"
              @search="loadTaiKhoanVaiTro"
              @reset="resetTaiKhoanVaiTroFilter"
              @change="loadTaiKhoanVaiTro"
          />

          <DataTable
              title="Tài khoản vai trò"
              :columns="accountRoleColumns"
              :items="taiKhoanVaiTroViewItems"
              :loading="loading.taiKhoanVaiTro"
              @edit="editTaiKhoanVaiTro"
              @remove="deleteTaiKhoanVaiTro"
          />
        </div>

        <div class="stack">
          <FilterBar
              :filters="rolePermissionFilters"
              :filter-state="filters.vaiTroQuyen"
              @search="loadVaiTroQuyen"
              @reset="resetVaiTroQuyenFilter"
              @change="loadVaiTroQuyen"
          />

          <DataTable
              title="Vai trò quyền"
              :columns="rolePermissionColumns"
              :items="vaiTroQuyenViewItems"
              :loading="loading.vaiTroQuyen"
              @edit="editVaiTroQuyen"
              @remove="deleteVaiTroQuyen"
          />
        </div>
      </div>
    </section>
  </section>
</template>

<script setup>
import { computed, defineComponent, h, onMounted, reactive, ref } from 'vue';

import { getAllTaiKhoan } from '@/api/heThong/ApiRespone/TaiKhoanController.js';
import { getAllNhanVien } from '@/api/heThong/ApiRespone/NhanVienController.js';
import { getAllVaiTro } from '@/api/heThong/ApiRespone/VaiTroController.js';
import { getAllQuyen } from '@/api/heThong/ApiRespone/QuyenController.js';
import { getAllTaiKhoanVaiTro } from '@/api/heThong/ApiRespone/TaiKhoanVaiTroController.js';
import { getAllVaiTroQuyen } from '@/api/heThong/ApiRespone/VaiTroQuyenController.js';

import { getPageSinhVien } from '@/api/sinhVien/response/fetchResponse_SinhVien.js';
import { getAllGiaoVien } from '@/api/giangDay/response/fetchResponse_GiaoVien.js';
import { getAllSinhVienChuongTrinh } from '@/api/sinhVien/response/fetchResponse_SinhVienChuongTrinh.js';

const activeTab = ref('taiKhoan');
const error = ref('');

const tabs = [
  { key: 'taiKhoan', label: 'Tài khoản' },
  { key: 'sinhVien', label: 'Sinh viên' },
  { key: 'giaoVien', label: 'Giảng viên' },
  { key: 'nhanVien', label: 'Nhân viên / Đào tạo / Admin' },
  { key: 'vaiTroQuyen', label: 'Vai trò / Quyền' },
  { key: 'lienKet', label: 'Liên kết phân quyền' },
];

const loading = reactive({
  taiKhoan: false,
  sinhVien: false,
  giaoVien: false,
  nhanVien: false,
  vaiTro: false,
  quyen: false,
  taiKhoanVaiTro: false,
  vaiTroQuyen: false,
});

const pagination = reactive({
  sinhVien: {
    page: 0,
    size: 10,
    totalPages: 0,
    totalElements: 0,
  },
});

const filters = reactive({
  taiKhoan: { keyword: '', loaiTaiKhoan: '', trangThai: '', vaiTroId: '', page: 0, size: 20 },
  sinhVien: { keyword: '', namDangKy: '', trangThai: '', lopHanhChinhId: '', page: 0, size: 10 },
  giaoVien: { keyword: '', namBatDau: '', trangThai: '', chuyenMon: '', page: 0, size: 20 },
  nhanVien: { keyword: '', namBatDau: '', phongBan: '', chucVu: '', trangThai: '', page: 0, size: 20 },
  vaiTro: { keyword: '', maVaiTro: '', page: 0, size: 20 },
  quyen: { keyword: '', maQuyen: '', page: 0, size: 20 },
  taiKhoanVaiTro: { taiKhoanId: '', vaiTroId: '', keyword: '', page: 0, size: 20 },
  vaiTroQuyen: { vaiTroId: '', quyenId: '', keyword: '', page: 0, size: 20 },
});

const taiKhoanItems = ref([]);
const sinhVienRawItems = ref([]);
const sinhVienChuongTrinhItems = ref([]);
const giaoVienRawItems = ref([]);
const nhanVienRawItems = ref([]);
const vaiTroItems = ref([]);
const quyenItems = ref([]);
const taiKhoanVaiTroItems = ref([]);
const vaiTroQuyenItems = ref([]);

const accountFilters = [
  { key: 'keyword', label: 'Từ khóa', type: 'text' },
  {
    key: 'loaiTaiKhoan',
    label: 'Loại tài khoản',
    type: 'select',
    options: [
      { value: '', label: 'Tất cả' },
      { value: 'sinh_vien', label: 'Sinh viên' },
      { value: 'giao_vien', label: 'Giảng viên' },
      { value: 'nhan_vien', label: 'Nhân viên' },
      { value: 'dao_tao', label: 'Đào tạo' },
      { value: 'admin', label: 'Admin' },
    ],
  },
  {
    key: 'trangThai',
    label: 'Trạng thái',
    type: 'select',
    options: [
      { value: '', label: 'Tất cả' },
      { value: 'cho_kich_hoat', label: 'Chờ kích hoạt' },
      { value: 'da_kich_hoat', label: 'Đã kích hoạt' },
      { value: 'bi_khoa', label: 'Bị khóa' },
    ],
  },
  { key: 'vaiTroId', label: 'ID vai trò', type: 'number' },
];

const studentFilters = [
  { key: 'keyword', label: 'Từ khóa', type: 'text' },
  { key: 'namDangKy', label: 'Năm đăng ký học', type: 'number' },
  {
    key: 'trangThai',
    label: 'Trạng thái',
    type: 'select',
    options: [
      { value: '', label: 'Tất cả' },
      { value: 'dang_hoc', label: 'Đang học' },
      { value: 'bao_luu', label: 'Bảo lưu' },
      { value: 'nghi_hoc', label: 'Nghỉ học' },
      { value: 'tot_nghiep', label: 'Tốt nghiệp' },
    ],
  },
  { key: 'lopHanhChinhId', label: 'ID lớp hành chính', type: 'number' },
];

const teacherFilters = [
  { key: 'keyword', label: 'Từ khóa', type: 'text' },
  { key: 'namBatDau', label: 'Năm bắt đầu làm', type: 'number' },
  {
    key: 'trangThai',
    label: 'Trạng thái',
    type: 'select',
    options: [
      { value: '', label: 'Tất cả' },
      { value: 'dang_day', label: 'Đang dạy' },
      { value: 'tam_nghi', label: 'Tạm nghỉ' },
      { value: 'nghi_viec', label: 'Nghỉ việc' },
    ],
  },
  { key: 'chuyenMon', label: 'Chuyên môn', type: 'text' },
];

const staffFilters = [
  { key: 'keyword', label: 'Từ khóa', type: 'text' },
  { key: 'namBatDau', label: 'Năm bắt đầu làm', type: 'number' },
  { key: 'phongBan', label: 'Phòng ban', type: 'text' },
  { key: 'chucVu', label: 'Chức vụ', type: 'text' },
  {
    key: 'trangThai',
    label: 'Trạng thái',
    type: 'select',
    options: [
      { value: '', label: 'Tất cả' },
      { value: 'dang_lam', label: 'Đang làm' },
      { value: 'tam_nghi', label: 'Tạm nghỉ' },
      { value: 'nghi_viec', label: 'Nghỉ việc' },
    ],
  },
];

const roleFilters = [
  { key: 'keyword', label: 'Từ khóa vai trò', type: 'text' },
  { key: 'maVaiTro', label: 'Mã vai trò', type: 'text' },
];

const permissionFilters = [
  { key: 'keyword', label: 'Từ khóa quyền', type: 'text' },
  { key: 'maQuyen', label: 'Mã quyền', type: 'text' },
];

const accountRoleFilters = [
  { key: 'keyword', label: 'Từ khóa', type: 'text' },
  { key: 'taiKhoanId', label: 'ID tài khoản', type: 'number' },
  { key: 'vaiTroId', label: 'ID vai trò', type: 'number' },
];

const rolePermissionFilters = [
  { key: 'keyword', label: 'Từ khóa', type: 'text' },
  { key: 'vaiTroId', label: 'ID vai trò', type: 'number' },
  { key: 'quyenId', label: 'ID quyền', type: 'number' },
];

const accountColumns = [
  { key: 'id', label: 'ID', width: '70px' },
  { key: 'email', label: 'Email', width: '230px' },
  { key: 'loaiTaiKhoanText', label: 'Loại tài khoản', width: '140px' },
  { key: 'trangThaiText', label: 'Trạng thái', width: '140px', badge: true },
  { key: 'tenVaiTro', label: 'Vai trò', width: '220px' },
  { key: 'tenQuyen', label: 'Quyền', width: '260px' },
  { key: 'lanDangNhapCuoi', label: 'Lần đăng nhập cuối', width: '180px' },
];

const studentColumns = [
  { key: 'id', label: 'ID', width: '70px' },
  { key: 'maSinhVien', label: 'Mã sinh viên', width: '140px' },
  { key: 'hoTen', label: 'Họ tên', width: '200px' },
  { key: 'email', label: 'Email', width: '230px' },
  { key: 'soDienThoai', label: 'Số điện thoại', width: '140px' },
  { key: 'namDangKy', label: 'Năm đăng ký', width: '130px' },
  { key: 'lopHanhChinhId', label: 'Lớp HC', width: '100px' },
  { key: 'chuongTrinhVersionId', label: 'Phiên bản CT', width: '130px' },
  { key: 'trangThaiText', label: 'Trạng thái', width: '140px', badge: true },
  { key: 'taiKhoanId', label: 'Tài khoản', width: '100px' },
];

const teacherColumns = [
  { key: 'id', label: 'ID', width: '70px' },
  { key: 'maGiaoVien', label: 'Mã giảng viên', width: '140px' },
  { key: 'hoTen', label: 'Họ tên', width: '200px' },
  { key: 'email', label: 'Email', width: '230px' },
  { key: 'soDienThoai', label: 'Số điện thoại', width: '140px' },
  { key: 'chuyenMon', label: 'Chuyên môn', width: '200px' },
  { key: 'namBatDau', label: 'Năm bắt đầu', width: '130px' },
  { key: 'trangThaiText', label: 'Trạng thái', width: '140px', badge: true },
  { key: 'taiKhoanId', label: 'Tài khoản', width: '100px' },
];

const staffColumns = [
  { key: 'id', label: 'ID', width: '70px' },
  { key: 'maNhanVien', label: 'Mã nhân viên', width: '140px' },
  { key: 'hoTen', label: 'Họ tên', width: '200px' },
  { key: 'email', label: 'Email', width: '230px' },
  { key: 'soDienThoai', label: 'Số điện thoại', width: '140px' },
  { key: 'phongBanText', label: 'Phòng ban', width: '180px' },
  { key: 'chucVu', label: 'Chức vụ', width: '160px' },
  { key: 'namBatDau', label: 'Năm bắt đầu', width: '130px' },
  { key: 'trangThaiText', label: 'Trạng thái', width: '140px', badge: true },
  { key: 'taiKhoanId', label: 'Tài khoản', width: '100px' },
];

const roleColumns = [
  { key: 'id', label: 'ID', width: '70px' },
  { key: 'maVaiTro', label: 'Mã vai trò', width: '150px' },
  { key: 'tenVaiTro', label: 'Tên vai trò', width: '220px' },
  { key: 'moTa', label: 'Mô tả', width: '300px' },
];

const permissionColumns = [
  { key: 'id', label: 'ID', width: '70px' },
  { key: 'maQuyen', label: 'Mã quyền', width: '160px' },
  { key: 'tenQuyen', label: 'Tên quyền', width: '240px' },
  { key: 'moTa', label: 'Mô tả', width: '300px' },
];

const accountRoleColumns = [
  { key: 'id', label: 'ID', width: '70px' },
  { key: 'taiKhoanId', label: 'ID tài khoản', width: '120px' },
  { key: 'email', label: 'Email', width: '230px' },
  { key: 'loaiTaiKhoanText', label: 'Loại tài khoản', width: '150px' },
  { key: 'vaiTroId', label: 'ID vai trò', width: '110px' },
  { key: 'tenVaiTro', label: 'Tên vai trò', width: '220px' },
];

const rolePermissionColumns = [
  { key: 'id', label: 'ID', width: '70px' },
  { key: 'vaiTroId', label: 'ID vai trò', width: '110px' },
  { key: 'tenVaiTro', label: 'Tên vai trò', width: '220px' },
  { key: 'quyenId', label: 'ID quyền', width: '110px' },
  { key: 'tenQuyen', label: 'Tên quyền', width: '240px' },
];

const labels = {
  sinh_vien: 'Sinh viên',
  giao_vien: 'Giảng viên',
  nhan_vien: 'Nhân viên',
  dao_tao: 'Đào tạo',
  admin: 'Admin',
  cho_kich_hoat: 'Chờ kích hoạt',
  da_kich_hoat: 'Đã kích hoạt',
  bi_khoa: 'Bị khóa',
  dang_hoc: 'Đang học',
  bao_luu: 'Bảo lưu',
  nghi_hoc: 'Nghỉ học',
  tot_nghiep: 'Tốt nghiệp',
  dang_day: 'Đang dạy',
  dang_lam: 'Đang làm',
  tam_nghi: 'Tạm nghỉ',
  nghi_viec: 'Nghỉ việc',
};

const unwrapBody = (response) => {
  const data = response?.data ?? response;
  return data?.data ?? data;
};

const unwrapList = (response) => {
  const body = unwrapBody(response);
  if (Array.isArray(body)) return body;
  if (Array.isArray(body?.content)) return body.content;
  if (Array.isArray(body?.items)) return body.items;
  if (Array.isArray(body?.result)) return body.result;
  return [];
};

const unwrapPage = (response) => {
  const body = unwrapBody(response);
  return {
    content: Array.isArray(body?.content) ? body.content : [],
    number: Number(body?.number ?? 0),
    size: Number(body?.size ?? filters.sinhVien.size),
    totalPages: Number(body?.totalPages ?? 0),
    totalElements: Number(body?.totalElements ?? 0),
  };
};

const cleanParams = (source) => Object.fromEntries(
    Object.entries(source).filter(([, value]) => value !== '' && value !== null && value !== undefined)
);

const containsText = (item, keyword) => {
  if (!keyword) return true;
  const text = Object.values(item).join(' ').toLowerCase();
  return text.includes(String(keyword).toLowerCase());
};

const sameNumber = (left, right) => {
  if (right === '' || right === null || right === undefined) return true;
  return Number(left) === Number(right);
};

const getYear = (value) => {
  if (!value) return '';
  const date = new Date(value);
  if (!Number.isNaN(date.getTime())) return date.getFullYear();
  const matched = String(value).match(/\d{4}/);
  return matched ? matched[0] : '';
};

const textLabel = (value) => labels[value] || value || '';

const roleIdsByAccount = computed(() => {
  const map = new Map();
  taiKhoanVaiTroItems.value.forEach((item) => {
    const key = Number(item.taiKhoanId);
    const values = map.get(key) || [];
    values.push(Number(item.vaiTroId));
    map.set(key, values);
  });
  return map;
});

const permissionIdsByRole = computed(() => {
  const map = new Map();
  vaiTroQuyenItems.value.forEach((item) => {
    const key = Number(item.vaiTroId);
    const values = map.get(key) || [];
    values.push(Number(item.quyenId));
    map.set(key, values);
  });
  return map;
});

const roleNameById = computed(() => Object.fromEntries(vaiTroItems.value.map((item) => [Number(item.id), item.tenVaiTro || item.maVaiTro || item.id])));
const permissionNameById = computed(() => Object.fromEntries(quyenItems.value.map((item) => [Number(item.id), item.tenQuyen || item.maQuyen || item.id])));
const accountById = computed(() => Object.fromEntries(taiKhoanItems.value.map((item) => [Number(item.id), item])));

const buildAccountView = (account) => {
  const roleIds = roleIdsByAccount.value.get(Number(account.id)) || [];
  const permissionIds = [...new Set(roleIds.flatMap((roleId) => permissionIdsByRole.value.get(Number(roleId)) || []))];

  return {
    ...account,
    loaiTaiKhoanText: textLabel(account.loaiTaiKhoan),
    trangThaiText: textLabel(account.trangThai),
    tenVaiTro: roleIds.map((id) => roleNameById.value[id]).filter(Boolean).join(', '),
    tenQuyen: permissionIds.map((id) => permissionNameById.value[id]).filter(Boolean).join(', '),
  };
};

const taiKhoanViewItems = computed(() => taiKhoanItems.value.map(buildAccountView));

const sinhVienItems = computed(() => sinhVienRawItems.value.map((student) => {
  const enrollment = sinhVienChuongTrinhItems.value.find((item) => Number(item.sinhVienId) === Number(student.id));

  return {
    ...student,
    namDangKy: student.namDangKy || getYear(enrollment?.ngayDangKy || enrollment?.ngayNhapHoc || student.createdAt),
    lopHanhChinhId: student.lopHanhChinhId || enrollment?.lopHanhChinhId || '',
    chuongTrinhVersionId: student.chuongTrinhVersionId || enrollment?.chuongTrinhVersionId || '',
    trangThaiText: textLabel(student.trangThai),
  };
}));

const giaoVienItems = computed(() => giaoVienRawItems.value.map((teacher) => ({
  ...teacher,
  namBatDau: teacher.namBatDau || getYear(teacher.ngayVaoLam || teacher.createdAt),
  trangThaiText: textLabel(teacher.trangThai),
})).filter((item) => {
  const filter = filters.giaoVien;
  return containsText(item, filter.keyword)
      && (!filter.namBatDau || Number(item.namBatDau) === Number(filter.namBatDau))
      && (!filter.trangThai || item.trangThai === filter.trangThai)
      && (!filter.chuyenMon || String(item.chuyenMon || '').toLowerCase().includes(String(filter.chuyenMon).toLowerCase()));
}));

const nhanVienItems = computed(() => nhanVienRawItems.value.map((staff) => ({
  ...staff,
  phongBanText: staff.phongBan || staff.tenPhongBan || staff.boPhan || '',
  namBatDau: staff.namBatDau || getYear(staff.ngayVaoLam || staff.createdAt),
  trangThaiText: textLabel(staff.trangThai),
})).filter((item) => {
  const filter = filters.nhanVien;
  return containsText(item, filter.keyword)
      && (!filter.namBatDau || Number(item.namBatDau) === Number(filter.namBatDau))
      && (!filter.phongBan || String(item.phongBanText || '').toLowerCase().includes(String(filter.phongBan).toLowerCase()))
      && (!filter.chucVu || String(item.chucVu || '').toLowerCase().includes(String(filter.chucVu).toLowerCase()))
      && (!filter.trangThai || item.trangThai === filter.trangThai);
}));

const taiKhoanVaiTroViewItems = computed(() => taiKhoanVaiTroItems.value.map((item) => {
  const account = accountById.value[Number(item.taiKhoanId)] || {};

  return {
    ...item,
    email: item.email || account.email || '',
    loaiTaiKhoanText: textLabel(account.loaiTaiKhoan),
    tenVaiTro: item.tenVaiTro || roleNameById.value[Number(item.vaiTroId)] || '',
  };
}).filter((item) => {
  const filter = filters.taiKhoanVaiTro;
  return containsText(item, filter.keyword)
      && sameNumber(item.taiKhoanId, filter.taiKhoanId)
      && sameNumber(item.vaiTroId, filter.vaiTroId);
}));

const vaiTroQuyenViewItems = computed(() => vaiTroQuyenItems.value.map((item) => ({
  ...item,
  tenVaiTro: item.tenVaiTro || roleNameById.value[Number(item.vaiTroId)] || '',
  tenQuyen: item.tenQuyen || permissionNameById.value[Number(item.quyenId)] || '',
})).filter((item) => {
  const filter = filters.vaiTroQuyen;
  return containsText(item, filter.keyword)
      && sameNumber(item.vaiTroId, filter.vaiTroId)
      && sameNumber(item.quyenId, filter.quyenId);
}));

const runLoad = async (key, callback, fallbackMessage) => {
  loading[key] = true;
  error.value = '';

  try {
    await callback();
  } catch (err) {
    error.value = err?.response?.data?.message || err?.message || fallbackMessage;
  } finally {
    loading[key] = false;
  }
};

const loadTaiKhoan = () => runLoad('taiKhoan', async () => {
  taiKhoanItems.value = unwrapList(await getAllTaiKhoan(cleanParams(filters.taiKhoan)));
}, 'Không tải được tài khoản');

const loadSinhVien = () => runLoad('sinhVien', async () => {
  filters.sinhVien.page = pagination.sinhVien.page;
  filters.sinhVien.size = pagination.sinhVien.size;

  const pageData = unwrapPage(await getPageSinhVien(cleanParams(filters.sinhVien)));

  sinhVienRawItems.value = pageData.content;
  pagination.sinhVien.page = pageData.number;
  pagination.sinhVien.size = pageData.size;
  pagination.sinhVien.totalPages = pageData.totalPages;
  pagination.sinhVien.totalElements = pageData.totalElements;

  sinhVienChuongTrinhItems.value = unwrapList(await getAllSinhVienChuongTrinh({ size: 1000 }));
}, 'Không tải được tài khoản sinh viên');

const loadGiaoVien = () => runLoad('giaoVien', async () => {
  giaoVienRawItems.value = unwrapList(await getAllGiaoVien(cleanParams(filters.giaoVien)));
}, 'Không tải được tài khoản giảng viên');

const loadNhanVien = () => runLoad('nhanVien', async () => {
  nhanVienRawItems.value = unwrapList(await getAllNhanVien(cleanParams(filters.nhanVien)));
}, 'Không tải được tài khoản nhân viên');

const loadVaiTro = () => runLoad('vaiTro', async () => {
  vaiTroItems.value = unwrapList(await getAllVaiTro(cleanParams(filters.vaiTro)));
}, 'Không tải được vai trò');

const loadQuyen = () => runLoad('quyen', async () => {
  quyenItems.value = unwrapList(await getAllQuyen(cleanParams(filters.quyen)));
}, 'Không tải được quyền');

const loadTaiKhoanVaiTro = () => runLoad('taiKhoanVaiTro', async () => {
  taiKhoanVaiTroItems.value = unwrapList(await getAllTaiKhoanVaiTro(cleanParams(filters.taiKhoanVaiTro)));
}, 'Không tải được tài khoản vai trò');

const loadVaiTroQuyen = () => runLoad('vaiTroQuyen', async () => {
  vaiTroQuyenItems.value = unwrapList(await getAllVaiTroQuyen(cleanParams(filters.vaiTroQuyen)));
}, 'Không tải được vai trò quyền');

const resetTaiKhoanFilter = () => {
  Object.assign(filters.taiKhoan, { keyword: '', loaiTaiKhoan: '', trangThai: '', vaiTroId: '', page: 0, size: 20 });
  loadTaiKhoan();
};

const resetSinhVienFilter = () => {
  Object.assign(filters.sinhVien, { keyword: '', namDangKy: '', trangThai: '', lopHanhChinhId: '', page: 0, size: 10 });
  pagination.sinhVien.page = 0;
  pagination.sinhVien.size = 10;
  loadSinhVien();
};

const resetGiaoVienFilter = () => {
  Object.assign(filters.giaoVien, { keyword: '', namBatDau: '', trangThai: '', chuyenMon: '', page: 0, size: 20 });
  loadGiaoVien();
};

const resetNhanVienFilter = () => {
  Object.assign(filters.nhanVien, { keyword: '', namBatDau: '', phongBan: '', chucVu: '', trangThai: '', page: 0, size: 20 });
  loadNhanVien();
};

const resetVaiTroFilter = () => {
  Object.assign(filters.vaiTro, { keyword: '', maVaiTro: '', page: 0, size: 20 });
  loadVaiTro();
};

const resetQuyenFilter = () => {
  Object.assign(filters.quyen, { keyword: '', maQuyen: '', page: 0, size: 20 });
  loadQuyen();
};

const resetTaiKhoanVaiTroFilter = () => {
  Object.assign(filters.taiKhoanVaiTro, { taiKhoanId: '', vaiTroId: '', keyword: '', page: 0, size: 20 });
  loadTaiKhoanVaiTro();
};

const resetVaiTroQuyenFilter = () => {
  Object.assign(filters.vaiTroQuyen, { vaiTroId: '', quyenId: '', keyword: '', page: 0, size: 20 });
  loadVaiTroQuyen();
};

const changeTab = (tab) => {
  activeTab.value = tab;
};

const changeSinhVienPage = (page) => {
  if (page < 0 || page >= pagination.sinhVien.totalPages) return;
  pagination.sinhVien.page = page;
  loadSinhVien();
};

const changeSinhVienSize = (size) => {
  pagination.sinhVien.page = 0;
  pagination.sinhVien.size = Number(size);
  loadSinhVien();
};

const loadAll = async () => {
  await Promise.all([
    loadTaiKhoan(),
    loadVaiTro(),
    loadQuyen(),
    loadTaiKhoanVaiTro(),
    loadVaiTroQuyen(),
    loadSinhVien(),
    loadGiaoVien(),
    loadNhanVien(),
  ]);
};

const editTaiKhoan = (item) => console.log('Cập nhật tài khoản', item);
const deleteTaiKhoan = (item) => console.log('Xóa tài khoản', item);
const editSinhVien = (item) => console.log('Cập nhật sinh viên', item);
const deleteSinhVien = (item) => console.log('Xóa sinh viên', item);
const editGiaoVien = (item) => console.log('Cập nhật giảng viên', item);
const deleteGiaoVien = (item) => console.log('Xóa giảng viên', item);
const editNhanVien = (item) => console.log('Cập nhật nhân viên', item);
const deleteNhanVien = (item) => console.log('Xóa nhân viên', item);
const editVaiTro = (item) => console.log('Cập nhật vai trò', item);
const deleteVaiTro = (item) => console.log('Xóa vai trò', item);
const editQuyen = (item) => console.log('Cập nhật quyền', item);
const deleteQuyen = (item) => console.log('Xóa quyền', item);
const editTaiKhoanVaiTro = (item) => console.log('Cập nhật tài khoản vai trò', item);
const deleteTaiKhoanVaiTro = (item) => console.log('Xóa tài khoản vai trò', item);
const editVaiTroQuyen = (item) => console.log('Cập nhật vai trò quyền', item);
const deleteVaiTroQuyen = (item) => console.log('Xóa vai trò quyền', item);

const formatValue = (value) => {
  if (Array.isArray(value)) return value.join(', ');
  if (value === true) return 'Có';
  if (value === false) return 'Không';
  return value ?? '';
};

const DataTable = defineComponent({
  props: {
    title: { type: String, required: true },
    columns: { type: Array, required: true },
    items: { type: Array, required: true },
    loading: { type: Boolean, default: false },
  },
  emits: ['edit', 'remove'],
  setup(props, { emit }) {
    return () => h('div', { class: 'card table-card' }, [
      h('div', { class: 'table-title' }, [
        h('div', [
          h('h2', props.title),
          h('p', `${props.items.length} dòng đang hiển thị`),
        ]),
      ]),

      props.loading
          ? h('div', { class: 'table-loading' }, 'Đang tải dữ liệu...')
          : h('div', { class: 'table-scroll' }, [
            h('table', [
              h('colgroup', [
                ...props.columns.map((column) => h('col', { style: { width: column.width || '160px' } })),
                h('col', { style: { width: '150px' } }),
              ]),
              h('thead', [
                h('tr', [
                  ...props.columns.map((column) => h('th', column.label)),
                  h('th', { class: 'action-th' }, 'Thao tác'),
                ]),
              ]),
              h('tbody', props.items.length
                  ? props.items.map((item) => h('tr', { key: `${props.title}-${item.id}` }, [
                    ...props.columns.map((column) => h('td', [
                      column.badge
                          ? h('span', { class: 'status-badge' }, formatValue(item[column.key]))
                          : h('span', { class: 'cell-text' }, formatValue(item[column.key])),
                    ])),
                    h('td', { class: 'actions-cell' }, [
                      h('button', { class: 'icon-btn edit', type: 'button', onClick: () => emit('edit', item) }, 'Sửa'),
                      h('button', { class: 'icon-btn danger', type: 'button', onClick: () => emit('remove', item) }, 'Xóa'),
                    ]),
                  ]))
                  : [
                    h('tr', [
                      h('td', { colspan: props.columns.length + 1, class: 'empty-cell' }, 'Chưa có dữ liệu'),
                    ]),
                  ]),
            ]),
          ]),
    ]);
  },
});

const FilterBar = defineComponent({
  props: {
    filters: { type: Array, required: true },
    filterState: { type: Object, required: true },
  },
  emits: ['search', 'reset', 'change'],
  setup(props, { emit }) {
    return () => h('form', {
      class: 'card filter-grid',
      onSubmit: (event) => {
        event.preventDefault();
        emit('search');
      },
    }, [
      ...props.filters.map((filter) => h('label', { class: 'filter-item' }, [
        h('span', filter.label),
        filter.type === 'select'
            ? h('select', {
              value: props.filterState[filter.key],
              onChange: (event) => {
                props.filterState[filter.key] = event.target.value;
                props.filterState.page = 0;
                emit('change');
              },
            }, filter.options.map((option) => h('option', { value: option.value }, option.label)))
            : h('input', {
              type: filter.type || 'text',
              value: props.filterState[filter.key],
              onInput: (event) => {
                props.filterState[filter.key] = event.target.value;
              },
            }),
      ])),
      h('div', { class: 'filter-actions' }, [
        h('button', { class: 'btn btn-primary btn-sm', type: 'submit' }, 'Lọc'),
        h('button', { class: 'btn btn-secondary btn-sm', type: 'button', onClick: () => emit('reset') }, 'Xóa lọc'),
      ]),
    ]);
  },
});

const PaginationBar = defineComponent({
  props: {
    page: { type: Number, required: true },
    size: { type: Number, required: true },
    totalPages: { type: Number, required: true },
    totalElements: { type: Number, required: true },
  },
  emits: ['change-page', 'change-size'],
  setup(props, { emit }) {
    return () => h('div', { class: 'pagination-card' }, [
      h('div', { class: 'pagination-info' }, [
        h('strong', `Tổng ${props.totalElements} sinh viên`),
        h('span', `Trang ${props.totalPages ? props.page + 1 : 0}/${props.totalPages}`),
      ]),
      h('div', { class: 'pagination-actions' }, [
        h('select', {
          value: props.size,
          onChange: (event) => emit('change-size', Number(event.target.value)),
        }, [
          h('option', { value: 10 }, '10 dòng'),
          h('option', { value: 20 }, '20 dòng'),
          h('option', { value: 50 }, '50 dòng'),
          h('option', { value: 100 }, '100 dòng'),
        ]),
        h('button', {
          class: 'btn btn-secondary btn-sm',
          type: 'button',
          disabled: props.page <= 0,
          onClick: () => emit('change-page', props.page - 1),
        }, 'Trước'),
        h('button', {
          class: 'btn btn-secondary btn-sm',
          type: 'button',
          disabled: props.page + 1 >= props.totalPages,
          onClick: () => emit('change-page', props.page + 1),
        }, 'Sau'),
      ]),
    ]);
  },
});

onMounted(loadAll);
</script>

<style scoped>
.page-wrap {
  width: 100%;
  min-height: 100%;
  padding: 20px;
  background: #eef3f9;
}

.page-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 14px;
}

.page-header h1 {
  margin: 0;
  color: #0f172a;
  font-size: 26px;
  font-weight: 900;
  letter-spacing: -0.03em;
}

.page-header p {
  margin: 6px 0 0;
  color: #64748b;
  font-size: 14px;
  font-weight: 600;
}

.tabs {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  padding: 8px;
  margin-bottom: 14px;
  background: #ffffff;
  border: 1px solid #dbe3ef;
  border-radius: 16px;
  box-shadow: 0 12px 30px rgba(15, 23, 42, 0.06);
}

.tab {
  border: 1px solid transparent;
  background: transparent;
  color: #475569;
  border-radius: 12px;
  padding: 9px 13px;
  font-size: 13px;
  font-weight: 800;
  cursor: pointer;
}

.tab:hover {
  background: #f1f5f9;
  color: #0f172a;
}

.tab.active {
  color: #ffffff;
  background: #2563eb;
  border-color: #2563eb;
  box-shadow: 0 8px 18px rgba(37, 99, 235, 0.22);
}

.stack {
  display: grid;
  gap: 14px;
}

.grid-2 {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 14px;
}

.card {
  min-width: 0;
  background: #ffffff;
  border: 1px solid #dbe3ef;
  border-radius: 16px;
  box-shadow: 0 12px 30px rgba(15, 23, 42, 0.06);
}

.filter-grid {
  display: grid;
  grid-template-columns: repeat(4, minmax(140px, 1fr)) auto;
  gap: 10px;
  align-items: end;
  padding: 12px;
}

.filter-item {
  display: flex;
  flex-direction: column;
  gap: 5px;
  color: #334155;
  font-size: 12px;
  font-weight: 800;
}

.filter-item input,
.filter-item select {
  width: 100%;
  height: 36px;
  border: 1px solid #cbd5e1;
  border-radius: 10px;
  padding: 7px 10px;
  outline: none;
  background: #ffffff;
  color: #0f172a;
  font-size: 13px;
  font-weight: 600;
}

.filter-item input:focus,
.filter-item select:focus {
  border-color: #2563eb;
  box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.12);
}

.filter-actions {
  display: flex;
  gap: 8px;
  justify-content: flex-end;
}

.btn {
  border: 0;
  cursor: pointer;
  white-space: nowrap;
  font-weight: 850;
}

.btn-sm {
  min-height: 34px;
  border-radius: 10px;
  padding: 7px 11px;
  font-size: 12px;
}

.btn-primary {
  color: #ffffff;
  background: #2563eb;
}

.btn-primary:hover {
  background: #1d4ed8;
}

.btn-secondary {
  color: #334155;
  background: #ffffff;
  border: 1px solid #cbd5e1;
}

.btn-secondary:hover {
  background: #f8fafc;
}

.btn:disabled {
  cursor: not-allowed;
  opacity: 0.45;
}

.alert {
  margin-bottom: 14px;
  padding: 12px 14px;
  color: #b42318;
  background: #fef2f2;
  border: 1px solid #fecaca;
  border-radius: 14px;
  font-size: 13px;
  font-weight: 800;
}

.table-card {
  width: 100%;
  padding: 0;
  overflow: hidden;
}

.table-title {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 16px;
  border-bottom: 1px solid #e2e8f0;
  background: linear-gradient(180deg, #ffffff 0%, #f8fafc 100%);
}

.table-title h2 {
  margin: 0;
  color: #0f172a;
  font-size: 17px;
  font-weight: 900;
}

.table-title p {
  margin: 4px 0 0;
  color: #64748b;
  font-size: 12px;
  font-weight: 700;
}

.table-loading {
  padding: 22px;
  color: #64748b;
  font-size: 13px;
  font-weight: 800;
}

.table-scroll {
  width: 100%;
  max-width: 100%;
  overflow: auto;
}

table {
  width: 100%;
  min-width: 1200px;
  border-collapse: separate;
  border-spacing: 0;
  background: #ffffff;
}

thead th {
  position: sticky;
  top: 0;
  z-index: 1;
  height: 44px;
  padding: 10px 12px;
  color: #334155;
  background: #f1f5f9;
  border-bottom: 1px solid #cbd5e1;
  border-right: 1px solid #e2e8f0;
  text-align: left;
  font-size: 12px;
  font-weight: 900;
  white-space: nowrap;
}

tbody td {
  height: 46px;
  padding: 9px 12px;
  color: #1e293b;
  border-bottom: 1px solid #e2e8f0;
  border-right: 1px solid #edf2f7;
  vertical-align: middle;
  font-size: 13px;
  font-weight: 600;
}

tbody tr:nth-child(even) td {
  background: #fbfdff;
}

tbody tr:hover td {
  background: #eff6ff;
}

.cell-text {
  display: block;
  max-width: 360px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.status-badge {
  display: inline-flex;
  align-items: center;
  min-height: 26px;
  padding: 4px 9px;
  border-radius: 999px;
  color: #1d4ed8;
  background: #dbeafe;
  border: 1px solid #bfdbfe;
  font-size: 12px;
  font-weight: 900;
  white-space: nowrap;
}

.action-th {
  position: sticky;
  right: 0;
  z-index: 2;
  text-align: center;
}

.actions-cell {
  position: sticky;
  right: 0;
  z-index: 1;
  display: flex;
  justify-content: center;
  gap: 6px;
  background: inherit;
}

.icon-btn {
  border: 0;
  border-radius: 9px;
  padding: 6px 9px;
  cursor: pointer;
  font-size: 12px;
  font-weight: 900;
}

.icon-btn.edit {
  color: #1d4ed8;
  background: #dbeafe;
}

.icon-btn.edit:hover {
  background: #bfdbfe;
}

.icon-btn.danger {
  color: #b42318;
  background: #fee2e2;
}

.icon-btn.danger:hover {
  background: #fecaca;
}

.empty-cell {
  height: 80px;
  color: #64748b;
  text-align: center;
  font-weight: 800;
}

.pagination-card {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  padding: 12px 14px;
  background: #ffffff;
  border: 1px solid #dbe3ef;
  border-radius: 16px;
  box-shadow: 0 12px 30px rgba(15, 23, 42, 0.06);
}

.pagination-info {
  display: flex;
  flex-direction: column;
  gap: 3px;
  color: #334155;
  font-size: 13px;
}

.pagination-info span {
  color: #64748b;
  font-size: 12px;
  font-weight: 700;
}

.pagination-actions {
  display: flex;
  align-items: center;
  gap: 8px;
}

.pagination-actions select {
  height: 34px;
  border: 1px solid #cbd5e1;
  border-radius: 10px;
  padding: 6px 9px;
  color: #0f172a;
  background: #ffffff;
  font-size: 12px;
  font-weight: 800;
}

@media (max-width: 1280px) {
  .grid-2,
  .filter-grid {
    grid-template-columns: 1fr;
  }

  .filter-actions {
    justify-content: flex-start;
  }
}

@media (max-width: 720px) {
  .page-wrap {
    padding: 12px;
  }

  .page-header,
  .pagination-card {
    flex-direction: column;
    align-items: stretch;
  }

  .tabs {
    overflow-x: auto;
    flex-wrap: nowrap;
  }
}
</style>