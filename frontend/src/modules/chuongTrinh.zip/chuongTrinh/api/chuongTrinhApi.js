import apiClient from '@/core/api/apiClient'

const BASE_URL = '/chuongTrinh'

function createCrudApi(path) {
    return {
        getAll(params = {}) {
            return apiClient.get(`${BASE_URL}/${path}`, { params })
        },

        getById(id) {
            return apiClient.get(`${BASE_URL}/${path}/${id}`)
        },

        create(payload) {
            return apiClient.post(`${BASE_URL}/${path}`, payload)
        },

        update(id, payload) {
            return apiClient.put(`${BASE_URL}/${path}/${id}`, payload)
        },

        delete(id) {
            return apiClient.delete(`${BASE_URL}/${path}/${id}`)
        }
    }
}

export const chuongTrinhApi = {
    chuongTrinh: createCrudApi('chuong-trinh'),
    chuongTrinhVersion: createCrudApi('chuong-trinh-version'),
    chuongTrinhMon: createCrudApi('chuong-trinh-mon'),
    nhomKienThuc: createCrudApi('nhom-kien-thuc'),
    mucTieuChuongTrinh: createCrudApi('muc-tieu-chuong-trinh'),
    nangLucDauRa: createCrudApi('nang-luc-dau-ra'),
    viTriViecLam: createCrudApi('vi-tri-viec-lam'),
    dieuKienTotNghiep: createCrudApi('dieu-kien-tot-nghiep'),
    nhomTuChon: createCrudApi('nhom-tu-chon'),
    monTuChon: createCrudApi('mon-tu-chon'),
    monTienQuyet: createCrudApi('mon-tien-quyet'),

    // Dùng để chọn môn trong chuongTrinhMon, không tính là 1 trong 11 bảng chính.
    monHoc: createCrudApi('mon-hoc')
}