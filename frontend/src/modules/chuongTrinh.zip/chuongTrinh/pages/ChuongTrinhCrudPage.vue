<template>
  <div>
    <PageHeader :title="config.title" />

    <form class="module-filter" @submit.prevent="searchItems">
      <FormInput
          v-model="filters.keyword"
          label="Tìm kiếm"
          placeholder="Nhập từ khóa lọc"
      />

      <BaseButton
          type="submit"
          label="Lọc"
          variant="primary"
      />

      <BaseButton
          label="Tải lại"
          @click="loadPageData"
      />
    </form>

    <form class="module-form" @submit.prevent="handleSave">
      <FormSelect
          v-for="field in selectFields"
          :key="field.key"
          v-model="form[field.key]"
          :label="field.label"
          :placeholder="field.placeholder || `Chọn ${field.label.toLowerCase()}`"
          :options="lookupOptions[field.lookup] || []"
          :value-key="field.valueKey || 'id'"
          :label-key="field.labelKey"
          :required="field.required"
      />

      <FormInput
          v-for="field in inputFields"
          :key="field.key"
          v-model="form[field.key]"
          :type="field.type || 'text'"
          :label="field.label"
          :placeholder="`Nhập ${field.label.toLowerCase()}`"
          :required="field.required"
      />

      <BaseButton
          type="submit"
          variant="primary"
          :loading="saving"
          :label="editingId ? 'Cập nhật' : 'Thêm mới'"
      />

      <BaseButton
          label="Làm mới"
          @click="resetForm"
      />
    </form>

    <p v-if="errorMessage" class="error-text">
      {{ errorMessage }}
    </p>

    <DataTable
        :columns="config.columns"
        :items="items"
        :loading="loading"
    >
      <template #actions="{ item }">
        <BaseButton
            label="Sửa"
            @click="editItem(item)"
        />

        <BaseButton
            label="Xóa"
            variant="danger"
            @click="handleDelete(item.id)"
        />
      </template>
    </DataTable>
  </div>
</template>

<script setup>
import { computed, onMounted, reactive } from 'vue'
import { useRoute } from 'vue-router'

import PageHeader from '@/shared/components/PageHeader.vue'
import DataTable from '@/shared/components/DataTable.vue'
import FormInput from '@/shared/components/FormInput.vue'
import FormSelect from '@/shared/components/FormSelect.vue'
import BaseButton from '@/shared/components/BaseButton.vue'

import { daoTaoService } from '@/modules/daoTao/services/daoTaoService'
import { chuongTrinhCrudConfig } from '../config/chuongTrinhCrudConfig'
import { chuongTrinhService } from '../services/chuongTrinhService'
import { useChuongTrinhCrud } from '../composables/useChuongTrinhCrud'

const route = useRoute()

const entity = computed(() => route.meta.entity)
const config = computed(() => chuongTrinhCrudConfig[entity.value])

const lookupOptions = reactive({
  chuongTrinh: [],
  chuongTrinhVersion: [],
  chuongTrinhMon: [],
  nhomKienThuc: [],
  nhomTuChon: [],
  monHoc: [],
  khungKy: [],
  nganh: [],
  trinhDoDaoTao: [],
  loaiChuongTrinh: []
})

const {
  items,
  form,
  filters,
  loading,
  saving,
  errorMessage,
  editingId,
  fetchItems,
  searchItems,
  editItem,
  saveItem,
  deleteItem,
  resetForm
} = useChuongTrinhCrud(config.value.service, config.value.defaultForm)

const selectFields = computed(() => {
  return config.value.fields.filter((field) => field.type === 'select')
})

const inputFields = computed(() => {
  return config.value.fields.filter((field) => field.type !== 'select')
})

async function fetchLookupData() {
  const [
    chuongTrinhRes,
    versionRes,
    chuongTrinhMonRes,
    nhomKienThucRes,
    nhomTuChonRes,
    monHocRes,
    khungKyRes,
    nganhRes,
    trinhDoRes,
    loaiRes
  ] = await Promise.all([
    chuongTrinhService.chuongTrinh.getAll(),
    chuongTrinhService.chuongTrinhVersion.getAll(),
    chuongTrinhService.chuongTrinhMon.getAll(),
    chuongTrinhService.nhomKienThuc.getAll(),
    chuongTrinhService.nhomTuChon.getAll(),
    chuongTrinhService.monHoc.getAll(),
    daoTaoService.khungKy.getAll(),
    daoTaoService.nganh.getAll(),
    daoTaoService.trinhDoDaoTao.getAll(),
    daoTaoService.loaiChuongTrinh.getAll()
  ])

  lookupOptions.chuongTrinh = chuongTrinhRes.items
  lookupOptions.chuongTrinhVersion = versionRes.items
  lookupOptions.chuongTrinhMon = chuongTrinhMonRes.items
  lookupOptions.nhomKienThuc = nhomKienThucRes.items
  lookupOptions.nhomTuChon = nhomTuChonRes.items
  lookupOptions.monHoc = monHocRes.items
  lookupOptions.khungKy = khungKyRes.items
  lookupOptions.nganh = nganhRes.items
  lookupOptions.trinhDoDaoTao = trinhDoRes.items
  lookupOptions.loaiChuongTrinh = loaiRes.items
}

function findById(listName, id) {
  return lookupOptions[listName].find((item) => item.id === id)
}

function getChuongTrinhMonName(id) {
  const ctm = findById('chuongTrinhMon', id)
  if (!ctm) return id

  const mon = findById('monHoc', ctm.monHocId)

  return ctm.maMonTrongCt || mon?.tenMon || mon?.tenMonHoc || id
}

function enrichItems() {
  items.value = items.value.map((item) => {
    const chuongTrinh = findById('chuongTrinh', item.chuongTrinhId)
    const version = findById('chuongTrinhVersion', item.chuongTrinhVersionId)
    const mon = findById('monHoc', item.monHocId)
    const khungKy = findById('khungKy', item.khungKyId)
    const nhomKienThuc = findById('nhomKienThuc', item.nhomKienThucId)
    const nhomTuChon = findById('nhomTuChon', item.nhomId)

    const monTienQuyet = findById('chuongTrinhMon', item.monId)
    const monDieuKien = findById('chuongTrinhMon', item.monDieuKienId)

    const nganh = findById('nganh', item.nganhId)
    const trinhDo = findById('trinhDoDaoTao', item.trinhDoId)
    const loai = findById('loaiChuongTrinh', item.loaiChuongTrinhId)

    return {
      ...item,

      tenChuongTrinh: item.tenChuongTrinh || chuongTrinh?.tenChuongTrinh || item.chuongTrinhId,
      tenVersion: item.tenVersion || version?.tenVersion || item.chuongTrinhVersionId,

      tenMon: mon?.tenMon || mon?.tenMonHoc || item.monHocId,
      tenKy: khungKy?.tenKy || item.khungKyId,
      tenNhomKienThuc: nhomKienThuc?.ten || item.nhomKienThucId,

      tenNhomTuChon: nhomTuChon?.ten || item.nhomId,
      tenChuongTrinhMon: getChuongTrinhMonName(item.chuongTrinhMonId),

      tenMonTienQuyet: monTienQuyet
          ? getChuongTrinhMonName(monTienQuyet.id)
          : item.monId,

      tenMonDieuKien: monDieuKien
          ? getChuongTrinhMonName(monDieuKien.id)
          : item.monDieuKienId,

      tenNganh: nganh?.tenNganh || item.nganhId,
      tenTrinhDo: trinhDo?.tenTrinhDo || item.trinhDoId,
      tenLoaiChuongTrinh: loai?.tenLoai || item.loaiChuongTrinhId
    }
  })
}

async function loadPageData() {
  await fetchLookupData()
  await fetchItems()
  enrichItems()
}

async function handleSave() {
  await saveItem()
  await loadPageData()
}

async function handleDelete(id) {
  await deleteItem(id)
  await loadPageData()
}

onMounted(loadPageData)
</script>

<style scoped>
.module-filter {
  display: flex;
  gap: 12px;
  align-items: flex-end;
  margin-bottom: 16px;
}
</style>