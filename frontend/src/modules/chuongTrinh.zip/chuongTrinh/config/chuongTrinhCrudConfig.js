import { chuongTrinhService } from '../services/chuongTrinhService'

export const chuongTrinhCrudConfig = {
    chuongTrinh: {
        title: 'Chương trình',
        service: chuongTrinhService.chuongTrinh,
        defaultForm: {
            nganhId: null,
            trinhDoId: null,
            loaiChuongTrinhId: null,
            maChuongTrinh: '',
            tenChuongTrinh: '',
            doiTuongTuyenSinh: '',
            thoiGianDaoTao: ''
        },
        fields: [
            {
                key: 'nganhId',
                label: 'Ngành',
                type: 'select',
                lookup: 'nganh',
                labelKey: 'tenNganh',
                required: true
            },
            {
                key: 'trinhDoId',
                label: 'Trình độ',
                type: 'select',
                lookup: 'trinhDoDaoTao',
                labelKey: 'tenTrinhDo',
                required: true
            },
            {
                key: 'loaiChuongTrinhId',
                label: 'Loại chương trình',
                type: 'select',
                lookup: 'loaiChuongTrinh',
                labelKey: 'tenLoai',
                required: true
            },
            { key: 'maChuongTrinh', label: 'Mã chương trình', required: true },
            { key: 'tenChuongTrinh', label: 'Tên chương trình', required: true },
            { key: 'doiTuongTuyenSinh', label: 'Đối tượng tuyển sinh' },
            { key: 'thoiGianDaoTao', label: 'Thời gian đào tạo' }
        ],
        columns: [
            { key: 'maChuongTrinh', label: 'Mã CT' },
            { key: 'tenChuongTrinh', label: 'Tên CT' },
            { key: 'tenNganh', label: 'Ngành' },
            { key: 'tenTrinhDo', label: 'Trình độ' },
            { key: 'tenLoaiChuongTrinh', label: 'Loại chương trình' }
        ]
    },

    chuongTrinhVersion: {
        title: 'Phiên bản chương trình',
        service: chuongTrinhService.chuongTrinhVersion,
        defaultForm: {
            chuongTrinhId: null,
            maVersion: '',
            tenVersion: '',
            ngayApDung: '',
            ngayHetHieuLuc: '',
            soQuyetDinh: '',
            ngayQuyetDinh: '',
            nguoiKy: '',
            coQuanBanHanh: '',
            fileQuyetDinh: '',
            tongTinChi: null,
            tongSoGio: null,
            tongGioLyThuyet: null,
            tongGioThucHanh: null,
            tongGioKiemTra: null,
            laHienHanh: false
        },
        fields: [
            {
                key: 'chuongTrinhId',
                label: 'Chương trình',
                type: 'select',
                lookup: 'chuongTrinh',
                labelKey: 'tenChuongTrinh',
                required: true
            },
            { key: 'maVersion', label: 'Mã version', required: true },
            { key: 'tenVersion', label: 'Tên version', required: true },
            { key: 'ngayApDung', label: 'Ngày áp dụng', type: 'date' },
            { key: 'ngayHetHieuLuc', label: 'Ngày hết hiệu lực', type: 'date' },
            { key: 'soQuyetDinh', label: 'Số quyết định' },
            { key: 'ngayQuyetDinh', label: 'Ngày quyết định', type: 'date' },
            { key: 'nguoiKy', label: 'Người ký' },
            { key: 'coQuanBanHanh', label: 'Cơ quan ban hành' },
            { key: 'fileQuyetDinh', label: 'File quyết định' },
            { key: 'tongTinChi', label: 'Tổng tín chỉ', type: 'number' },
            { key: 'tongSoGio', label: 'Tổng số giờ', type: 'number' },
            { key: 'tongGioLyThuyet', label: 'Tổng giờ lý thuyết', type: 'number' },
            { key: 'tongGioThucHanh', label: 'Tổng giờ thực hành', type: 'number' },
            { key: 'tongGioKiemTra', label: 'Tổng giờ kiểm tra', type: 'number' }
        ],
        columns: [
            { key: 'maVersion', label: 'Mã version' },
            { key: 'tenVersion', label: 'Tên version' },
            { key: 'tenChuongTrinh', label: 'Chương trình' },
            { key: 'ngayApDung', label: 'Ngày áp dụng' },
            { key: 'tongTinChi', label: 'Tổng tín chỉ' }
        ]
    },

    chuongTrinhMon: {
        title: 'Môn trong chương trình',
        service: chuongTrinhService.chuongTrinhMon,
        defaultForm: {
            chuongTrinhVersionId: null,
            monHocId: null,
            maMonTrongCt: '',
            khungKyId: null,
            nhomKienThucId: null,
            loai: '',
            loaiHocPhan: '',
            batBuoc: true,
            laMonDieuKien: false,
            thuTu: null,
            soTinChi: null,
            tongGio: null,
            gioLyThuyet: null,
            gioThucHanh: null,
            gioKiemTra: null,
            ghiChu: ''
        },
        fields: [
            {
                key: 'chuongTrinhVersionId',
                label: 'Phiên bản chương trình',
                type: 'select',
                lookup: 'chuongTrinhVersion',
                labelKey: 'tenVersion',
                required: true
            },
            {
                key: 'monHocId',
                label: 'Môn học',
                type: 'select',
                lookup: 'monHoc',
                labelKey: 'tenMon',
                required: true
            },
            { key: 'maMonTrongCt', label: 'Mã môn trong CT' },
            {
                key: 'khungKyId',
                label: 'Khung kỳ',
                type: 'select',
                lookup: 'khungKy',
                labelKey: 'tenKy'
            },
            {
                key: 'nhomKienThucId',
                label: 'Nhóm kiến thức',
                type: 'select',
                lookup: 'nhomKienThuc',
                labelKey: 'ten'
            },
            { key: 'loai', label: 'Loại' },
            { key: 'loaiHocPhan', label: 'Loại học phần' },
            { key: 'thuTu', label: 'Thứ tự', type: 'number' },
            { key: 'soTinChi', label: 'Số tín chỉ', type: 'number' },
            { key: 'tongGio', label: 'Tổng giờ', type: 'number' },
            { key: 'gioLyThuyet', label: 'Giờ lý thuyết', type: 'number' },
            { key: 'gioThucHanh', label: 'Giờ thực hành', type: 'number' },
            { key: 'gioKiemTra', label: 'Giờ kiểm tra', type: 'number' },
            { key: 'ghiChu', label: 'Ghi chú' }
        ],
        columns: [
            { key: 'maMonTrongCt', label: 'Mã môn CT' },
            { key: 'tenVersion', label: 'Phiên bản' },
            { key: 'tenMon', label: 'Môn học' },
            { key: 'tenKy', label: 'Kỳ' },
            { key: 'tenNhomKienThuc', label: 'Nhóm kiến thức' },
            { key: 'soTinChi', label: 'Tín chỉ' },
            { key: 'tongGio', label: 'Tổng giờ' }
        ]
    },

    nhomKienThuc: {
        title: 'Nhóm kiến thức',
        service: chuongTrinhService.nhomKienThuc,
        defaultForm: {
            chuongTrinhVersionId: null,
            ma: '',
            ten: '',
            thuTu: null,
            loaiNhom: '',
            tongTinChi: null,
            tongSoGio: null,
            tongGioLyThuyet: null,
            tongGioThucHanh: null,
            tongGioKiemTra: null
        },
        fields: [
            {
                key: 'chuongTrinhVersionId',
                label: 'Phiên bản chương trình',
                type: 'select',
                lookup: 'chuongTrinhVersion',
                labelKey: 'tenVersion',
                required: true
            },
            { key: 'ma', label: 'Mã nhóm', required: true },
            { key: 'ten', label: 'Tên nhóm', required: true },
            { key: 'thuTu', label: 'Thứ tự', type: 'number' },
            { key: 'loaiNhom', label: 'Loại nhóm' },
            { key: 'tongTinChi', label: 'Tổng tín chỉ', type: 'number' },
            { key: 'tongSoGio', label: 'Tổng số giờ', type: 'number' }
        ],
        columns: [
            { key: 'ma', label: 'Mã' },
            { key: 'ten', label: 'Tên' },
            { key: 'tenVersion', label: 'Phiên bản' },
            { key: 'loaiNhom', label: 'Loại nhóm' },
            { key: 'tongTinChi', label: 'Tín chỉ' }
        ]
    },

    mucTieuChuongTrinh: {
        title: 'Mục tiêu chương trình',
        service: chuongTrinhService.mucTieuChuongTrinh,
        defaultForm: {
            chuongTrinhVersionId: null,
            loai: '',
            noiDung: '',
            thuTu: null
        },
        fields: [
            {
                key: 'chuongTrinhVersionId',
                label: 'Phiên bản chương trình',
                type: 'select',
                lookup: 'chuongTrinhVersion',
                labelKey: 'tenVersion',
                required: true
            },
            { key: 'loai', label: 'Loại' },
            { key: 'noiDung', label: 'Nội dung', required: true },
            { key: 'thuTu', label: 'Thứ tự', type: 'number' }
        ],
        columns: [
            { key: 'tenVersion', label: 'Phiên bản' },
            { key: 'loai', label: 'Loại' },
            { key: 'noiDung', label: 'Nội dung' },
            { key: 'thuTu', label: 'Thứ tự' }
        ]
    },

    nangLucDauRa: {
        title: 'Năng lực đầu ra',
        service: chuongTrinhService.nangLucDauRa,
        defaultForm: {
            chuongTrinhVersionId: null,
            ma: '',
            noiDung: '',
            loai: '',
            thuTu: null
        },
        fields: [
            {
                key: 'chuongTrinhVersionId',
                label: 'Phiên bản chương trình',
                type: 'select',
                lookup: 'chuongTrinhVersion',
                labelKey: 'tenVersion',
                required: true
            },
            { key: 'ma', label: 'Mã', required: true },
            { key: 'noiDung', label: 'Nội dung', required: true },
            { key: 'loai', label: 'Loại' },
            { key: 'thuTu', label: 'Thứ tự', type: 'number' }
        ],
        columns: [
            { key: 'tenVersion', label: 'Phiên bản' },
            { key: 'ma', label: 'Mã' },
            { key: 'noiDung', label: 'Nội dung' },
            { key: 'loai', label: 'Loại' },
            { key: 'thuTu', label: 'Thứ tự' }
        ]
    },

    viTriViecLam: {
        title: 'Vị trí việc làm',
        service: chuongTrinhService.viTriViecLam,
        defaultForm: {
            chuongTrinhVersionId: null,
            ten: '',
            moTa: '',
            thuTu: null
        },
        fields: [
            {
                key: 'chuongTrinhVersionId',
                label: 'Phiên bản chương trình',
                type: 'select',
                lookup: 'chuongTrinhVersion',
                labelKey: 'tenVersion',
                required: true
            },
            { key: 'ten', label: 'Tên vị trí', required: true },
            { key: 'moTa', label: 'Mô tả' },
            { key: 'thuTu', label: 'Thứ tự', type: 'number' }
        ],
        columns: [
            { key: 'tenVersion', label: 'Phiên bản' },
            { key: 'ten', label: 'Tên' },
            { key: 'moTa', label: 'Mô tả' },
            { key: 'thuTu', label: 'Thứ tự' }
        ]
    },

    dieuKienTotNghiep: {
        title: 'Điều kiện tốt nghiệp',
        service: chuongTrinhService.dieuKienTotNghiep,
        defaultForm: {
            chuongTrinhVersionId: null,
            noiDung: '',
            thuTu: null
        },
        fields: [
            {
                key: 'chuongTrinhVersionId',
                label: 'Phiên bản chương trình',
                type: 'select',
                lookup: 'chuongTrinhVersion',
                labelKey: 'tenVersion',
                required: true
            },
            { key: 'noiDung', label: 'Nội dung', required: true },
            { key: 'thuTu', label: 'Thứ tự', type: 'number' }
        ],
        columns: [
            { key: 'tenVersion', label: 'Phiên bản' },
            { key: 'noiDung', label: 'Nội dung' },
            { key: 'thuTu', label: 'Thứ tự' }
        ]
    },

    nhomTuChon: {
        title: 'Nhóm tự chọn',
        service: chuongTrinhService.nhomTuChon,
        defaultForm: {
            chuongTrinhVersionId: null,
            ten: '',
            soMonChon: null,
            soTinChiCanDat: null,
            ghiChu: ''
        },
        fields: [
            {
                key: 'chuongTrinhVersionId',
                label: 'Phiên bản chương trình',
                type: 'select',
                lookup: 'chuongTrinhVersion',
                labelKey: 'tenVersion',
                required: true
            },
            { key: 'ten', label: 'Tên nhóm', required: true },
            { key: 'soMonChon', label: 'Số môn chọn', type: 'number' },
            { key: 'soTinChiCanDat', label: 'Số tín chỉ cần đạt', type: 'number' },
            { key: 'ghiChu', label: 'Ghi chú' }
        ],
        columns: [
            { key: 'tenVersion', label: 'Phiên bản' },
            { key: 'ten', label: 'Tên nhóm' },
            { key: 'soMonChon', label: 'Số môn chọn' },
            { key: 'soTinChiCanDat', label: 'Tín chỉ cần đạt' },
            { key: 'ghiChu', label: 'Ghi chú' }
        ]
    },

    monTuChon: {
        title: 'Môn tự chọn',
        service: chuongTrinhService.monTuChon,
        defaultForm: {
            nhomId: null,
            chuongTrinhMonId: null
        },
        fields: [
            {
                key: 'nhomId',
                label: 'Nhóm tự chọn',
                type: 'select',
                lookup: 'nhomTuChon',
                labelKey: 'ten',
                required: true
            },
            {
                key: 'chuongTrinhMonId',
                label: 'Môn trong chương trình',
                type: 'select',
                lookup: 'chuongTrinhMon',
                labelKey: 'maMonTrongCt',
                required: true
            }
        ],
        columns: [
            { key: 'tenNhomTuChon', label: 'Nhóm tự chọn' },
            { key: 'tenChuongTrinhMon', label: 'Môn trong CT' }
        ]
    },

    monTienQuyet: {
        title: 'Môn tiên quyết',
        service: chuongTrinhService.monTienQuyet,
        defaultForm: {
            monId: null,
            monDieuKienId: null,
            loai: '',
            ghiChu: ''
        },
        fields: [
            {
                key: 'monId',
                label: 'Môn',
                type: 'select',
                lookup: 'chuongTrinhMon',
                labelKey: 'maMonTrongCt',
                required: true
            },
            {
                key: 'monDieuKienId',
                label: 'Môn điều kiện',
                type: 'select',
                lookup: 'chuongTrinhMon',
                labelKey: 'maMonTrongCt',
                required: true
            },
            { key: 'loai', label: 'Loại' },
            { key: 'ghiChu', label: 'Ghi chú' }
        ],
        columns: [
            { key: 'tenMonTienQuyet', label: 'Môn' },
            { key: 'tenMonDieuKien', label: 'Môn điều kiện' },
            { key: 'loai', label: 'Loại' },
            { key: 'ghiChu', label: 'Ghi chú' }
        ]
    }
}