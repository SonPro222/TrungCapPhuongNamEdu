import ChuongTrinhLayout from './layouts/ChuongTrinhLayout.vue'
import ChuongTrinhCrudPage from './pages/ChuongTrinhCrudPage.vue'

import { ROLES } from '@/core/constants/roles'
import { requireAuth } from '@/core/guards/authGuard'
import { requireAdmin } from '@/core/guards/adminGuard'

export const chuongTrinhRoutes = [
    {
        path: 'chuong-trinh',
        component: ChuongTrinhLayout,
        beforeEnter: [
            requireAuth,
            requireAdmin
        ],
        meta: {
            module: 'chuongTrinh',
            title: 'Chương trình',
            roles: [ROLES.ADMIN, ROLES.DAO_TAO]
        },
        children: [
            {
                path: '',
                name: 'ChuongTrinh.ChuongTrinh',
                component: ChuongTrinhCrudPage,
                meta: {
                    entity: 'chuongTrinh',
                    title: 'Chương trình'
                }
            },
            {
                path: 'version',
                name: 'ChuongTrinh.Version',
                component: ChuongTrinhCrudPage,
                meta: {
                    entity: 'chuongTrinhVersion',
                    title: 'Phiên bản chương trình'
                }
            },
            {
                path: 'mon',
                name: 'ChuongTrinh.Mon',
                component: ChuongTrinhCrudPage,
                meta: {
                    entity: 'chuongTrinhMon',
                    title: 'Môn trong chương trình'
                }
            },
            {
                path: 'nhom-kien-thuc',
                name: 'ChuongTrinh.NhomKienThuc',
                component: ChuongTrinhCrudPage,
                meta: {
                    entity: 'nhomKienThuc',
                    title: 'Nhóm kiến thức'
                }
            },
            {
                path: 'muc-tieu',
                name: 'ChuongTrinh.MucTieu',
                component: ChuongTrinhCrudPage,
                meta: {
                    entity: 'mucTieuChuongTrinh',
                    title: 'Mục tiêu chương trình'
                }
            },
            {
                path: 'nang-luc-dau-ra',
                name: 'ChuongTrinh.NangLucDauRa',
                component: ChuongTrinhCrudPage,
                meta: {
                    entity: 'nangLucDauRa',
                    title: 'Năng lực đầu ra'
                }
            },
            {
                path: 'vi-tri-viec-lam',
                name: 'ChuongTrinh.ViTriViecLam',
                component: ChuongTrinhCrudPage,
                meta: {
                    entity: 'viTriViecLam',
                    title: 'Vị trí việc làm'
                }
            },
            {
                path: 'dieu-kien-tot-nghiep',
                name: 'ChuongTrinh.DieuKienTotNghiep',
                component: ChuongTrinhCrudPage,
                meta: {
                    entity: 'dieuKienTotNghiep',
                    title: 'Điều kiện tốt nghiệp'
                }
            },
            {
                path: 'nhom-tu-chon',
                name: 'ChuongTrinh.NhomTuChon',
                component: ChuongTrinhCrudPage,
                meta: {
                    entity: 'nhomTuChon',
                    title: 'Nhóm tự chọn'
                }
            },
            {
                path: 'mon-tu-chon',
                name: 'ChuongTrinh.MonTuChon',
                component: ChuongTrinhCrudPage,
                meta: {
                    entity: 'monTuChon',
                    title: 'Môn tự chọn'
                }
            },
            {
                path: 'mon-tien-quyet',
                name: 'ChuongTrinh.MonTienQuyet',
                component: ChuongTrinhCrudPage,
                meta: {
                    entity: 'monTienQuyet',
                    title: 'Môn tiên quyết'
                }
            }
        ]
    }
]