<template>
  <div class="tang-page tang-nganh-page">
    <XemTomTatHuongDi tieu-de="Tầng 1 - Ngành" :danh-sach="summary" />

    <section class="tang-nganh-header">
      <p class="tang-label">Tầng 1</p>
      <h1 class="tang-title">Chọn ngành đào tạo</h1>
      <p class="tang-mo-ta">
        Bấm vào một ngành để xem chương trình đào tạo theo ngành đó.
      </p>
    </section>

    <XemTrangDangTai v-if="loading" />
    <p v-else-if="loi" class="loi-text">{{ loi }}</p>
    <XemTrangRong v-else-if="!danhSach.length" thong-bao="Chưa có ngành nào để hiển thị." />

    <div v-else class="nganh-grid-wrap">
      <div class="nganh-grid">
        <button
            v-for="(item, index) in danhSach"
            :key="item.id || index"
            type="button"
            class="nganh-card"
            :class="`nganh-card--mau-${index % 8}`"
            @click="moChuongTrinh(item)"
        >
          <span class="nganh-card__so">Ngành {{ index + 1 }}</span>
          <span class="nganh-card__ten">{{ layTenNganh(item) }}</span>
          <span class="nganh-card__xem">Xem chương trình →</span>
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { xemChuongTrinhService, layTenHienThi } from '../services/xemChuongTrinhService'
import XemTomTatHuongDi from '../components/XemTomTatHuongDi.vue'
import XemTrangRong from '../components/XemTrangRong.vue'
import XemTrangDangTai from '../components/XemTrangDangTai.vue'

const route = useRoute()
const router = useRouter()

const loading = ref(false)
const loi = ref('')
const danhSach = ref([])
const summary = ref([{ nhan: 'Tầng', giaTri: 'Ngành' }])

async function taiDuLieu() {
  loading.value = true
  loi.value = ''
  try {
    danhSach.value = await xemChuongTrinhService.layDanhSachNganh()
  } catch (error) {
    loi.value = error?.message || 'Không tải được danh sách ngành.'
  } finally {
    loading.value = false
  }
}

function layTenNganh(item) {
  return layTenHienThi(item, ['tenNganh', 'ten', 'maNganh'])
}

function moChuongTrinh(item) {
  router.push({
    name: 'XemChuongTrinh.Tang2ChuongTrinh',
    params: { ...route.params, nganhId: item.id }
  })
}

onMounted(taiDuLieu)
</script>

<style scoped>
.tang-page {
  min-height: calc(100vh - 80px);
  padding: 28px;
  background:
      radial-gradient(circle at top left, rgba(59, 130, 246, 0.12), transparent 30%),
      radial-gradient(circle at bottom right, rgba(168, 85, 247, 0.1), transparent 28%),
      #f8fafc;
}

.tang-nganh-page {
  display: flex;
  flex-direction: column;
}

.tang-nganh-header {
  max-width: 860px;
  margin: 10px auto 28px;
  text-align: center;
}

.tang-label {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  margin: 0 0 10px;
  padding: 7px 16px;
  border-radius: 999px;
  background: #e0f2fe;
  color: #0369a1;
  font-size: 15px;
  font-weight: 800;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}

.tang-title {
  margin: 0;
  font-size: 34px;
  line-height: 1.2;
  font-weight: 900;
  color: #0f172a;
}

.tang-mo-ta {
  margin: 12px auto 0;
  max-width: 620px;
  color: #64748b;
  font-size: 15px;
  line-height: 1.6;
}

.nganh-grid-wrap {
  display: flex;
  justify-content: center;
  width: 100%;
}

.nganh-grid {
  width: min(1120px, 100%);
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 18px;
}

.nganh-card {
  min-height: 145px;
  border: 0;
  border-radius: 22px;
  padding: 20px;
  text-align: left;
  color: #ffffff;
  cursor: pointer;
  box-shadow: 0 14px 30px rgba(15, 23, 42, 0.16);
  transition:
      transform 0.18s ease,
      box-shadow 0.18s ease,
      filter 0.18s ease;
}

.nganh-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 20px 42px rgba(15, 23, 42, 0.22);
  filter: brightness(1.04);
}

.nganh-card:active {
  transform: translateY(-1px);
}

.nganh-card__so {
  display: inline-flex;
  margin-bottom: 18px;
  padding: 5px 10px;
  border-radius: 999px;
  background: rgba(255, 255, 255, 0.22);
  color: rgba(255, 255, 255, 0.92);
  font-size: 12px;
  font-weight: 700;
}

.nganh-card__ten {
  display: block;
  min-height: 44px;
  color: #ffffff;
  font-size: 20px;
  line-height: 1.25;
  font-weight: 850;
}

.nganh-card__xem {
  display: block;
  margin-top: 18px;
  color: rgba(255, 255, 255, 0.92);
  font-size: 13px;
  font-weight: 700;
}

.nganh-card--mau-0 {
  background: linear-gradient(135deg, #2563eb, #06b6d4);
}

.nganh-card--mau-1 {
  background: linear-gradient(135deg, #7c3aed, #ec4899);
}

.nganh-card--mau-2 {
  background: linear-gradient(135deg, #059669, #22c55e);
}

.nganh-card--mau-3 {
  background: linear-gradient(135deg, #ea580c, #f59e0b);
}

.nganh-card--mau-4 {
  background: linear-gradient(135deg, #0891b2, #6366f1);
}

.nganh-card--mau-5 {
  background: linear-gradient(135deg, #be123c, #f43f5e);
}

.nganh-card--mau-6 {
  background: linear-gradient(135deg, #4338ca, #8b5cf6);
}

.nganh-card--mau-7 {
  background: linear-gradient(135deg, #0f766e, #14b8a6);
}

.loi-text {
  max-width: 760px;
  margin: 0 auto;
  padding: 14px 16px;
  border-radius: 12px;
  background: #fef2f2;
  color: #dc2626;
  font-size: 14px;
  font-weight: 600;
}

@media (max-width: 1100px) {
  .nganh-grid {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
}

@media (max-width: 820px) {
  .tang-page {
    padding: 18px;
  }

  .tang-title {
    font-size: 28px;
  }

  .nganh-grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}

@media (max-width: 520px) {
  .nganh-grid {
    grid-template-columns: 1fr;
  }
}
.tang-page {
  font-family: 'Roboto', Arial, sans-serif;
}
</style>