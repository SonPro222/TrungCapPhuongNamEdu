<template>
  <div class="syllabus-mon-hoc-goc-page">
    <section class="khoi-dau">
      <div>
        <h2>Quản lý syllabus môn học gốc</h2>
        <p>Mỗi môn học gốc chỉ có một syllabus gốc. Chọn môn là hiển thị form cập nhật ngay, không qua danh sách syllabus trung gian.</p>
      </div>
      <button type="button" class="nut" :disabled="dangTai" @click="taiDuLieuNen">Tải lại dữ liệu</button>
    </section>

    <section class="luoi-trang">
      <aside class="the cot-mon">
        <div class="tieu-de-the compact">
          <h3>Danh sách môn học gốc toàn trường</h3>
          <p>Chọn môn để cập nhật syllabus, chương/bài, điều kiện/đánh giá và tài liệu gốc.</p>
        </div>
        <ThongBaoKhuVuc :state="thongBaoKhuVuc.mon" />
        <div class="bo-loc">
          <input v-model.trim="tuKhoaMon" type="text" placeholder="Tìm mã môn hoặc tên môn">
        </div>
        <div class="danh-sach-mon">
          <button
              v-for="mon in danhSachMonLoc"
              :key="mon.id"
              type="button"
              :class="['dong-mon', { 'dang-chon': String(mon.id || '') === String(monHocIdDangChon || '') }]"
              @click="chonMonHoc(mon)"
          >
            <b>{{ tenMonHoc(mon) }}</b>
            <small>{{ maMonHoc(mon) }} · ID {{ mon.id }}</small>
          </button>
          <div v-if="!danhSachMonLoc.length" class="rong">Không có môn học gốc phù hợp.</div>
        </div>
      </aside>

      <main class="noi-dung-chinh">
        <section v-if="!monHocDangChon" class="hop-rong">Chọn một môn học gốc để cập nhật syllabus gốc.</section>

        <template v-else>
          <section class="thanh-mon">
            <div>
              <b>Môn học gốc đang chọn:</b>
              <span>{{ maMonHoc(monHocDangChon) }} - {{ tenMonHoc(monHocDangChon) }}</span>
            </div>
            <div class="badge">{{ formSyllabus.id ? 'Đã có syllabus gốc' : 'Chưa có syllabus gốc' }}</div>
          </section>

          <section class="luoi-chinh">
            <div class="the khoi-syllabus">
              <div class="tieu-de-the">
                <h3>{{ formSyllabus.id ? 'Cập nhật syllabus gốc' : 'Tạo syllabus gốc' }}</h3>
                <p>Syllabus gốc luôn thuộc đúng môn học gốc đang chọn.</p>
              </div>
              <ThongBaoKhuVuc :state="thongBaoKhuVuc.syllabus" />

              <form class="form-grid form-syllabus" @submit.prevent="luuSyllabus">
                <label>
                  <span>Mã syllabus</span>
                  <input v-model.trim="formSyllabus.ma" type="text" placeholder="VD: SYL-GOC-MH28-BTSCMB-2026">
                </label>
                <label>
                  <span>Tên syllabus <b>*</b></span>
                  <input v-model.trim="formSyllabus.ten" type="text" placeholder="VD: Syllabus gốc - An toàn an ninh dân dụng">
                </label>
                <label class="cot-rong">
                  <span>Vị trí</span>
                  <textarea v-model.trim="formSyllabus.viTri" rows="3" placeholder="Vị trí của môn học trong chương trình"></textarea>
                </label>
                <label>
                  <span>Tính chất</span>
                  <input v-model.trim="formSyllabus.tinhChat" type="text" placeholder="VD: Bắt buộc / Tự chọn">
                </label>
                <label>
                  <span>Số buổi học <b>*</b></span>
                  <input v-model="formSyllabus.soBuoiHoc" type="number" min="1" step="1">
                </label>
                <label>
                  <span>Số tín chỉ</span>
                  <input v-model="formSyllabus.soTinChi" type="number" min="0" step="0.1">
                </label>
                <label>
                  <span>Số tiết mỗi buổi <b>*</b></span>
                  <input v-model="formSyllabus.soTietMoiBuoi" type="number" min="0.1" step="0.1">
                </label>
                <div class="cot-rong tong-hop-syllabus">
                  <div class="tieu-de-tong-hop">Tổng hợp giờ từ chương/bài gốc - không nhập tay</div>
                  <label>
                    <span>Tổng giờ</span>
                    <input :value="hienThiSo(tongHopGioSyllabusGoc.tongGio)" type="text" readonly>
                  </label>
                  <label>
                    <span>LT</span>
                    <input :value="hienThiSo(tongHopGioSyllabusGoc.gioLyThuyet)" type="text" readonly>
                  </label>
                  <label>
                    <span>TH</span>
                    <input :value="hienThiSo(tongHopGioSyllabusGoc.gioThucHanh)" type="text" readonly>
                  </label>
                  <label>
                    <span>KT</span>
                    <input :value="hienThiSo(tongHopGioSyllabusGoc.gioKiemTra)" type="text" readonly>
                  </label>
                </div>
                <label>
                  <span>Số phút một tiết <b>*</b></span>
                  <input v-model="formSyllabus.soPhutMotTiet" type="number" min="1" step="1">
                </label>
                <label>
                  <span>Điểm đạt tối thiểu</span>
                  <input v-model="formSyllabus.diemDatToiThieu" type="number" min="0" step="0.1">
                </label>
                <label>
                  <span>Đơn vị điểm</span>
                  <select v-model="formSyllabus.donViDiem">
                    <option value="">-- Không chọn --</option>
                    <option value="thang_10">Thang 10</option>
                    <option value="phan_tram">Phần trăm (%)</option>
                  </select>
                </label>
                <label>
                  <span>Tỷ lệ chuyên cần tối thiểu (%)</span>
                  <input v-model="formSyllabus.tyLeChuyenCanToiThieu" type="number" min="0" max="100" step="0.1">
                </label>
                <label class="check-line">
                  <input v-model="formSyllabus.batBuocDuThi" type="checkbox">
                  <span>Bắt buộc đủ điều kiện dự thi</span>
                </label>
                <label class="cot-rong">
                  <span>Mục tiêu</span>
                  <textarea v-model.trim="formSyllabus.mucTieu" rows="8"></textarea>
                </label>
                <label class="cot-rong">
                  <span>Phương pháp đánh giá</span>
                  <textarea v-model.trim="formSyllabus.phuongPhapDanhGia" rows="7"></textarea>
                </label>
                <label class="cot-rong">
                  <span>Điều kiện hoàn thành</span>
                  <textarea v-model.trim="formSyllabus.dieuKienHoanThanh" rows="3"></textarea>
                </label>
                <label class="cot-rong">
                  <span>Hướng dẫn</span>
                  <textarea v-model.trim="formSyllabus.huongDan" rows="3"></textarea>
                </label>
                <label class="cot-rong">
                  <span>Công thức quy đổi</span>
                  <textarea v-model.trim="formSyllabus.congThucQuyDoi" rows="3"></textarea>
                </label>
                <label class="cot-rong">
                  <span>Ghi chú</span>
                  <textarea v-model.trim="formSyllabus.ghiChu" rows="2" placeholder="VD: Syllabus gốc nhập từ tài liệu chương trình đào tạo năm 2026."></textarea>
                </label>
                <div class="hang-nut cot-rong">
                  <button type="submit" class="nut chinh" :disabled="dangLuu">{{ formSyllabus.id ? 'Cập nhật syllabus' : 'Lưu syllabus' }}</button>
                  <button type="button" class="nut" :disabled="dangLuu" @click="lamMoiFormSyllabus">Làm mới form</button>
                  <button v-if="formSyllabus.id" type="button" class="nut nguy-hiem" :disabled="dangLuu" @click="xoaSyllabusDangMo">Xóa syllabus</button>
                </div>
              </form>
            </div>

            <div class="the khoi-chuong-bai">
              <div class="tieu-de-the">
                <h3>{{ formChuongBai.id ? 'Cập nhật chương/bài gốc' : 'Thêm chương/bài gốc' }}</h3>
                <p>Chương/bài thuộc syllabus gốc của môn đang chọn.</p>
              </div>
              <ThongBaoKhuVuc :state="thongBaoKhuVuc.chuongBai" />

              <div v-if="!syllabusDangChon" class="canh-bao-nho">Lưu syllabus gốc trước khi thêm chương/bài.</div>
              <form class="form-grid form-nho" @submit.prevent="luuChuongBai">
                <label>
                  <span>Mã chương</span>
                  <input v-model.trim="formChuongBai.maChuong" type="text" placeholder="VD: CH01">
                </label>
                <label>
                  <span>Tên chương/bài <b>*</b></span>
                  <input v-model.trim="formChuongBai.ten" type="text" placeholder="VD: Chương 1: Các định nghĩa và khái niệm">
                </label>
                <label>
                  <span>TT</span>
                  <input v-model="formChuongBai.thuTu" type="number" min="0">
                </label>
                <label>
                  <span>Tổng giờ</span>
                  <input v-model="formChuongBai.tongGio" type="number" min="0" step="0.1">
                </label>
                <label>
                  <span>LT</span>
                  <input v-model="formChuongBai.gioLyThuyet" type="number" min="0" step="0.1">
                </label>
                <label>
                  <span>TH</span>
                  <input v-model="formChuongBai.gioThucHanh" type="number" min="0" step="0.1">
                </label>
                <label>
                  <span>KT</span>
                  <input v-model="formChuongBai.gioKiemTra" type="number" min="0" step="0.1">
                </label>
                <label class="cot-rong">
                  <span>Mục tiêu chương/bài</span>
                  <textarea v-model.trim="formChuongBai.mucTieu" rows="2"></textarea>
                </label>
                <label class="cot-rong">
                  <span>Nội dung</span>
                  <textarea v-model.trim="formChuongBai.noiDung" rows="2"></textarea>
                </label>
                <label class="cot-rong">
                  <span>Ghi chú</span>
                  <textarea v-model.trim="formChuongBai.ghiChu" rows="2"></textarea>
                </label>
                <div class="hang-nut cot-rong">
                  <button type="submit" class="nut chinh" :disabled="dangLuu || !syllabusDangChon">{{ formChuongBai.id ? 'Cập nhật' : 'Thêm chương/bài' }}</button>
                  <button type="button" class="nut" :disabled="dangLuu" @click="resetFormChuongBai">Làm mới</button>
                </div>
              </form>

              <div class="bang-boc">
                <table class="bang-du-lieu bang-chuong-bai">
                  <thead>
                  <tr>
                    <th>TT</th>
                    <th>Mã chương</th>
                    <th>Tên chương/bài</th>
                    <th>Mục tiêu</th>
                    <th>Tổng giờ</th>
                    <th>LT</th>
                    <th>TH</th>
                    <th>KT</th>
                    <th>Nội dung</th>
                    <th>Ghi chú</th>
                    <th>Thao tác</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr v-if="!danhSachChuongBai.length"><td colspan="11" class="rong">Chưa có chương/bài gốc.</td></tr>
                  <tr v-for="row in danhSachChuongBai" :key="row.id">
                    <td class="cot-so">{{ hienThi(row.thuTu) }}</td>
                    <td>{{ row.maChuong || '-' }}</td>
                    <td>{{ row.ten || '-' }}</td>
                    <td class="cot-noi-dung">{{ hienThi(row.mucTieu) }}</td>
                    <td class="cot-so">{{ hienThi(row.tongGio) }}</td>
                    <td class="cot-so">{{ hienThi(row.gioLyThuyet) }}</td>
                    <td class="cot-so">{{ hienThi(row.gioThucHanh) }}</td>
                    <td class="cot-so">{{ hienThi(row.gioKiemTra) }}</td>
                    <td class="cot-noi-dung">{{ hienThi(row.noiDung) }}</td>
                    <td class="cot-ghi-chu-bang">{{ hienThi(row.ghiChu) }}</td>
                    <td class="thao-tac">
                      <button type="button" class="nut nho" @click="suaChuongBai(row)">Sửa</button>
                      <button type="button" class="nut nho nguy-hiem" @click="xoaChuongBai(row)">Xóa</button>
                    </td>
                  </tr>
                  </tbody>
                </table>
              </div>
            </div>


            <div class="the khoi-tai-lieu">
              <div class="tieu-de-the"><h3>Tài liệu gốc của syllabus</h3></div>
              <ThongBaoKhuVuc :state="thongBaoKhuVuc.taiLieu" />
              <div v-if="!syllabusDangChon" class="canh-bao-nho">Lưu syllabus gốc trước khi thêm tài liệu gốc của syllabus.</div>

              <form class="form-grid form-nho" @submit.prevent="luuTaiLieuGoc">
                <label><span>Mã tài liệu</span><input v-model.trim="formTaiLieuGoc.ma" type="text" placeholder="Bỏ trống sẽ tự sinh mã"></label>
                <label><span>Tên tài liệu <b>*</b></span><input v-model.trim="formTaiLieuGoc.ten" type="text"></label>
                <label><span>Loại</span><input v-model.trim="formTaiLieuGoc.loai" type="text"></label>
                <label><span>Tác giả</span><input v-model.trim="formTaiLieuGoc.tacGia" type="text"></label>
                <label><span>Nhà xuất bản</span><input v-model.trim="formTaiLieuGoc.nhaXuatBan" type="text"></label>
                <label><span>Năm xuất bản</span><input v-model="formTaiLieuGoc.namXuatBan" type="number" min="1900" max="2100"></label>
                <label class="cot-rong">
                  <span>Đường dẫn đã lưu / danh sách file</span>
                  <textarea
                      v-model.trim="formTaiLieuGoc.duongDan"
                      rows="3"
                      readonly
                      placeholder="Tự sinh sau khi chọn file/thư mục và upload qua API, không nhập tay."
                  ></textarea>
                </label>
                <label>
                  <span>Thứ tự</span>
                  <input v-model="formGanTaiLieu.thuTu" type="number" min="0">
                </label>
                <label class="check-line compact-check">
                  <input v-model="formGanTaiLieu.batBuoc" type="checkbox">
                  <span>Bắt buộc</span>
                </label>
                <label class="cot-rong">
                  <span>Ghi chú tài liệu</span>
                  <textarea v-model.trim="formTaiLieuGoc.ghiChu" rows="2"></textarea>
                </label>
                <label class="cot-rong">
                  <span>Ghi chú gán trong syllabus gốc</span>
                  <input v-model.trim="formGanTaiLieu.ghiChu" type="text" placeholder="Ghi chú riêng khi tài liệu nằm trong syllabus gốc này">
                </label>
                <input ref="taiLieuFileInput" class="input-file-hidden" type="file" multiple accept=".doc,.docx,.pdf,.xls,.xlsx,.ppt,.pptx,.txt,.png,.jpg,.jpeg" @change="xuLyChonDuongDanTaiLieu">
                <input ref="taiLieuFolderInput" class="input-file-hidden" type="file" multiple webkitdirectory directory @change="xuLyChonDuongDanTaiLieu">
                <div class="hang-nut cot-rong">
                  <button type="submit" class="nut" :disabled="dangLuu">{{ formGanTaiLieu.id ? 'Cập nhật tài liệu gốc của syllabus' : 'Thêm tài liệu gốc vào syllabus' }}</button>
                  <button type="button" class="nut" @click="chonTepTaiLieu">Chọn nhiều file</button>
                  <button type="button" class="nut" @click="chonThuMucTaiLieu">Chọn thư mục</button>
                  <button type="button" class="nut" :disabled="!formTaiLieuGoc.duongDan" @click="moDuongDan(formTaiLieuGoc.duongDan)">Mở đường dẫn</button>
                  <button type="button" class="nut" @click="resetFormTaiLieuGoc">Làm mới</button>
                </div>
              </form>

              <BangDonGian :rows="danhSachGanTaiLieuHienThi" :columns="cotTaiLieu" empty-text="Chưa gán tài liệu gốc." @edit="suaGanTaiLieu" @delete="xoaGanTaiLieu" />
            </div>

            <div class="the khoi-dieu-kien">
              <div class="tieu-de-the"><h3>Điều kiện gốc của syllabus</h3><p>Dữ liệu này có trong DB: điều kiện phòng học, thiết bị, học liệu, dụng cụ, nguyên vật liệu hoặc điều kiện khác. Đánh giá điểm nằm ở form syllabus phía trên.</p></div>
              <ThongBaoKhuVuc :state="thongBaoKhuVuc.dieuKien" />
              <div v-if="!syllabusDangChon" class="canh-bao-nho">Lưu syllabus gốc trước khi gán điều kiện.</div>

              <form class="form-grid form-nho" @submit.prevent="luuDieuKienGoc">
                <label>
                  <span>Mã điều kiện</span>
                  <input v-model.trim="formDieuKienGoc.ma" type="text">
                </label>

                <label>
                  <span>Loại <b>*</b></span>
                  <select v-model="formDieuKienGoc.loai">
                    <option value="phong_hoc">Phòng học</option>
                    <option value="thiet_bi">Thiết bị</option>
                    <option value="hoc_lieu">Học liệu</option>
                    <option value="dung_cu">Dụng cụ</option>
                    <option value="nguyen_vat_lieu">Nguyên vật liệu</option>
                    <option value="khac">Khác</option>
                  </select>
                </label>

                <label>
                  <span>Thứ tự</span>
                  <input v-model="formGanDieuKien.thuTu" type="number" min="0">
                </label>

                <label class="cot-rong">
                  <span>Nội dung <b>*</b></span>
                  <textarea v-model.trim="formDieuKienGoc.noiDung" rows="2"></textarea>
                </label>

                <label class="cot-rong">
                  <span>Ghi chú điều kiện</span>
                  <textarea v-model.trim="formDieuKienGoc.ghiChu" rows="2"></textarea>
                </label>

                <label class="cot-rong">
                  <span>Ghi chú trong syllabus gốc</span>
                  <input v-model.trim="formGanDieuKien.ghiChu" type="text">
                </label>

                <div class="hang-nut cot-rong">
                  <button type="submit" class="nut chinh" :disabled="dangLuu || !syllabusDangChon">
                    {{ formGanDieuKien.id ? 'Cập nhật điều kiện gốc của syllabus' : 'Lưu điều kiện gốc của syllabus' }}
                  </button>
                  <button type="button" class="nut" @click="resetFormDieuKienGoc">Làm mới</button>
                </div>
              </form>

<!--              <form class="form-grid form-gan" @submit.prevent="luuGanDieuKien">-->
<!--                <label class="cot-rong">-->
<!--                  <span>Gán điều kiện gốc vào syllabus</span>-->
<!--                  <select v-model="formGanDieuKien.dieuKienGocId">-->
<!--                    <option value="">&#45;&#45; Chọn điều kiện &#45;&#45;</option>-->
<!--                    <option v-for="dieuKien in danhSachDieuKienGoc" :key="dieuKien.id" :value="dieuKien.id">{{ dieuKien.ma || dieuKien.id }} - {{ dieuKien.noiDung }}</option>-->
<!--                  </select>-->
<!--                </label>-->
<!--                <label><span>TT</span><input v-model="formGanDieuKien.thuTu" type="number" min="0"></label>-->
<!--                <label><span>Ghi chú</span><input v-model.trim="formGanDieuKien.ghiChu" type="text"></label>-->
<!--                <div class="hang-nut cot-rong">-->
<!--                  <button type="submit" class="nut chinh" :disabled="dangLuu || !syllabusDangChon">{{ formGanDieuKien.id ? 'Cập nhật gán' : 'Gán điều kiện' }}</button>-->
<!--                  <button type="button" class="nut" @click="resetFormGanDieuKien">Làm mới gán</button>-->
<!--                </div>-->
<!--              </form>-->

              <BangDonGian
                  :rows="danhSachGanDieuKienHienThi"
                  :columns="cotDieuKien"
                  empty-text="Chưa có điều kiện gốc của syllabus."
                  @edit="suaGanDieuKien"
                  @delete="xoaGanDieuKien"
              />
            </div>

          </section>
        </template>
      </main>
    </section>
  </div>
</template>

<script setup>
import { computed, defineComponent, h, onMounted, reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { daoTaoService as services } from '@/modules/daoTao/services/daoTaoService'
import { layThongBaoLoi } from '@/modules/daoTao/utils/layThongBaoLoi'
import { tepDinhKemUploadService } from '@/modules/daoTao/services/tepDinhKemUploadService'

const ThongBaoKhuVuc = defineComponent({
  name: 'ThongBaoKhuVuc',
  props: {
    state: { type: Object, required: true }
  },
  setup(props) {
    return () => h('div', { class: ['thong-bao-khu-vuc', props.state?.type || 'info'] }, props.state?.message || 'Chưa có thông báo.')
  }
})

const BangDonGian = defineComponent({
  name: 'BangDonGian',
  props: {
    rows: { type: Array, default: () => [] },
    columns: { type: Array, default: () => [] },
    emptyText: { type: String, default: 'Chưa có dữ liệu.' }
  },
  emits: ['edit', 'delete'],
  setup(props, { emit }) {
    function renderNoiDungO(col, row) {
      const value = col.render ? col.render(row) : (row[col.key] ?? '-')
      if (Array.isArray(value) || (value && typeof value === 'object')) return value
      return String(value ?? '-')
    }

    return () => h('div', { class: 'bang-boc bang-con' }, [
      h('table', { class: 'bang-du-lieu' }, [
        h('thead', [h('tr', [...props.columns.map((col) => h('th', { key: col.key, class: col.class || '' }, col.label)), h('th', { class: 'cot-thao-tac' }, 'Thao tác')])]),
        h('tbody', [
          !props.rows.length
              ? h('tr', [h('td', { class: 'rong', colspan: props.columns.length + 1 }, props.emptyText)])
              : props.rows.map((row) => h('tr', { key: row.id }, [
                ...props.columns.map((col) => h('td', { key: col.key, class: col.class || '' }, renderNoiDungO(col, row))),
                h('td', { class: 'thao-tac' }, [
                  h('button', { type: 'button', class: 'nut nho nut-sua', onClick: () => emit('edit', row) }, 'Sửa'),
                  h('button', { type: 'button', class: 'nut nho nguy-hiem nut-xoa', onClick: () => emit('delete', row) }, 'Xóa')
                ])
              ]))
        ])
      ])
    ])
  }
})

const thongBaoKhuVuc = reactive({
  mon: { message: 'Chọn môn học gốc để bắt đầu.', type: 'info' },
  syllabus: { message: 'Form syllabus sẵn sàng.', type: 'info' },
  chuongBai: { message: 'Chương/bài gốc sẵn sàng.', type: 'info' },
  taiLieu: { message: 'Tài liệu gốc của syllabus sẵn sàng.', type: 'info' },
  dieuKien: { message: 'Điều kiện gốc sẵn sàng.', type: 'info' }
})
const router = useRouter()
const dangTai = ref(false)
const dangLuu = ref(false)
const tuKhoaMon = ref('')
const taiLieuFileInput = ref(null)
const taiLieuFolderInput = ref(null)
const monHocIdDangChon = ref(null)
const syllabusIdDangChon = ref(null)
const syllabusTrungTheoMon = ref([])

const danhSachMonHocGoc = ref([])
const danhSachSyllabus = ref([])
const danhSachChuongBai = ref([])
const danhSachTaiLieuGoc = ref([])
const danhSachGanTaiLieu = ref([])
const danhSachDieuKienGoc = ref([])
const danhSachGanDieuKien = ref([])

const formSyllabus = reactive({ id: null, ma: '', ten: '', viTri: '', tinhChat: '', mucTieu: '', phuongPhapDanhGia: '', dieuKienHoanThanh: '', huongDan: '', diemDatToiThieu: '', donViDiem: '', tyLeChuyenCanToiThieu: '', batBuocDuThi: false, congThucQuyDoi: '', ghiChu: '' })
const formChuongBai = reactive({ id: null, maChuong: '', ten: '', mucTieu: '', noiDung: '', thuTu: '', tongGio: '', gioLyThuyet: '', gioThucHanh: '', gioKiemTra: '', ghiChu: '' })
const formTaiLieuGoc = reactive({ id: null, ma: '', ten: '', loai: '', tacGia: '', nhaXuatBan: '', namXuatBan: '', duongDan: '', ghiChu: '' })
const formGanTaiLieu = reactive({ id: null, taiLieuGocId: '', thuTu: '', batBuoc: false, ghiChu: '' })
const formDieuKienGoc = reactive({ id: null, ma: '', loai: 'khac', noiDung: '', ghiChu: '' })
const formGanDieuKien = reactive({ id: null, dieuKienGocId: '', thuTu: '', ghiChu: '' })

const cotTaiLieu = [
  { key: 'thuTu', label: 'TT', class: 'cot-tt cot-can-giua' },
  { key: 'maTaiLieu', label: 'Mã', class: 'cot-ma-tai-lieu' },
  { key: 'tenTaiLieu', label: 'Tên tài liệu', class: 'cot-tai-lieu-ten' },
  { key: 'loaiTaiLieu', label: 'Loại', class: 'cot-loai-tai-lieu cot-can-giua' },
  { key: 'tacGiaTaiLieu', label: 'Tác giả', class: 'cot-tac-gia' },
  { key: 'nhaXuatBanTaiLieu', label: 'NXB', class: 'cot-nxb' },
  { key: 'namXuatBanTaiLieu', label: 'Năm', class: 'cot-nam-xb cot-can-giua' },
  { key: 'batBuocText', label: 'Bắt buộc', class: 'cot-bat-buoc cot-can-giua' },
  { key: 'xemFileText', label: 'Xem file', class: 'cot-xem-file cot-can-giua' },
  { key: 'duongDanText', label: 'Mở đọc', class: 'cot-mo-doc cot-can-giua' },
  { key: 'ghiChuTaiLieu', label: 'Ghi chú TL', class: 'cot-ghi-chu' },
  { key: 'ghiChuGan', label: 'Ghi chú gán', class: 'cot-ghi-chu' }
]
const cotDieuKien = [
  { key: 'thuTu', label: 'TT', class: 'cot-tt cot-can-giua' },
  { key: 'maDieuKien', label: 'Mã điều kiện', class: 'cot-dieu-kien-ma' },
  { key: 'noiDungDieuKien', label: 'Điều kiện gốc', class: 'cot-dieu-kien-noi-dung' },
  { key: 'loaiDieuKien', label: 'Loại', class: 'cot-dieu-kien-loai cot-can-giua' },
  { key: 'ghiChuDieuKien', label: 'Ghi chú điều kiện', class: 'cot-ghi-chu' },
  { key: 'ghiChuGan', label: 'Ghi chú trong syllabus', class: 'cot-ghi-chu' }
]

const monHocDangChon = computed(() => danhSachMonHocGoc.value.find((mon) => String(mon.id || '') === String(monHocIdDangChon.value || '')) || null)
const syllabusDangChon = computed(() => danhSachSyllabus.value.find((item) => String(item.id || '') === String(syllabusIdDangChon.value || '')) || null)
const danhSachMonLoc = computed(() => {
  const keyword = chuanHoa(tuKhoaMon.value)
  const rows = [...danhSachMonHocGoc.value].sort((a, b) => tenMonHoc(a).localeCompare(tenMonHoc(b), 'vi'))
  if (!keyword) return rows
  return rows.filter((mon) => chuanHoa([maMonHoc(mon), tenMonHoc(mon), mon.moTa].filter(Boolean).join(' ')).includes(keyword))
})
const danhSachGanTaiLieuHienThi = computed(() => danhSachGanTaiLieu.value.map((row) => {
  const taiLieu = danhSachTaiLieuGoc.value.find((item) => String(item.id || '') === String(row.taiLieuGocId || ''))
  const duongDan = taiLieu?.duongDan || ''
  return {
    ...row,
    maTaiLieu: taiLieu?.ma || '-',
    tenTaiLieu: taiLieu?.ten || `ID ${row.taiLieuGocId}`,
    loaiTaiLieu: taiLieu?.loai || '-',
    tacGiaTaiLieu: taiLieu?.tacGia || '-',
    nhaXuatBanTaiLieu: taiLieu?.nhaXuatBan || '-',
    namXuatBanTaiLieu: taiLieu?.namXuatBan ?? '-',
    ghiChuTaiLieu: taiLieu?.ghiChu || '-',
    ghiChuGan: row.ghiChu || '-',
    batBuocText: row.batBuoc ? 'Có' : 'Không',
    duongDan,
    xemFileText: h('button', { type: 'button', class: 'nut nho nut-xem-file', onClick: () => xemTepTaiLieuGoc(row) }, 'Xem file'),
    duongDanText: duongDan
        ? h('button', { type: 'button', class: 'nut nho nut-mo-doc', onClick: () => moDuongDan(duongDan) }, 'Mở')
        : '-'
  }
}))

const danhSachGanDieuKienHienThi = computed(() => danhSachGanDieuKien.value.map((row) => {
  const dieuKien = danhSachDieuKienGoc.value.find((item) => {
    return String(item.id || '') === String(row.dieuKienGocId || '')
  })

  return {
    ...row,
    maDieuKien: row.ma || dieuKien?.ma || '-',
    noiDungDieuKien: row.noiDung || dieuKien?.noiDung || `ID ${row.dieuKienGocId}`,
    loaiDieuKien: row.loai || dieuKien?.loai || '-',
    ghiChuDieuKien: row.ghiChuDieuKien || dieuKien?.ghiChu || '-',
    ghiChuGan: row.ghiChu || '-'
  }
}))

const tongHopGioSyllabusGoc = computed(() => {
  const tongHopTuChuongBai = danhSachChuongBai.value.reduce((result, row) => {
    result.tongGio += Number(row.tongGio || 0)
    result.gioLyThuyet += Number(row.gioLyThuyet || 0)
    result.gioThucHanh += Number(row.gioThucHanh || 0)
    result.gioKiemTra += Number(row.gioKiemTra || 0)
    return result
  }, { tongGio: 0, gioLyThuyet: 0, gioThucHanh: 0, gioKiemTra: 0 })

  if (danhSachChuongBai.value.length) return tongHopTuChuongBai

  return {
    tongGio: Number(syllabusDangChon.value?.tongGio || 0),
    gioLyThuyet: Number(syllabusDangChon.value?.gioLyThuyet || 0),
    gioThucHanh: Number(syllabusDangChon.value?.gioThucHanh || 0),
    gioKiemTra: Number(syllabusDangChon.value?.gioKiemTra || 0)
  }
})

function chuanHoa(value) { return String(value || '').trim().toLowerCase() }
function maMonHoc(mon) { return mon?.maMon || mon?.ma || '-' }
function tenMonHoc(mon) { return mon?.tenMon || mon?.ten || '-' }
function hienThi(value) { return value === null || value === undefined || value === '' ? '-' : value }
function hienThiSo(value) {
  const number = Number(value || 0)
  if (!Number.isFinite(number)) return '0'
  return Number.isInteger(number) ? String(number) : String(Number(number.toFixed(2)))
}
function parseNumber(value) { if (value === '' || value === null || value === undefined) return null; const number = Number(value); return Number.isFinite(number) ? number : null }
function layItems(page) { return Array.isArray(page?.items) ? page.items : [] }
function layIdSauKhiLuu(res) {
  return res?.id || res?.data?.id || res?.data?.data?.id || null
}
function baoTin(message, type = 'success', khuVuc = 'syllabus') {
  const key = thongBaoKhuVuc[khuVuc] ? khuVuc : 'syllabus'
  thongBaoKhuVuc[key].message = message
  thongBaoKhuVuc[key].type = type
}
function datThongBaoNhieuKhuVuc(message, type, khuVucList) {
  khuVucList.forEach((khuVuc) => baoTin(message, type, khuVuc))
}
function taoMaTuDong(prefix) {
  const monPart = monHocIdDangChon.value ? `MH${monHocIdDangChon.value}` : 'MH'
  return `${prefix}-${monPart}-${Date.now().toString().slice(-6)}`
}
function moDuongDan(duongDan) {
  const danhSach = String(duongDan || '').split(/\r?\n/).map((item) => item.trim()).filter(Boolean)
  const url = danhSach[0] || ''
  if (!url) return baoTin('Tài liệu chưa có đường dẫn để mở.', 'error', 'taiLieu')
  window.open(url, '_blank', 'noopener,noreferrer')
  if (danhSach.length > 1) baoTin(`Đã mở đường dẫn đầu tiên. Ô Đường dẫn đang có ${danhSach.length} file/thư mục.`, 'info', 'taiLieu')
}
function xemTepTaiLieuGoc(row) {
  const taiLieuGocId = row?.taiLieuGocId || row?.id || null
  if (!taiLieuGocId) return baoTin('Không tìm thấy ID tài liệu gốc để xem file.', 'error', 'taiLieu')
  router.push({
    name: 'DaoTao.XemChuongTrinh.SyllabusTep',
    params: {
      nganhId: 0,
      chuongTrinhId: 0,
      versionId: 0,
      chuongTrinhMonId: 0
    },
    query: {
      tepNguon: 'taiLieuGoc',
      taiLieuGocId
    }
  })
}

function chuanHoaDonViDiem(value) {
  const text = String(value || '').trim().toLowerCase()
  if (!text) return null
  if (['thang_10', 'thang 10', 'thang10', '10'].includes(text)) return 'thang_10'
  if (['phan_tram', 'phần trăm', 'phan tram', '%'].includes(text)) return 'phan_tram'
  return text
}

async function taiDuLieuNen() {
  dangTai.value = true
  try {
    const [monHoc, taiLieuGoc, dieuKienGoc] = await Promise.all([services.monHoc.getAll({ size: 500 }), services.taiLieuGoc.getAll({ size: 500 }), services.dieuKienMonHocGoc.getAll({ size: 500 })])
    danhSachMonHocGoc.value = layItems(monHoc)
    danhSachTaiLieuGoc.value = layItems(taiLieuGoc)
    danhSachDieuKienGoc.value = layItems(dieuKienGoc)
    if (monHocIdDangChon.value) await taiSyllabusTheoMonVaMoForm()
    baoTin('Đã tải lại dữ liệu gốc.', 'success', 'mon')
  } catch (error) { baoTin(layThongBaoLoi(error, 'Không tải được dữ liệu gốc.'), 'error', 'mon') }
  finally { dangTai.value = false }
}

async function chonMonHoc(mon) {
  monHocIdDangChon.value = mon?.id || null
  resetTatCaFormChiTiet()
  await taiSyllabusTheoMonVaMoForm()
}

async function taiSyllabusTheoMonVaMoForm() {
  if (!monHocIdDangChon.value) return
  const page = await services.syllabusMonHocGoc.getAll({ size: 500, monHocId: monHocIdDangChon.value })
  const rows = layItems(page).filter((row) => String(row.monHocId || '') === String(monHocIdDangChon.value || ''))
  syllabusTrungTheoMon.value = rows
  danhSachSyllabus.value = rows.slice(0, 1)
  if (rows.length) {
    const syllabus = rows[0]
    syllabusIdDangChon.value = syllabus.id
    suaSyllabus(syllabus)
    await taiChiTietSyllabus()
    if (rows.length > 1) baoTin('Môn này đang có nhiều hơn 1 syllabus gốc trong dữ liệu cũ. Trang chỉ mở bản đầu tiên; nên xử lý trùng trong DB.', 'error', 'syllabus')
  } else {
    syllabusIdDangChon.value = null
    resetFormSyllabus()
    resetTatCaFormChiTiet()
  }
}

async function taiChiTietSyllabus() {
  if (!syllabusIdDangChon.value) return
  try {
    const params = { size: 500, syllabusMonHocGocId: syllabusIdDangChon.value }
    const [chuongBai, ganTaiLieu, ganDieuKien] = await Promise.all([services.syllabusMonHocGocChuongBai.getAll(params), services.syllabusMonHocGocTaiLieu.getAll(params), services.syllabusMonHocGocDieuKien.getAll(params)])
    danhSachChuongBai.value = layItems(chuongBai).sort((a, b) => Number(a.thuTu || 0) - Number(b.thuTu || 0))
    danhSachGanTaiLieu.value = layItems(ganTaiLieu).sort((a, b) => Number(a.thuTu || 0) - Number(b.thuTu || 0))
    danhSachGanDieuKien.value = layItems(ganDieuKien).sort((a, b) => Number(a.thuTu || 0) - Number(b.thuTu || 0))
  } catch (error) { datThongBaoNhieuKhuVuc(layThongBaoLoi(error, 'Không tải được chi tiết syllabus.'), 'error', ['chuongBai', 'taiLieu', 'dieuKien']) }
}

function resetFormSyllabus() {
  Object.assign(formSyllabus, {
    id: null,
    ma: '',
    ten: '',
    viTri: '',
    tinhChat: '',
    soTinChi: '',
    soBuoiHoc: '',
    soTietMoiBuoi: '',
    soPhutMotTiet: '',
    mucTieu: '',
    phuongPhapDanhGia: '',
    dieuKienHoanThanh: '',
    huongDan: '',
    diemDatToiThieu: '',
    donViDiem: '',
    tyLeChuyenCanToiThieu: '',
    batBuocDuThi: false,
    congThucQuyDoi: '',
    ghiChu: ''
  })
}
function lamMoiFormSyllabus() { if (syllabusDangChon.value) suaSyllabus(syllabusDangChon.value); else resetFormSyllabus() }
function suaSyllabus(row) {
  Object.assign(formSyllabus, {
    id: row.id,
    ma: row.ma || '',
    ten: row.ten || '',
    viTri: row.viTri || '',
    tinhChat: row.tinhChat || '',
    soTinChi: row.soTinChi ?? '',
    soBuoiHoc: row.soBuoiHoc ?? '',
    soTietMoiBuoi: row.soTietMoiBuoi ?? '',
    soPhutMotTiet: row.soPhutMotTiet ?? '',
    mucTieu: row.mucTieu || '',
    phuongPhapDanhGia: row.phuongPhapDanhGia || '',
    dieuKienHoanThanh: row.dieuKienHoanThanh || '',
    huongDan: row.huongDan || '',
    diemDatToiThieu: row.diemDatToiThieu ?? '',
    donViDiem: row.donViDiem || '',
    tyLeChuyenCanToiThieu: row.tyLeChuyenCanToiThieu ?? '',
    batBuocDuThi: Boolean(row.batBuocDuThi),
    congThucQuyDoi: row.congThucQuyDoi || '',
    ghiChu: row.ghiChu || ''
  })
}
function payloadSyllabus() {
  return {
    monHocId: monHocIdDangChon.value,
    ma: formSyllabus.ma || taoMaTuDong('SYL-GOC'),
    ten: formSyllabus.ten,
    viTri: formSyllabus.viTri || null,
    tinhChat: formSyllabus.tinhChat || null,
    soTinChi: parseNumber(formSyllabus.soTinChi),
    soBuoiHoc: parseNumber(formSyllabus.soBuoiHoc),
    soTietMoiBuoi: parseNumber(formSyllabus.soTietMoiBuoi),
    soPhutMotTiet: parseNumber(formSyllabus.soPhutMotTiet),
    mucTieu: formSyllabus.mucTieu || null,
    phuongPhapDanhGia: formSyllabus.phuongPhapDanhGia || null,
    dieuKienHoanThanh: formSyllabus.dieuKienHoanThanh || null,
    huongDan: formSyllabus.huongDan || null,
    diemDatToiThieu: parseNumber(formSyllabus.diemDatToiThieu),
    donViDiem: chuanHoaDonViDiem(formSyllabus.donViDiem),
    tyLeChuyenCanToiThieu: parseNumber(formSyllabus.tyLeChuyenCanToiThieu),
    batBuocDuThi: Boolean(formSyllabus.batBuocDuThi),
    congThucQuyDoi: formSyllabus.congThucQuyDoi || null,
    ghiChu: formSyllabus.ghiChu || null
  }
}

async function luuSyllabus() {
  if (!monHocIdDangChon.value) return baoTin('Cần chọn môn học gốc.', 'error', 'syllabus')
  if (!formSyllabus.ten) return baoTin('Cần nhập tên syllabus.', 'error', 'syllabus')
  if (parseNumber(formSyllabus.soTinChi) !== null && parseNumber(formSyllabus.soTinChi) < 0) {
    return baoTin('Số tín chỉ không được âm.', 'error', 'syllabus')
  }
  if (!parseNumber(formSyllabus.soBuoiHoc) || parseNumber(formSyllabus.soBuoiHoc) < 1) return baoTin('Cần nhập số buổi học lớn hơn 0.', 'error', 'syllabus')
  if (!parseNumber(formSyllabus.soTietMoiBuoi) || parseNumber(formSyllabus.soTietMoiBuoi) <= 0) return baoTin('Cần nhập số tiết mỗi buổi lớn hơn 0.', 'error', 'syllabus')
  if (!parseNumber(formSyllabus.soPhutMotTiet) || parseNumber(formSyllabus.soPhutMotTiet) < 1) return baoTin('Cần nhập số phút một tiết lớn hơn 0.', 'error', 'syllabus')
  dangLuu.value = true
  try {
    if (formSyllabus.id) await services.syllabusMonHocGoc.update(formSyllabus.id, payloadSyllabus())
    else await services.syllabusMonHocGoc.create(payloadSyllabus())
    await taiSyllabusTheoMonVaMoForm()
    baoTin('Đã lưu syllabus gốc.', 'success', 'syllabus')
  } catch (error) { baoTin(layThongBaoLoi(error, 'Không lưu được syllabus gốc.'), 'error', 'syllabus') }
  finally { dangLuu.value = false }
}

async function xoaSyllabusDangMo() {
  if (!formSyllabus.id) return
  if (!window.confirm(`Xóa syllabus gốc "${formSyllabus.ten || formSyllabus.ma || formSyllabus.id}"?`)) return
  dangLuu.value = true
  try {
    await services.syllabusMonHocGoc.delete(formSyllabus.id)
    await taiSyllabusTheoMonVaMoForm()
    baoTin('Đã xóa syllabus gốc.', 'success', 'syllabus')
  } catch (error) { baoTin(layThongBaoLoi(error, 'Không xóa được syllabus gốc. Kiểm tra dữ liệu con đang dùng.'), 'error', 'syllabus') }
  finally { dangLuu.value = false }
}

function resetFormChuongBai() { Object.assign(formChuongBai, { id: null, maChuong: '', ten: '', mucTieu: '', noiDung: '', thuTu: '', tongGio: '', gioLyThuyet: '', gioThucHanh: '', gioKiemTra: '', ghiChu: '' }) }
function suaChuongBai(row) { Object.assign(formChuongBai, { id: row.id, maChuong: row.maChuong || '', ten: row.ten || '', mucTieu: row.mucTieu || '', noiDung: row.noiDung || '', thuTu: row.thuTu ?? '', tongGio: row.tongGio ?? '', gioLyThuyet: row.gioLyThuyet ?? '', gioThucHanh: row.gioThucHanh ?? '', gioKiemTra: row.gioKiemTra ?? '', ghiChu: row.ghiChu || '' }) }
function payloadChuongBai() { return { syllabusMonHocGocId: syllabusIdDangChon.value, maChuong: formChuongBai.maChuong || null, ten: formChuongBai.ten, mucTieu: formChuongBai.mucTieu || null, noiDung: formChuongBai.noiDung || null, thuTu: parseNumber(formChuongBai.thuTu), tongGio: parseNumber(formChuongBai.tongGio), gioLyThuyet: parseNumber(formChuongBai.gioLyThuyet), gioThucHanh: parseNumber(formChuongBai.gioThucHanh), gioKiemTra: parseNumber(formChuongBai.gioKiemTra), ghiChu: formChuongBai.ghiChu || null } }
async function luuChuongBai() { if (!syllabusIdDangChon.value) return baoTin('Cần lưu syllabus gốc trước.', 'error', 'chuongBai'); if (!formChuongBai.ten) return baoTin('Cần nhập tên chương/bài.', 'error', 'chuongBai'); await luuChiTiet(services.syllabusMonHocGocChuongBai, formChuongBai.id, payloadChuongBai(), resetFormChuongBai, 'chương/bài gốc', 'chuongBai') }
async function xoaChuongBai(row) { await xoaChiTiet(services.syllabusMonHocGocChuongBai, row, 'chương/bài gốc', 'chuongBai') }


function chonTepTaiLieu() {
  taiLieuFileInput.value?.click()
}

function chonThuMucTaiLieu() {
  taiLieuFolderInput.value?.click()
}

async function xuLyChonDuongDanTaiLieu(event) {
  const files = Array.from(event?.target?.files || [])
  if (!files.length) return
  if (!syllabusIdDangChon.value) {
    event.target.value = ''
    return baoTin('Cần lưu syllabus gốc trước khi upload file tài liệu.', 'error', 'taiLieu')
  }
  dangLuu.value = true
  try {
    const danhSachFileInfo = await tepDinhKemUploadService.uploadMany({
      files,
      module: 'dao-tao',
      nghiepVu: 'syllabus_mon_hoc_goc_tai_lieu',
      doiTuongId: syllabusIdDangChon.value,
      nguoiGuiLoai: 'DAO_TAO',
      nguoiGuiId: 1,
      nguoiGuiTen: 'Đào tạo',
      moTa: formTaiLieuGoc.ten || '',
      monHocId: monHocIdDangChon.value || null,
      syllabusMonHocGocId: syllabusIdDangChon.value,
      tangNghiepVu: 'syllabus-mon-hoc-goc-tai-lieu'
    })

    const duongDanMoi = danhSachFileInfo.map((fileInfo, index) => {
      const file = files[index]
      const duongDan = tepDinhKemUploadService.taoDuongDanTaiFile(fileInfo)
      return duongDan || file?.webkitRelativePath || file?.name || ''
    }).filter(Boolean)

    const hienTai = String(formTaiLieuGoc.duongDan || '').split(/\r?\n/).map((item) => item.trim()).filter(Boolean)
    formTaiLieuGoc.duongDan = Array.from(new Set([...hienTai, ...duongDanMoi])).join('\n')
    if (!formTaiLieuGoc.ten && files.length === 1) formTaiLieuGoc.ten = files[0].name.replace(/\.[^.]+$/, '')
    if (!formTaiLieuGoc.loai && files.length === 1) formTaiLieuGoc.loai = (files[0].name.split('.').pop() || '').toLowerCase()
    baoTin(`Đã upload và lưu ${files.length} file/thư mục vào ô Đường dẫn đã lưu.`, 'success', 'taiLieu')
  } catch (error) {
    baoTin(layThongBaoLoi(error, 'Không upload được file tài liệu.'), 'error', 'taiLieu')
  } finally {
    dangLuu.value = false
    event.target.value = ''
  }
}

function resetFormTaiLieuGoc() { Object.assign(formTaiLieuGoc, { id: null, ma: '', ten: '', loai: '', tacGia: '', nhaXuatBan: '', namXuatBan: '', duongDan: '', ghiChu: '' }); resetFormGanTaiLieu() }
function payloadTaiLieuGoc() { return { ma: formTaiLieuGoc.ma || taoMaTuDong('TL-GOC'), ten: formTaiLieuGoc.ten, loai: formTaiLieuGoc.loai || null, tacGia: formTaiLieuGoc.tacGia || null, nhaXuatBan: formTaiLieuGoc.nhaXuatBan || null, namXuatBan: parseNumber(formTaiLieuGoc.namXuatBan), duongDan: formTaiLieuGoc.duongDan || null, ghiChu: formTaiLieuGoc.ghiChu || null } }
async function luuTaiLieuGoc() {
  if (!syllabusIdDangChon.value) return baoTin('Cần lưu syllabus gốc trước khi thêm tài liệu.', 'error', 'taiLieu')
  if (!formTaiLieuGoc.ten) return baoTin('Cần nhập tên tài liệu gốc.', 'error', 'taiLieu')
  dangLuu.value = true
  try {
    const payload = payloadTaiLieuGoc()
    const res = formTaiLieuGoc.id ? await services.taiLieuGoc.update(formTaiLieuGoc.id, payload) : await services.taiLieuGoc.create(payload)
    const savedId = layIdSauKhiLuu(res) || formTaiLieuGoc.id
    const linkPayload = {
      syllabusMonHocGocId: syllabusIdDangChon.value,
      taiLieuGocId: savedId,
      thuTu: parseNumber(formGanTaiLieu.thuTu),
      batBuoc: Boolean(formGanTaiLieu.batBuoc),
      ghiChu: formGanTaiLieu.ghiChu || null,
      ma: payload.ma,
      ten: payload.ten,
      loai: payload.loai,
      tacGia: payload.tacGia,
      nhaXuatBan: payload.nhaXuatBan,
      namXuatBan: payload.namXuatBan,
      duongDan: payload.duongDan
    }
    if (formGanTaiLieu.id) await services.syllabusMonHocGocTaiLieu.update(formGanTaiLieu.id, linkPayload)
    else await services.syllabusMonHocGocTaiLieu.create(linkPayload)
    danhSachTaiLieuGoc.value = layItems(await services.taiLieuGoc.getAll({ size: 500 }))
    await taiChiTietSyllabus()
    resetFormTaiLieuGoc()
    baoTin('Đã lưu tài liệu gốc trực tiếp vào syllabus gốc.', 'success', 'taiLieu')
  } catch (error) { baoTin(layThongBaoLoi(error, 'Không lưu được tài liệu gốc của syllabus.'), 'error', 'taiLieu') }
  finally { dangLuu.value = false }
}
function resetFormGanTaiLieu() { Object.assign(formGanTaiLieu, { id: null, taiLieuGocId: '', thuTu: '', batBuoc: false, ghiChu: '' }) }
function suaGanTaiLieu(row) {
  Object.assign(formGanTaiLieu, { id: row.id, taiLieuGocId: row.taiLieuGocId, thuTu: row.thuTu ?? '', batBuoc: Boolean(row.batBuoc), ghiChu: row.ghiChu || '' })
  const taiLieu = danhSachTaiLieuGoc.value.find((item) => String(item.id || '') === String(row.taiLieuGocId || ''))
  Object.assign(formTaiLieuGoc, {
    id: taiLieu?.id || row.taiLieuGocId || null,
    ma: row.ma || taiLieu?.ma || '',
    ten: row.ten || taiLieu?.ten || '',
    loai: row.loai || taiLieu?.loai || '',
    tacGia: row.tacGia || taiLieu?.tacGia || '',
    nhaXuatBan: row.nhaXuatBan || taiLieu?.nhaXuatBan || '',
    namXuatBan: row.namXuatBan ?? taiLieu?.namXuatBan ?? '',
    duongDan: row.duongDan || taiLieu?.duongDan || '',
    ghiChu: row.ghiChuTaiLieu || taiLieu?.ghiChu || ''
  })
}
function payloadGanTaiLieu() { return { syllabusMonHocGocId: syllabusIdDangChon.value, taiLieuGocId: parseNumber(formGanTaiLieu.taiLieuGocId), thuTu: parseNumber(formGanTaiLieu.thuTu), batBuoc: Boolean(formGanTaiLieu.batBuoc), ghiChu: formGanTaiLieu.ghiChu || null } }
async function luuGanTaiLieu() { if (!formGanTaiLieu.taiLieuGocId) return baoTin('Cần chọn tài liệu gốc để gán.', 'error', 'taiLieu'); await luuChiTiet(services.syllabusMonHocGocTaiLieu, formGanTaiLieu.id, payloadGanTaiLieu(), resetFormGanTaiLieu, 'gán tài liệu gốc', 'taiLieu') }
async function xoaGanTaiLieu(row) { await xoaChiTiet(services.syllabusMonHocGocTaiLieu, row, 'gán tài liệu gốc', 'taiLieu') }

function resetFormDieuKienGoc() { Object.assign(formDieuKienGoc, { id: null, ma: '', loai: 'khac', noiDung: '', ghiChu: '' }) }
function payloadDieuKienGoc() { return { ma: formDieuKienGoc.ma || taoMaTuDong('DK-GOC'), loai: formDieuKienGoc.loai || 'khac', noiDung: formDieuKienGoc.noiDung, ghiChu: formDieuKienGoc.ghiChu || null } }
async function luuDieuKienGoc() {
  if (!syllabusIdDangChon.value) {
    return baoTin('Cần lưu syllabus gốc trước khi thêm điều kiện.', 'error', 'dieuKien')
  }

  if (!formDieuKienGoc.noiDung) {
    return baoTin('Cần nhập nội dung điều kiện gốc.', 'error', 'dieuKien')
  }

  dangLuu.value = true

  try {
    const payload = payloadDieuKienGoc()

    const res = formDieuKienGoc.id
        ? await services.dieuKienMonHocGoc.update(formDieuKienGoc.id, payload)
        : await services.dieuKienMonHocGoc.create(payload)

    const savedId = layIdSauKhiLuu(res) || formDieuKienGoc.id

    const linkPayload = {
      syllabusMonHocGocId: syllabusIdDangChon.value,
      dieuKienGocId: savedId,
      thuTu: parseNumber(formGanDieuKien.thuTu),
      ghiChu: formGanDieuKien.ghiChu || null
    }

    if (formGanDieuKien.id) {
      await services.syllabusMonHocGocDieuKien.update(formGanDieuKien.id, linkPayload)
    } else {
      await services.syllabusMonHocGocDieuKien.create(linkPayload)
    }

    danhSachDieuKienGoc.value = layItems(await services.dieuKienMonHocGoc.getAll({ size: 500 }))
    await taiChiTietSyllabus()
    resetFormDieuKienGoc()
    baoTin('Đã lưu điều kiện gốc trực tiếp vào syllabus gốc.', 'success', 'dieuKien')
  } catch (error) {
    baoTin(layThongBaoLoi(error, 'Không lưu được điều kiện gốc của syllabus.'), 'error', 'dieuKien')
  } finally {
    dangLuu.value = false
  }
}
function resetFormGanDieuKien() { Object.assign(formGanDieuKien, { id: null, dieuKienGocId: '', thuTu: '', ghiChu: '' }) }
function suaGanDieuKien(row) {
  Object.assign(formGanDieuKien, {
    id: row.id,
    dieuKienGocId: row.dieuKienGocId,
    thuTu: row.thuTu ?? '',
    ghiChu: row.ghiChu || ''
  })

  const dieuKien = danhSachDieuKienGoc.value.find((item) => {
    return String(item.id || '') === String(row.dieuKienGocId || '')
  })

  Object.assign(formDieuKienGoc, {
    id: dieuKien?.id || row.dieuKienGocId || null,
    ma: dieuKien?.ma || '',
    loai: dieuKien?.loai || 'khac',
    noiDung: dieuKien?.noiDung || '',
    ghiChu: dieuKien?.ghiChu || ''
  })
}
function payloadGanDieuKien() { return { syllabusMonHocGocId: syllabusIdDangChon.value, dieuKienGocId: parseNumber(formGanDieuKien.dieuKienGocId), thuTu: parseNumber(formGanDieuKien.thuTu), ghiChu: formGanDieuKien.ghiChu || null } }
async function luuGanDieuKien() { if (!formGanDieuKien.dieuKienGocId) return baoTin('Cần chọn điều kiện gốc để gán.', 'error', 'dieuKien'); await luuChiTiet(services.syllabusMonHocGocDieuKien, formGanDieuKien.id, payloadGanDieuKien(), resetFormGanDieuKien, 'gán điều kiện gốc', 'dieuKien') }
async function xoaGanDieuKien(row) { await xoaChiTiet(services.syllabusMonHocGocDieuKien, row, 'gán điều kiện gốc', 'dieuKien') }

async function luuChiTiet(service, id, payload, resetFn, ten, khuVuc = 'syllabus') { if (!syllabusIdDangChon.value) return baoTin('Cần lưu syllabus gốc trước.', 'error', khuVuc); dangLuu.value = true; try { if (id) await service.update(id, payload); else await service.create(payload); await taiChiTietSyllabus(); resetFn(); baoTin(`Đã lưu ${ten}.`, 'success', khuVuc) } catch (error) { baoTin(layThongBaoLoi(error, `Không lưu được ${ten}.`), 'error', khuVuc) } finally { dangLuu.value = false } }
async function xoaChiTiet(service, row, ten, khuVuc = 'syllabus') { if (!row?.id) return; if (!window.confirm(`Xóa ${ten} này?`)) return; dangLuu.value = true; try { await service.delete(row.id); await taiChiTietSyllabus(); baoTin(`Đã xóa ${ten}.`, 'success', khuVuc) } catch (error) { baoTin(layThongBaoLoi(error, `Không xóa được ${ten}.`), 'error', khuVuc) } finally { dangLuu.value = false } }
function resetTatCaFormChiTiet() { danhSachChuongBai.value = []; danhSachGanTaiLieu.value = []; danhSachGanDieuKien.value = []; resetFormChuongBai(); resetFormGanTaiLieu(); resetFormGanDieuKien() }

onMounted(taiDuLieuNen)
</script>

<style scoped>
.syllabus-mon-hoc-goc-page { display: grid; gap: 10px; padding: 10px; font-family: Roboto, Arial, sans-serif; color: #111827; }
.thong-bao { padding: 9px 11px; border: 1px solid #bbf7d0; border-radius: 5px; background: #f0fdf4; color: #166534; font-size: 13px; }
.thong-bao.error { border-color: #fecaca; background: #fef2f2; color: #b91c1c; }
.khoi-dau, .the, .hop-rong, .thanh-mon { border: 1px solid #d7dde6; border-radius: 6px; background: #fff; box-shadow: 0 1px 2px rgba(15, 23, 42, 0.04); }
.khoi-dau, .thanh-mon { display: flex; align-items: center; justify-content: space-between; gap: 10px; padding: 10px 12px; }
.khoi-dau h2, .tieu-de-the h3 { margin: 0; font-size: 16px; color: #0f172a; }
.khoi-dau p, .tieu-de-the p { margin: 3px 0 0; color: #64748b; font-size: 12px; line-height: 1.35; }
.luoi-trang { display: grid; grid-template-columns: 285px minmax(0, 1fr); gap: 10px; align-items: start; }
.noi-dung-chinh { display: grid; gap: 10px; min-width: 0; }
.luoi-chinh { display: grid; grid-template-columns: minmax(0, 1fr); gap: 10px; align-items: start; }
.khoi-syllabus, .khoi-chuong-bai, .khoi-tai-lieu, .khoi-dieu-kien { width: 100%; min-width: 0; }
.khoi-chuong-bai,
.khoi-tai-lieu { border-color: #cbd5e1; }
.khoi-tai-lieu .tieu-de-the { background: #f7fbff; }
.tieu-de-the { padding: 9px 11px; border-bottom: 1px solid #e5e7eb; background: #f8fafc; }
.tieu-de-the.compact h3 { font-size: 15px; }
.bo-loc { padding: 10px; border-bottom: 1px solid #eef2f7; }
.danh-sach-mon { display: grid; gap: 5px; padding: 10px; max-height: calc(100vh - 155px); min-height: 680px; overflow: auto; scrollbar-width: thin; }
.dong-mon { display: grid; gap: 2px; width: 100%; border: 1px solid #e5e7eb; border-radius: 5px; background: #fff; padding: 7px 9px; text-align: left; cursor: pointer; font-family: Roboto, Arial, sans-serif; }
.dong-mon:hover, .dong-mon.dang-chon { border-color: #2563eb; background: #eff6ff; }
.dong-mon b { font-size: 13px; }
.dong-mon small, td small { display: block; margin-top: 2px; color: #64748b; }
.thanh-mon b { font-size: 12px; color: #475569; }
.thanh-mon span { font-size: 13px; font-weight: 700; }
.badge { padding: 5px 9px; border-radius: 999px; border: 1px solid #bfdbfe; background: #eff6ff; color: #1d4ed8; font-size: 12px; font-weight: 700; }
.form-grid { display: grid; grid-template-columns: repeat(2, minmax(150px, 1fr)); gap: 8px; padding: 10px; }
.form-syllabus { grid-template-columns: repeat(2, minmax(200px, 1fr)); }
.form-nho { grid-template-columns: repeat(3, minmax(90px, 1fr)); }
.form-gan { border-top: 1px dashed #cbd5e1; background: #fbfdff; }
label { display: grid; gap: 3px; }
label span { color: #374151; font-size: 12px; font-weight: 700; }
label b { color: #dc2626; }
input, select, textarea { width: 100%; min-height: 30px; border: 1px solid #cbd5e1; border-radius: 4px; padding: 5px 7px; font-size: 13px; font-family: Roboto, Arial, sans-serif; background: #fff; box-sizing: border-box; }
textarea { resize: vertical; line-height: 1.35; }
input[readonly], textarea[readonly] { background: #f8fafc; color: #334155; cursor: not-allowed; }
.tong-hop-syllabus {
  display: grid;
  grid-template-columns: repeat(4, minmax(100px, 1fr));
  gap: 8px;
  padding: 9px;
  border: 1px dashed #bfdbfe;
  border-radius: 6px;
  background: #f8fbff;
}
.tieu-de-tong-hop {
  grid-column: 1 / -1;
  color: #1e40af;
  font-size: 12px;
  font-weight: 800;
}
.check-line { display: flex; align-items: center; gap: 7px; padding-top: 19px; }
.check-line input { width: auto; min-height: auto; }
.compact-check { padding-top: 19px; }
.cot-rong { grid-column: 1 / -1; }
.hang-nut { display: flex; flex-wrap: wrap; gap: 6px; }
.canh-bao-nho { margin: 10px 10px 0; padding: 8px 10px; border: 1px solid #fed7aa; border-radius: 5px; background: #fff7ed; color: #9a3412; font-size: 12px; }
.input-file-hidden { display: none; }

.thong-bao-khu-vuc {
  min-height: 31px;
  display: flex;
  align-items: center;
  margin: 8px 10px 0;
  padding: 7px 10px;
  border: 1px solid #dbeafe;
  border-radius: 6px;
  background: #f8fbff;
  color: #334155;
  font-size: 12px;
  font-weight: 700;
  line-height: 1.35;
}
.thong-bao-khu-vuc.info { border-color: #dbeafe; background: #f8fbff; color: #1e40af; }
.thong-bao-khu-vuc.success { border-color: #bbf7d0; background: #f0fdf4; color: #166534; }
.thong-bao-khu-vuc.error { border-color: #fecaca; background: #fef2f2; color: #b91c1c; }
.thong-bao-khu-vuc.warning { border-color: #fed7aa; background: #fff7ed; color: #9a3412; }

.hop-rong, .rong { color: #6b7280; text-align: center; }
.hop-rong { padding: 26px; }
.bang-boc { max-height: 430px; overflow: auto; border-top: 1px solid #e5e7eb; }
.bang-du-lieu { width: 100%; min-width: 620px; border-collapse: collapse; font-size: 12.5px; }
.bang-chuong-bai { min-width: 980px; }
.khoi-tai-lieu .form-nho { grid-template-columns: repeat(2, minmax(150px, 1fr)); }
.khoi-tai-lieu .form-gan { padding-top: 8px; }
.khoi-tai-lieu .bang-boc { max-height: 300px; }

.khoi-chuong-bai .bang-boc { max-height: 360px; }
th, td { border: 1px solid #e5e7eb; padding: 7px 8px; text-align: left; vertical-align: top; }
th { position: sticky; top: 0; z-index: 5; background: #f1f5f9; color: #334155; font-size: 12px; font-weight: 800; white-space: nowrap; }
td { background: #fff; }
tr:nth-child(even) td { background: #fcfcfd; }
.cot-so { width: 64px; text-align: center; white-space: nowrap; }
.cot-noi-dung { min-width: 220px; color: #334155; }
.cot-ghi-chu-bang { min-width: 160px; color: #475569; }
.cot-thao-tac { width: 128px; text-align: center; }
.thao-tac { display: flex; flex-wrap: wrap; justify-content: center; align-items: center; gap: 5px; }
.khoi-tai-lieu .bang-boc { border: 1px solid #dbe4f0; border-radius: 0 0 6px 6px; background: #fff; }
.khoi-tai-lieu .bang-du-lieu { min-width: 640px; table-layout: fixed; }
.khoi-tai-lieu th { background: #eaf3ff; color: #1e3a8a; border-color: #d4e5fb; }
.khoi-tai-lieu td { border-color: #e2e8f0; }
.khoi-tai-lieu tbody tr:hover td { background: #f8fbff; }
.khoi-tai-lieu .cot-tt { width: 44px; }
.khoi-tai-lieu .cot-tai-lieu-ten { width: 34%; font-weight: 600; color: #0f172a; }
.khoi-tai-lieu .cot-bat-buoc { width: 82px; }
.khoi-tai-lieu .cot-mo-doc { width: 80px; }
.khoi-tai-lieu .cot-ghi-chu { width: 26%; color: #475569; }
.cot-can-giua { text-align: center; vertical-align: middle; }
.nut { min-height: 29px; border: 1px solid #cbd5e1; border-radius: 4px; background: #fff; color: #111827; padding: 5px 9px; font-size: 12px; cursor: pointer; font-family: Roboto, Arial, sans-serif; }
.nut:hover { background: #f8fafc; }
.nut:disabled { cursor: not-allowed; opacity: .6; }
.nut.chinh { border-color: #2563eb; background: #2563eb; color: #fff; }
.nut.nguy-hiem { border-color: #fecaca; background: #fff1f2; color: #b91c1c; }
.nut.nho { min-height: 25px; padding: 3px 8px; font-size: 11px; font-weight: 700; }
.nut-sua { border-color: #bfdbfe; background: #eff6ff; color: #1d4ed8; }
.nut-sua:hover { background: #dbeafe; }
.nut-xoa { border-color: #fecaca; background: #fff1f2; color: #be123c; }
.nut-xoa:hover { background: #ffe4e6; }
.nut-mo-doc { border-color: #bbf7d0; background: #f0fdf4; color: #15803d; }
.nut-mo-doc:hover { background: #dcfce7; }
.nut-xem-file { border-color: #bfdbfe; background: #eff6ff; color: #1d4ed8; }
.nut-xem-file:hover { background: #dbeafe; }

/* Bảng tài liệu gốc: dùng :deep vì bảng được render trong component con BangDonGian */
.khoi-tai-lieu :deep(.bang-boc) {
  margin: 0 10px 10px;
  max-height: 340px;
  overflow: auto;
  border: 1px solid #d7e3f3;
  border-radius: 8px;
  background: #ffffff;
  box-shadow: 0 1px 2px rgba(15, 23, 42, 0.06);
}

.khoi-tai-lieu :deep(.bang-du-lieu) {
  width: 100%;
  min-width: 1180px;
  table-layout: fixed;
  border-collapse: separate;
  border-spacing: 0;
  font-size: 12.5px;
}

.khoi-tai-lieu :deep(th) {
  position: sticky;
  top: 0;
  z-index: 6;
  border: 0;
  border-bottom: 1px solid #cfe0f5;
  background: linear-gradient(180deg, #f4f9ff 0%, #eaf3ff 100%);
  color: #1e3a8a;
  font-size: 12px;
  font-weight: 800;
  text-align: left;
  white-space: nowrap;
}

.khoi-tai-lieu :deep(td) {
  border: 0;
  border-bottom: 1px solid #edf2f7;
  background: #ffffff;
  color: #1f2937;
  line-height: 1.45;
}

.khoi-tai-lieu :deep(tbody tr:last-child td) {
  border-bottom: 0;
}

.khoi-tai-lieu :deep(tbody tr:hover td) {
  background: #f8fbff;
}

.khoi-tai-lieu :deep(.cot-tt) {
  width: 42px;
  text-align: center;
  color: #475569;
  font-weight: 700;
}

.khoi-tai-lieu :deep(.cot-ma-tai-lieu) {
  width: 110px;
  color: #1e3a8a;
  font-weight: 800;
  word-break: break-word;
}

.khoi-tai-lieu :deep(.cot-tai-lieu-ten) {
  width: 260px;
  color: #0f172a;
  font-weight: 700;
  word-break: break-word;
}

.khoi-tai-lieu :deep(.cot-loai-tai-lieu) {
  width: 90px;
}

.khoi-tai-lieu :deep(.cot-tac-gia) {
  width: 130px;
  word-break: break-word;
}

.khoi-tai-lieu :deep(.cot-nxb) {
  width: 130px;
  word-break: break-word;
}

.khoi-tai-lieu :deep(.cot-nam-xb) {
  width: 64px;
}

.khoi-tai-lieu :deep(.cot-bat-buoc) {
  width: 76px;
  text-align: center;
}

.khoi-tai-lieu :deep(.cot-xem-file) {
  width: 92px;
  text-align: center;
}

.khoi-tai-lieu :deep(.cot-mo-doc) {
  width: 78px;
  text-align: center;
}

.khoi-tai-lieu :deep(.cot-ghi-chu) {
  width: 170px;
  color: #475569;
  word-break: break-word;
}

.khoi-tai-lieu :deep(.cot-thao-tac) {
  width: 118px;
  text-align: center;
}

.khoi-tai-lieu :deep(.thao-tac) {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 6px;
  min-width: 108px;
}

.khoi-tai-lieu :deep(.nut) {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-height: 26px;
  border-radius: 999px;
  padding: 4px 10px;
  font-size: 11.5px;
  font-weight: 800;
  line-height: 1;
  cursor: pointer;
  transition: background .15s ease, border-color .15s ease, transform .15s ease;
}

.khoi-tai-lieu :deep(.nut:hover) {
  transform: translateY(-1px);
}

.khoi-tai-lieu :deep(.nut-sua) {
  border: 1px solid #bfdbfe;
  background: #eff6ff;
  color: #1d4ed8;
}

.khoi-tai-lieu :deep(.nut-sua:hover) {
  background: #dbeafe;
}

.khoi-tai-lieu :deep(.nut-xoa) {
  border: 1px solid #fecaca;
  background: #fff1f2;
  color: #be123c;
}

.khoi-tai-lieu :deep(.nut-xoa:hover) {
  background: #ffe4e6;
}

.khoi-tai-lieu :deep(.nut-xem-file) {
  border: 1px solid #bfdbfe;
  background: #eff6ff;
  color: #1d4ed8;
}

.khoi-tai-lieu :deep(.nut-xem-file:hover) {
  background: #dbeafe;
}

.khoi-tai-lieu :deep(.nut-mo-doc) {
  border: 1px solid #bbf7d0;
  background: #f0fdf4;
  color: #15803d;
}

.khoi-tai-lieu :deep(.nut-mo-doc:hover) {
  background: #dcfce7;
}



/* Bảng điều kiện gốc: gọn, rõ cột, đồng bộ bảng tài liệu */
.khoi-dieu-kien :deep(.bang-boc) {
  margin: 0 10px 10px;
  max-height: 320px;
  overflow: auto;
  border: 1px solid #e2ddf5;
  border-radius: 8px;
  background: #ffffff;
  box-shadow: 0 1px 2px rgba(15, 23, 42, 0.06);
}

.khoi-dieu-kien :deep(.bang-du-lieu) {
  width: 100%;
  min-width: 720px;
  table-layout: fixed;
  border-collapse: separate;
  border-spacing: 0;
  font-size: 12.5px;
}

.khoi-dieu-kien :deep(th) {
  position: sticky;
  top: 0;
  z-index: 6;
  border: 0;
  border-bottom: 1px solid #ddd6fe;
  background: linear-gradient(180deg, #faf7ff 0%, #f1ecff 100%);
  color: #4c1d95;
  font-size: 12px;
  font-weight: 800;
  text-align: left;
  white-space: nowrap;
}

.khoi-dieu-kien :deep(td) {
  border: 0;
  border-bottom: 1px solid #f1eefb;
  background: #ffffff;
  color: #1f2937;
  line-height: 1.45;
}

.khoi-dieu-kien :deep(tbody tr:last-child td) {
  border-bottom: 0;
}

.khoi-dieu-kien :deep(tbody tr:hover td) {
  background: #fbfaff;
}

.khoi-dieu-kien :deep(.cot-tt) {
  width: 42px;
  text-align: center;
  color: #6b7280;
  font-weight: 700;
}

.khoi-dieu-kien :deep(.cot-dieu-kien-noi-dung) {
  width: 48%;
  color: #111827;
  font-weight: 600;
  word-break: break-word;
}

.khoi-dieu-kien :deep(.cot-dieu-kien-loai) {
  width: 100px;
  text-align: center;
  color: #4c1d95;
  font-weight: 700;
}

.khoi-dieu-kien :deep(.cot-ghi-chu) {
  width: 24%;
  color: #475569;
  word-break: break-word;
}

.khoi-dieu-kien :deep(.cot-thao-tac) {
  width: 118px;
  text-align: center;
}

.khoi-dieu-kien :deep(.thao-tac) {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 6px;
  min-width: 108px;
}

.khoi-dieu-kien :deep(.nut) {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-height: 26px;
  border-radius: 999px;
  padding: 4px 10px;
  font-size: 11.5px;
  font-weight: 800;
  line-height: 1;
  cursor: pointer;
  transition: background .15s ease, border-color .15s ease, transform .15s ease;
}

.khoi-dieu-kien :deep(.nut:hover) {
  transform: translateY(-1px);
}

.khoi-dieu-kien :deep(.nut-sua) {
  border: 1px solid #c4b5fd;
  background: #f5f3ff;
  color: #6d28d9;
}

.khoi-dieu-kien :deep(.nut-sua:hover) {
  background: #ede9fe;
}

.khoi-dieu-kien :deep(.nut-xoa) {
  border: 1px solid #fecaca;
  background: #fff1f2;
  color: #be123c;
}

.khoi-dieu-kien :deep(.nut-xoa:hover) {
  background: #ffe4e6;
}
.khoi-dieu-kien :deep(.cot-dieu-kien-ma) {
  width: 120px;
  color: #4c1d95;
  font-weight: 800;
  word-break: break-word;
}
@media (max-width: 1350px) { .luoi-chinh { grid-template-columns: 1fr; } }
@media (max-width: 980px) { .luoi-trang { grid-template-columns: 1fr; } .danh-sach-mon { min-height: 0; max-height: 420px; } }
@media (max-width: 720px) { .khoi-dau, .thanh-mon { flex-direction: column; align-items: stretch; } .form-grid, .form-syllabus, .form-nho { grid-template-columns: 1fr; } }
</style>
