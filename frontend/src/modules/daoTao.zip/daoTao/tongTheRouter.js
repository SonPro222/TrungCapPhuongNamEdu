import {ROLES} from '@/core/constants/roles'
import {requireAuth} from '@/core/guards/authGuard'
import {requireAdmin} from '@/core/guards/adminGuard'
import DaoTaoLayout from './layouts/DaoTaoLayout.vue'
import XemTongTheChuongTrinhPage from './pages/TongThe/XemTongTheChuongTrinhPage.vue'
import XemKyChuongTrinhPage from './pages/TongThe/XemKyChuongTrinhPage.vue'
import XemSyllabusMonHocPage from './pages/TongThe/XemSyllabusMonHocPage.vue'

export const tongTheRoutes = [
    {
        path: 'dao-tao',
        component: DaoTaoLayout,
        beforeEnter: [requireAuth, requireAdmin],
        meta: {
            module: 'daoTao',
            title: 'Đào tạo',
            roles: [ROLES.ADMIN, ROLES.DAO_TAO]
        },
        children: [
            {
                path: 'chuong-trinh/tong-quan',
                name: 'dao-tao-chuong-trinh-tong-quan',
                component: XemTongTheChuongTrinhPage,
                meta: {
                    title: 'Đào tạo - Tổng quan chương trình đào tạo',
                    roles: [ROLES.ADMIN, ROLES.DAO_TAO]
                }
            },
            {
                path: 'chuong-trinh/:chuongTrinhId/ky',
                name: 'dao-tao-chuong-trinh-ky',
                component: XemKyChuongTrinhPage,
                meta: {
                    title: 'Đào tạo - Xem kỳ chương trình',
                    roles: [ROLES.ADMIN, ROLES.DAO_TAO]
                }
            },
            {
                path: 'syllabus-mon-hoc/xem',
                name: 'dao-tao-syllabus-mon-hoc-xem',
                component: XemSyllabusMonHocPage,
                meta: {
                    title: 'Đào tạo - Xem syllabus môn học',
                    roles: [ROLES.ADMIN, ROLES.DAO_TAO]
                }
            }
        ]
    }
]