<template>
  <div class="xem-danh-sach-nut">
    <button
        v-for="(item, index) in danhSach"
        :key="item.id || index"
        type="button"
        class="nut-card"
        :class="`nut-card--mau-${index % 8}`"
        @click="$emit('chon', item)"
    >
      <span class="nut-card__so">Mục {{ index + 1 }}</span>
      <span class="nut-card__ten">{{ layTen(item) }}</span>
      <span v-if="moTaKeys.length" class="nut-card__phu">{{ layMoTa(item) }}</span>
      <span class="nut-card__xem">Xem tiếp →</span>
    </button>
  </div>
</template>

<script setup>
import { layTenHienThi } from '../services/xemChuongTrinhService'

const props = defineProps({
  danhSach: {
    type: Array,
    default: () => []
  },
  tenKeys: {
    type: Array,
    default: () => []
  },
  moTaKeys: {
    type: Array,
    default: () => []
  }
})

defineEmits(['chon'])

function layTen(item) {
  return layTenHienThi(item, props.tenKeys)
}

function layMoTa(item) {
  for (const key of props.moTaKeys) {
    const value = item?.[key]
    if (value !== null && value !== undefined && value !== '') return value
  }
  return ''
}
</script>

<style scoped>
.xem-danh-sach-nut {
  width: min(1120px, 100%);
  margin: 0 auto;
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 18px;
  font-family: 'Roboto', Arial, sans-serif;
}

.nut-card {
  min-height: 138px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 8px;
  text-align: left;
  border: 0;
  border-radius: 22px;
  padding: 18px;
  color: #ffffff;
  cursor: pointer;
  box-shadow: 0 14px 30px rgba(15, 23, 42, 0.16);
  transition:
      transform 0.18s ease,
      box-shadow 0.18s ease,
      filter 0.18s ease;
}

.nut-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 20px 42px rgba(15, 23, 42, 0.22);
  filter: brightness(1.04);
}

.nut-card:active {
  transform: translateY(-1px);
}

.nut-card__so {
  display: inline-flex;
  margin-bottom: 4px;
  padding: 5px 10px;
  border-radius: 999px;
  background: rgba(255, 255, 255, 0.22);
  color: rgba(255, 255, 255, 0.92);
  font-size: 12px;
  font-weight: 700;
}

.nut-card__ten {
  display: block;
  color: #ffffff;
  font-size: 18px;
  line-height: 1.28;
  font-weight: 850;
}

.nut-card__phu {
  display: block;
  color: rgba(255, 255, 255, 0.86);
  font-size: 13px;
  line-height: 1.4;
  font-weight: 500;
}

.nut-card__xem {
  display: block;
  margin-top: auto;
  color: rgba(255, 255, 255, 0.94);
  font-size: 13px;
  font-weight: 700;
}

.nut-card--mau-0 {
  background: linear-gradient(135deg, #2563eb, #06b6d4);
}

.nut-card--mau-1 {
  background: linear-gradient(135deg, #7c3aed, #ec4899);
}

.nut-card--mau-2 {
  background: linear-gradient(135deg, #059669, #22c55e);
}

.nut-card--mau-3 {
  background: linear-gradient(135deg, #ea580c, #f59e0b);
}

.nut-card--mau-4 {
  background: linear-gradient(135deg, #0891b2, #6366f1);
}

.nut-card--mau-5 {
  background: linear-gradient(135deg, #be123c, #f43f5e);
}

.nut-card--mau-6 {
  background: linear-gradient(135deg, #4338ca, #8b5cf6);
}

.nut-card--mau-7 {
  background: linear-gradient(135deg, #0f766e, #14b8a6);
}

@media (max-width: 1100px) {
  .xem-danh-sach-nut {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
}

@media (max-width: 820px) {
  .xem-danh-sach-nut {
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 14px;
  }

  .nut-card {
    min-height: 128px;
    border-radius: 18px;
    padding: 16px;
  }

  .nut-card__ten {
    font-size: 16px;
  }
}

@media (max-width: 520px) {
  .xem-danh-sach-nut {
    grid-template-columns: 1fr;
  }
}
</style>