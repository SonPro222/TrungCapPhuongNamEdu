import { ROLES } from '@/core/constants/roles'
import { requireAuth } from '@/core/guards/authGuard'
import { requireAdmin } from '@/core/guards/adminGuard'

import SinhVienLayout from './layouts/SinhVienLayout.vue'
import AdminSinhVienFlowPage from './pages/AdminSinhVienFlowPage.vue'
import AdminSinhVienBaoLuuPage from './pages/AdminSinhVienBaoLuuPage.vue'

export const sinhVienRoutes = [
    {
        path: 'sinh-vien',
        component: SinhVienLayout,
        beforeEnter: [requireAuth, requireAdmin],
        meta: {
            module: 'sinhVien',
            title: 'Sinh viên',
            roles: [ROLES.ADMIN]
        },
        children: [
            {
                path: '',
                name: 'AdminSinhVienFlow',
                component: AdminSinhVienFlowPage,
                meta: {
                    title: 'Quản lý sinh viên',
                    roles: [ROLES.ADMIN]
                }
            },
            {
                path: 'bao-luu',
                name: 'AdminSinhVienBaoLuu',
                component: AdminSinhVienBaoLuuPage,
                meta: {
                    title: 'Danh sách sinh viên bảo lưu',
                    roles: [ROLES.ADMIN]
                }
            }
        ]
    }
]
