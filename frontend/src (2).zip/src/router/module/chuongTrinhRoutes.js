export { default } from '@/modules/chuong-trinh/router.js';
