import './assets/main.css'

// Bootstrap
import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap/dist/js/bootstrap.bundle.min.js'

// Vue
import { createApp } from 'vue'
import App from './App.vue'

// Router
import router from './router/router.js'

const app = createApp(App)

app.use(router)

app.mount('#app')