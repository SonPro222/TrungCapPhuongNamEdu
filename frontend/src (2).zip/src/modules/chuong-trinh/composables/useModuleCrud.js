import { computed, ref, watch } from 'vue';
import { unwrapApiList } from '@/api/apiResponse.js';
import { normalizeRole } from '@/utils/permission.js';

const toSnakeCase = (value) => String(value).replace(/[A-Z]/g, (letter) => `_${letter.toLowerCase()}`);

const getValue = (item, key) => {
  if (!item || !key) return undefined;
  if (Object.prototype.hasOwnProperty.call(item, key)) return item[key];
  return item[toSnakeCase(key)];
};

const normalizeComparable = (value) => String(value ?? '').trim();

const isNumberLikeKey = (key = '') => /(^id$|Id$|ID$|_id$)/.test(key);

const normalizeInputValue = (field, value) => {
  if (field.type === 'checkbox') return Boolean(value);
  if (value === '' || value === undefined) return null;
  if (field.type === 'number' || isNumberLikeKey(field.key)) {
    const numberValue = Number(value);
    return Number.isNaN(numberValue) ? value : numberValue;
  }
  return value;
};

const getCurrentRoles = () => {
  const directRole = localStorage.getItem('role');
  const roles = [];
  if (directRole) roles.push(directRole);

  try {
    const rawUser = localStorage.getItem('user') || localStorage.getItem('authUser');
    const user = rawUser ? JSON.parse(rawUser) : {};
    const userRoles = user.roles || user.vaiTro || user.role || [];
    roles.push(...(Array.isArray(userRoles) ? userRoles : [userRoles]));
  } catch {
    // Không chặn thao tác UI chỉ vì localStorage user bị sai định dạng.
  }

  return [...new Set(roles.map(normalizeRole).filter(Boolean))];
};

export const buildContextPayload = (config, routeContext = {}) => {
  const payload = {};
  Object.entries(config?.contextFields || {}).forEach(([paramKey, fieldKey]) => {
    const value = routeContext[paramKey];
    if (value !== undefined && value !== null && value !== '') {
      payload[fieldKey] = normalizeInputValue({ key: fieldKey, type: 'select' }, value);
    }
  });
  return payload;
};

export const filterRowsByContext = (rows, config, routeContext = {}) => {
  const contextEntries = Object.entries(config?.contextFields || {})
    .map(([paramKey, fieldKey]) => [fieldKey, routeContext[paramKey]])
    .filter(([, value]) => value !== undefined && value !== null && value !== '');

  if (!contextEntries.length) return rows;

  return rows.filter((row) => contextEntries.every(([fieldKey, expected]) => (
    normalizeComparable(getValue(row, fieldKey)) === normalizeComparable(expected)
  )));
};

const normalizePayload = (values, config, routeContext = {}) => {
  const contextPayload = buildContextPayload(config, routeContext);
  const source = { ...values, ...contextPayload };
  const payload = {};

  (config?.formFields || []).forEach((field) => {
    if (field.system || field.readOnly || field.key === config.primaryKey) return;
    if (!Object.prototype.hasOwnProperty.call(source, field.key)) return;
    payload[field.key] = normalizeInputValue(field, source[field.key]);
  });

  Object.entries(contextPayload).forEach(([key, value]) => {
    payload[key] = value;
  });

  return payload;
};

export const useModuleCrud = (configRef, routeContextRef) => {
  const rows = ref([]);
  const loading = ref(false);
  const submitting = ref(false);
  const error = ref('');
  const formError = ref('');
  const searchText = ref('');
  const page = ref(1);
  const pageSize = ref(10);
  const modalOpen = ref(false);
  const editingRow = ref(null);

  const config = computed(() => configRef.value || null);
  const routeContext = computed(() => routeContextRef.value || {});
  const contextPayload = computed(() => buildContextPayload(config.value, routeContext.value));

  const listParams = computed(() => ({ ...contextPayload.value }));

  const loadData = async () => {
    if (!config.value?.service?.list) return;

    loading.value = true;
    error.value = '';
    try {
      const response = await config.value.service.list(listParams.value);
      const list = unwrapApiList(response);
      rows.value = filterRowsByContext(list, config.value, routeContext.value);
      page.value = 1;
    } catch (err) {
      error.value = err?.message || 'Không tải được dữ liệu.';
      rows.value = [];
    } finally {
      loading.value = false;
    }
  };

  const filteredRows = computed(() => {
    const keyword = searchText.value.trim().toLowerCase();
    if (!keyword) return rows.value;

    const fields = config.value?.searchFields?.length
      ? config.value.searchFields
      : (config.value?.columns || []).map((column) => column.key);

    return rows.value.filter((row) => fields.some((fieldKey) => (
      String(getValue(row, fieldKey) ?? '').toLowerCase().includes(keyword)
    )));
  });

  const total = computed(() => filteredRows.value.length);
  const pageCount = computed(() => Math.max(1, Math.ceil(total.value / pageSize.value)));

  const pagedRows = computed(() => {
    const safePage = Math.min(page.value, pageCount.value);
    const start = (safePage - 1) * pageSize.value;
    return filteredRows.value.slice(start, start + pageSize.value);
  });

  const can = (action) => {
    const allowed = (config.value?.permissions?.[action] || []).map(normalizeRole).filter(Boolean);
    const roles = getCurrentRoles();
    if (!allowed.length || !roles.length) return true;
    return roles.some((role) => allowed.includes(role));
  };

  const openCreate = () => {
    editingRow.value = null;
    formError.value = '';
    modalOpen.value = true;
  };

  const openEdit = (row) => {
    editingRow.value = { ...row };
    formError.value = '';
    modalOpen.value = true;
  };

  const closeModal = () => {
    modalOpen.value = false;
    editingRow.value = null;
    formError.value = '';
  };

  const submit = async (values) => {
    if (!config.value?.service) return;
    submitting.value = true;
    formError.value = '';

    try {
      const payload = normalizePayload(values, config.value, routeContext.value);
      const primaryKey = config.value.primaryKey || 'id';
      const id = getValue(editingRow.value, primaryKey);

      if (id) await config.value.service.update(id, payload);
      else await config.value.service.create(payload);

      closeModal();
      await loadData();
    } catch (err) {
      formError.value = err?.message || 'Không lưu được dữ liệu.';
    } finally {
      submitting.value = false;
    }
  };

  const remove = async (row) => {
    if (!config.value?.service?.remove) return;
    const primaryKey = config.value.primaryKey || 'id';
    const id = getValue(row, primaryKey);
    if (!id || !window.confirm('Xóa bản ghi này?')) return;

    submitting.value = true;
    try {
      await config.value.service.remove(id);
      await loadData();
    } catch (err) {
      error.value = err?.message || 'Không xóa được dữ liệu.';
    } finally {
      submitting.value = false;
    }
  };

  watch([config, routeContext], () => {
    searchText.value = '';
    page.value = 1;
    loadData();
  }, { immediate: true, deep: true });

  watch([searchText, pageSize], () => {
    page.value = 1;
  });

  watch(pageCount, (value) => {
    if (page.value > value) page.value = value;
  });

  return {
    rows,
    loading,
    submitting,
    error,
    formError,
    searchText,
    page,
    pageSize,
    filteredRows,
    pagedRows,
    total,
    pageCount,
    modalOpen,
    editingRow,
    contextPayload,
    can,
    loadData,
    openCreate,
    openEdit,
    closeModal,
    submit,
    remove,
  };
};
