import { computed } from 'vue';
import { useRoute } from 'vue-router';
import {
  DEFAULT_MODULE_KEY,
  MODULE_FLOW_BY_KEY,
  ROUTE_PATH_TO_KEY,
} from '../configs/module-flow.config.js';
import { CHUONG_TRINH_MODULE_CONFIG_BY_KEY } from '../configs/chuong-trinh.config.js';

const BASE_PATH = '/chuong-trinh';

const normalizeSegments = (segments) => {
  if (Array.isArray(segments)) return segments.filter(Boolean);
  if (typeof segments === 'string') return segments.split('/').filter(Boolean);
  return [];
};

const encodePathValue = (value) => encodeURIComponent(String(value));

export const buildPathFromTrail = (trail, toIndex = trail.length - 1, includeCurrentId = false) => {
  const parts = [BASE_PATH];
  trail.slice(0, toIndex + 1).forEach((item, index) => {
    parts.push(item.routePath);
    if (item.id && (index < toIndex || includeCurrentId)) {
      parts.push(encodePathValue(item.id));
    }
  });
  return parts.join('/');
};

export const parseChuongTrinhRoute = (route) => {
  const segments = normalizeSegments(route?.params?.segments);
  const safeSegments = segments.length ? segments : [CHUONG_TRINH_MODULE_CONFIG_BY_KEY[DEFAULT_MODULE_KEY].routePath];
  const trail = [];
  const context = {};

  for (let index = 0; index < safeSegments.length; index += 1) {
    const segment = safeSegments[index];
    const key = ROUTE_PATH_TO_KEY[segment];
    const config = key ? CHUONG_TRINH_MODULE_CONFIG_BY_KEY[key] : null;

    if (!config) continue;

    const nextSegment = safeSegments[index + 1];
    const nextIsRoutePath = Boolean(ROUTE_PATH_TO_KEY[nextSegment]);
    const id = nextSegment && !nextIsRoutePath ? nextSegment : null;

    if (id) {
      context[config.idParam] = id;
      index += 1;
    }

    trail.push({
      key: config.key,
      title: config.title,
      routePath: config.routePath,
      idParam: config.idParam,
      id,
      config,
    });
  }

  if (!trail.length) {
    const config = CHUONG_TRINH_MODULE_CONFIG_BY_KEY[DEFAULT_MODULE_KEY];
    trail.push({
      key: config.key,
      title: config.title,
      routePath: config.routePath,
      idParam: config.idParam,
      id: null,
      config,
    });
  }

  const current = trail[trail.length - 1];

  return {
    segments: safeSegments,
    trail,
    context,
    currentKey: current.key,
    currentConfig: current.config,
    currentPath: buildPathFromTrail(trail, trail.length - 1, false),
  };
};

export const buildChildPath = (trail, currentConfig, row) => {
  const primaryKey = currentConfig?.primaryKey || 'id';
  const rowId = row?.[primaryKey] ?? row?.id;
  const childKey = currentConfig?.childKey;
  const childConfig = childKey ? CHUONG_TRINH_MODULE_CONFIG_BY_KEY[childKey] : null;

  if (!rowId || !childConfig) return null;

  return `${buildPathFromTrail(trail, trail.length - 1, false)}/${encodePathValue(rowId)}/${childConfig.routePath}`;
};

export const useModuleBreadcrumb = () => {
  const route = useRoute();
  const parsedRoute = computed(() => parseChuongTrinhRoute(route));
  const currentConfig = computed(() => parsedRoute.value.currentConfig);
  const currentContext = computed(() => parsedRoute.value.context);

  const breadcrumbItems = computed(() => parsedRoute.value.trail.map((item, index) => ({
    key: item.key,
    title: item.title,
    id: item.id,
    to: buildPathFromTrail(parsedRoute.value.trail, index, false),
    active: index === parsedRoute.value.trail.length - 1,
  })));

  const routeText = computed(() => parsedRoute.value.currentPath);

  return {
    parsedRoute,
    currentConfig,
    currentContext,
    breadcrumbItems,
    routeText,
  };
};
