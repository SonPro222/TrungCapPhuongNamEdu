<template>
  <section class="table-card">
    <div class="table-toolbar">
      <div class="toolbar-title">
        <h2>{{ config.title }}</h2>
        <span>{{ total }} bản ghi</span>
      </div>

      <div class="toolbar-actions">
        <div class="search-box">
          <span>⌕</span>
          <input
            :value="searchText"
            type="search"
            placeholder="Tìm kiếm..."
            @input="$emit('update:searchText', $event.target.value)"
          />
        </div>

        <button
          v-if="canCreate"
          class="btn btn-primary btn-sm"
          type="button"
          @click="$emit('add')"
        >
          + Thêm
        </button>
      </div>
    </div>

    <div v-if="error" class="alert alert-danger py-2 mb-3">
      {{ error }}
    </div>

    <div class="table-responsive table-shell">
      <table class="module-table">
        <thead>
          <tr>
            <th class="index-col">#</th>
            <th
              v-for="column in config.columns"
              :key="column.key"
              :class="{ 'text-end': column.align === 'right' }"
              :style="columnStyle(column)"
            >
              {{ column.label }}
            </th>
            <th class="action-col">Thao tác</th>
          </tr>
        </thead>

        <tbody>
          <tr v-if="loading">
            <td :colspan="colspan" class="state-cell">
              <div class="spinner-border spinner-border-sm me-2" role="status"></div>
              Đang tải dữ liệu...
            </td>
          </tr>

          <tr v-else-if="!rows.length">
            <td :colspan="colspan" class="state-cell empty-state">
              <strong>Chưa có dữ liệu</strong>
              <span>Tạo bản ghi mới hoặc thay đổi từ khóa tìm kiếm.</span>
            </td>
          </tr>

          <template v-else>
            <tr
              v-for="(row, index) in rows"
              :key="row[config.primaryKey] || index"
              :class="{ clickable: Boolean(config.childKey) }"
              @click="$emit('row-click', row)"
            >
              <td class="index-col">{{ rowNumber(index) }}</td>
              <td
                v-for="column in config.columns"
                :key="column.key"
                :class="[{ 'text-end': column.align === 'right' }, { truncate: column.truncate }]"
                :title="stringValue(row, column)"
              >
                <span v-if="column.type === 'boolean'" :class="['status-pill', truthyValue(row, column) ? 'yes' : 'no']">
                  {{ truthyValue(row, column) ? 'Có' : 'Không' }}
                </span>
                <span v-else>{{ formatValue(row, column) }}</span>
              </td>
              <td class="action-col" @click.stop>
                <div class="action-buttons">
                  <button
                    v-if="config.childKey"
                    class="btn btn-outline-primary btn-xs"
                    type="button"
                    @click="$emit('view-child', row)"
                  >
                    Chi tiết
                  </button>
                  <button
                    v-if="canEdit"
                    class="btn btn-outline-secondary btn-xs"
                    type="button"
                    @click="$emit('edit', row)"
                  >
                    Sửa
                  </button>
                  <button
                    v-if="canDelete"
                    class="btn btn-outline-danger btn-xs"
                    type="button"
                    @click="$emit('delete', row)"
                  >
                    Xóa
                  </button>
                </div>
              </td>
            </tr>
          </template>
        </tbody>
      </table>
    </div>

    <div class="table-footer">
      <div class="page-size">
        <span>Hiển thị</span>
        <select :value="pageSize" @change="$emit('update:pageSize', Number($event.target.value))">
          <option :value="10">10</option>
          <option :value="20">20</option>
          <option :value="50">50</option>
        </select>
        <span>dòng/trang</span>
      </div>

      <div class="pagination-box">
        <button class="btn btn-light btn-sm" :disabled="page <= 1" @click="$emit('update:page', page - 1)">
          Trước
        </button>
        <span>Trang {{ page }} / {{ pageCount }}</span>
        <button class="btn btn-light btn-sm" :disabled="page >= pageCount" @click="$emit('update:page', page + 1)">
          Sau
        </button>
      </div>
    </div>
  </section>
</template>

<script setup>
import { computed } from 'vue';

const props = defineProps({
  config: {
    type: Object,
    required: true,
  },
  rows: {
    type: Array,
    default: () => [],
  },
  loading: Boolean,
  error: {
    type: String,
    default: '',
  },
  searchText: {
    type: String,
    default: '',
  },
  page: {
    type: Number,
    default: 1,
  },
  pageSize: {
    type: Number,
    default: 10,
  },
  pageCount: {
    type: Number,
    default: 1,
  },
  total: {
    type: Number,
    default: 0,
  },
  canCreate: Boolean,
  canEdit: Boolean,
  canDelete: Boolean,
});

defineEmits([
  'update:searchText',
  'update:page',
  'update:pageSize',
  'add',
  'edit',
  'delete',
  'row-click',
  'view-child',
]);

const toSnakeCase = (value) => String(value).replace(/[A-Z]/g, (letter) => `_${letter.toLowerCase()}`);
const getValue = (row, key) => row?.[key] ?? row?.[toSnakeCase(key)];
const colspan = computed(() => (props.config.columns?.length || 0) + 2);

const columnStyle = (column) => ({
  width: column.width,
  minWidth: column.minWidth || column.width,
});

const rowNumber = (index) => ((props.page - 1) * props.pageSize) + index + 1;
const stringValue = (row, column) => String(getValue(row, column.key) ?? '');
const truthyValue = (row, column) => Boolean(getValue(row, column.key));

const formatDate = (value, withTime = false) => {
  if (!value) return '';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat('vi-VN', {
    dateStyle: 'short',
    ...(withTime ? { timeStyle: 'short' } : {}),
  }).format(date);
};

const formatValue = (row, column) => {
  const value = getValue(row, column.key);
  if (value === null || value === undefined || value === '') return '—';
  if (column.type === 'date') return formatDate(value, false);
  if (column.type === 'datetime') return formatDate(value, true);
  return value;
};
</script>

<style scoped>
.table-card {
  display: flex;
  flex-direction: column;
  min-height: 0;
  border: 1px solid #e2e8f0;
  border-radius: 18px;
  background: #ffffff;
  box-shadow: 0 18px 42px rgba(15, 23, 42, 0.07);
  overflow: hidden;
}

.table-toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 14px;
  padding: 14px 16px;
  border-bottom: 1px solid #e2e8f0;
}

.toolbar-title h2 {
  margin: 0;
  color: #0f172a;
  font-size: 18px;
  font-weight: 900;
}

.toolbar-title span {
  color: #64748b;
  font-size: 12px;
  font-weight: 700;
}

.toolbar-actions {
  display: flex;
  align-items: center;
  gap: 10px;
}

.search-box {
  display: flex;
  align-items: center;
  gap: 8px;
  width: min(300px, 45vw);
  padding: 7px 10px;
  border: 1px solid #cbd5e1;
  border-radius: 999px;
  background: #f8fafc;
}

.search-box input {
  width: 100%;
  border: 0;
  outline: 0;
  background: transparent;
  color: #0f172a;
  font-size: 13px;
}

.table-shell {
  min-height: 280px;
  max-height: calc(100vh - 330px);
  overflow: auto;
}

.module-table {
  width: 100%;
  border-collapse: separate;
  border-spacing: 0;
  font-size: 13px;
}

.module-table thead th {
  position: sticky;
  top: 0;
  z-index: 1;
  padding: 10px 12px;
  background: #f8fafc;
  color: #334155;
  border-bottom: 1px solid #e2e8f0;
  white-space: nowrap;
  font-weight: 900;
}

.module-table tbody td {
  padding: 9px 12px;
  border-bottom: 1px solid #eef2f7;
  color: #334155;
  vertical-align: middle;
}

.module-table tbody tr:hover {
  background: #f8fafc;
}

.module-table tbody tr.clickable {
  cursor: pointer;
}

.index-col {
  width: 56px;
  color: #94a3b8 !important;
  text-align: center;
  font-weight: 800;
}

.action-col {
  position: sticky;
  right: 0;
  width: 190px;
  min-width: 190px;
  background: inherit;
  box-shadow: -8px 0 16px rgba(255, 255, 255, 0.7);
}

.action-buttons {
  display: flex;
  justify-content: flex-end;
  gap: 6px;
  white-space: nowrap;
}

.btn-xs {
  padding: 3px 8px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 800;
}

.truncate {
  max-width: 320px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.status-pill {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 52px;
  padding: 2px 8px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 900;
}

.status-pill.yes {
  background: #dcfce7;
  color: #166534;
}

.status-pill.no {
  background: #fee2e2;
  color: #991b1b;
}

.state-cell {
  height: 220px;
  color: #64748b;
  text-align: center;
}

.empty-state strong,
.empty-state span {
  display: block;
}

.empty-state strong {
  color: #0f172a;
  font-size: 15px;
}

.table-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  padding: 10px 14px;
  border-top: 1px solid #e2e8f0;
  background: #ffffff;
  color: #64748b;
  font-size: 13px;
  font-weight: 700;
}

.page-size,
.pagination-box {
  display: flex;
  align-items: center;
  gap: 8px;
}

.page-size select {
  padding: 4px 8px;
  border: 1px solid #cbd5e1;
  border-radius: 10px;
  background: #fff;
}

@media (max-width: 768px) {
  .table-toolbar,
  .table-footer {
    align-items: stretch;
    flex-direction: column;
  }

  .toolbar-actions,
  .search-box {
    width: 100%;
  }
}
</style>
