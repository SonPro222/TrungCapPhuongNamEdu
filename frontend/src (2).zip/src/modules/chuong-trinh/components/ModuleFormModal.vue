<template>
  <Teleport to="body">
    <div v-if="show" class="modal-backdrop-custom">
      <div class="modal-card">
        <div class="modal-header-custom">
          <div>
            <h3>{{ modelValue ? 'Cập nhật' : 'Thêm mới' }} {{ config.title }}</h3>
            <p>Form sinh từ schema/config, khóa cha được tự động gán theo breadcrumb hiện tại.</p>
          </div>
          <button class="btn-close" type="button" aria-label="Đóng" @click="$emit('close')"></button>
        </div>

        <form @submit.prevent="handleSubmit">
          <div class="modal-body-custom">
            <div v-if="formError" class="alert alert-danger py-2">
              {{ formError }}
            </div>
            <div v-if="localError" class="alert alert-warning py-2">
              {{ localError }}
            </div>

            <div class="form-grid">
              <div
                v-for="field in visibleFields"
                :key="field.key"
                :class="['form-field', { wide: isWideField(field) }]"
              >
                <label :for="fieldId(field)">
                  {{ field.label }}
                  <span v-if="field.required" class="required">*</span>
                  <small v-if="isAutoLocked(field)">Tự động</small>
                </label>

                <textarea
                  v-if="field.type === 'textarea'"
                  :id="fieldId(field)"
                  v-model="form[field.key]"
                  class="form-control form-control-sm"
                  rows="3"
                  :disabled="field.readOnly || isAutoLocked(field)"
                  :maxlength="field.maxLength"
                ></textarea>

                <select
                  v-else-if="field.type === 'select'"
                  :id="fieldId(field)"
                  v-model="form[field.key]"
                  class="form-select form-select-sm"
                  :disabled="field.readOnly || isAutoLocked(field)"
                  :required="field.required && !field.readOnly"
                >
                  <option value="">-- Chọn --</option>
                  <option
                    v-for="option in getOptions(field)"
                    :key="option.value"
                    :value="option.value"
                  >
                    {{ option.label }}
                  </option>
                </select>

                <div v-else-if="field.type === 'checkbox'" class="form-check form-switch compact-switch">
                  <input
                    :id="fieldId(field)"
                    v-model="form[field.key]"
                    class="form-check-input"
                    type="checkbox"
                    :disabled="field.readOnly || isAutoLocked(field)"
                  />
                  <label class="form-check-label" :for="fieldId(field)">
                    {{ form[field.key] ? 'Có' : 'Không' }}
                  </label>
                </div>

                <input
                  v-else
                  :id="fieldId(field)"
                  v-model="form[field.key]"
                  class="form-control form-control-sm"
                  :type="inputType(field)"
                  :disabled="field.readOnly || isAutoLocked(field)"
                  :required="field.required && !field.readOnly"
                  :min="field.min"
                  :max="field.max"
                  :step="field.step"
                  :maxlength="field.maxLength"
                />
              </div>
            </div>
          </div>

          <div class="modal-footer-custom">
            <button class="btn btn-light btn-sm" type="button" @click="$emit('close')">
              Hủy
            </button>
            <button class="btn btn-primary btn-sm" type="submit" :disabled="submitting">
              <span v-if="submitting" class="spinner-border spinner-border-sm me-1"></span>
              Lưu
            </button>
          </div>
        </form>
      </div>
    </div>
  </Teleport>
</template>

<script setup>
import { computed, reactive, ref, watch } from 'vue';
import { unwrapApiList } from '@/api/apiResponse.js';
import { CHUONG_TRINH_MODULE_CONFIG_BY_KEY } from '../configs/chuong-trinh.config.js';
import { SELECT_OPTIONS } from '../configs/form-fields.config.js';

const props = defineProps({
  show: Boolean,
  config: {
    type: Object,
    required: true,
  },
  modelValue: {
    type: Object,
    default: null,
  },
  contextValues: {
    type: Object,
    default: () => ({}),
  },
  submitting: Boolean,
  formError: {
    type: String,
    default: '',
  },
});

const emit = defineEmits(['close', 'submit']);

const form = reactive({});
const optionCache = reactive({});
const localError = ref('');

const toSnakeCase = (value) => String(value).replace(/[A-Z]/g, (letter) => `_${letter.toLowerCase()}`);
const getRowValue = (row, key) => row?.[key] ?? row?.[toSnakeCase(key)];

const fieldId = (field) => `${props.config.key}-${field.key}`;
const isWideField = (field) => field.type === 'textarea' || ['tenChuongTrinh', 'tenVersion', 'ten', 'noiDung'].includes(field.key);
const isAutoLocked = (field) => field.autoFromRoute && props.contextValues[field.key] !== undefined && props.contextValues[field.key] !== null && props.contextValues[field.key] !== '';
const inputType = (field) => (field.type === 'datetime-local' ? 'datetime-local' : field.type || 'text');

const visibleFields = computed(() => (props.config.formFields || []).filter((field) => {
  if (field.system && !props.modelValue) return false;
  return true;
}));

const getDefaultValue = (field) => {
  if (field.key in props.contextValues) return props.contextValues[field.key];
  if (field.default !== undefined) return field.default;
  if (field.type === 'checkbox') return false;
  return '';
};

const resetForm = () => {
  Object.keys(form).forEach((key) => delete form[key]);
  (props.config.formFields || []).forEach((field) => {
    const rowValue = getRowValue(props.modelValue, field.key);
    form[field.key] = rowValue ?? getDefaultValue(field);
    if (field.key in props.contextValues) {
      form[field.key] = props.contextValues[field.key];
    }
  });
  localError.value = '';
};

const loadOptions = async () => {
  const optionResources = [...new Set((props.config.formFields || [])
    .map((field) => field.optionResource)
    .filter(Boolean))];

  await Promise.all(optionResources.map(async (resourceKey) => {
    if (optionCache[resourceKey]) return;
    const optionConfig = CHUONG_TRINH_MODULE_CONFIG_BY_KEY[resourceKey];
    if (!optionConfig?.service?.list) {
      optionCache[resourceKey] = [];
      return;
    }

    try {
      const response = await optionConfig.service.list({});
      optionCache[resourceKey] = unwrapApiList(response).map((item) => ({
        value: item[optionConfig.primaryKey] ?? item.id,
        label: buildOptionLabel(item, optionConfig),
      }));
    } catch {
      optionCache[resourceKey] = [];
    }
  }));
};

const buildOptionLabel = (item, optionConfig) => {
  const keys = optionConfig.searchFields?.length ? optionConfig.searchFields : optionConfig.columns?.map((column) => column.key) || [];
  const values = keys
    .map((key) => getRowValue(item, key))
    .filter((value) => value !== undefined && value !== null && value !== '')
    .slice(0, 2);
  const id = item[optionConfig.primaryKey] ?? item.id;
  return values.length ? `${values.join(' - ')} (#${id})` : `#${id}`;
};

const getOptions = (field) => {
  if (field.optionKey) return SELECT_OPTIONS[field.optionKey] || [];
  if (field.optionResource) return optionCache[field.optionResource] || [];
  return [];
};

const validate = () => {
  const missing = (props.config.formFields || []).find((field) => {
    if (!field.required || field.readOnly || field.system) return false;
    const value = form[field.key];
    return value === undefined || value === null || value === '';
  });

  if (missing) {
    localError.value = `Vui lòng nhập ${missing.label}.`;
    return false;
  }

  localError.value = '';
  return true;
};

const handleSubmit = () => {
  if (!validate()) return;
  emit('submit', { ...form });
};

watch(() => props.show, async (show) => {
  if (!show) return;
  resetForm();
  await loadOptions();
}, { immediate: true });

watch(() => props.modelValue, () => {
  if (props.show) resetForm();
}, { deep: true });

watch(() => props.contextValues, () => {
  if (props.show) resetForm();
}, { deep: true });
</script>

<style scoped>
.modal-backdrop-custom {
  position: fixed;
  inset: 0;
  z-index: 1050;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 22px;
  background: rgba(15, 23, 42, 0.52);
}

.modal-card {
  width: min(980px, 100%);
  max-height: min(88vh, 860px);
  display: flex;
  flex-direction: column;
  border-radius: 20px;
  background: #ffffff;
  box-shadow: 0 30px 80px rgba(15, 23, 42, 0.28);
  overflow: hidden;
}

.modal-header-custom,
.modal-footer-custom {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 14px 18px;
  border-bottom: 1px solid #e2e8f0;
}

.modal-footer-custom {
  border-top: 1px solid #e2e8f0;
  border-bottom: 0;
}

.modal-header-custom h3 {
  margin: 0;
  color: #0f172a;
  font-size: 18px;
  font-weight: 900;
}

.modal-header-custom p {
  margin: 3px 0 0;
  color: #64748b;
  font-size: 12px;
  font-weight: 700;
}

.modal-body-custom {
  max-height: calc(88vh - 130px);
  padding: 16px 18px;
  overflow: auto;
}

.form-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 12px 14px;
}

.form-field.wide {
  grid-column: 1 / -1;
}

.form-field label {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-bottom: 5px;
  color: #334155;
  font-size: 12px;
  font-weight: 900;
}

.form-field label small {
  padding: 1px 6px;
  border-radius: 999px;
  background: #e0f2fe;
  color: #0369a1;
  font-size: 10px;
  font-weight: 900;
  text-transform: uppercase;
}

.required {
  color: #dc2626;
}

.compact-switch {
  min-height: 31px;
  display: flex;
  align-items: center;
  gap: 8px;
  padding-top: 3px;
}

@media (max-width: 768px) {
  .form-grid {
    grid-template-columns: 1fr;
  }
}
</style>
