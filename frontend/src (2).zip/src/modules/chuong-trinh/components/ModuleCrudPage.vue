<template>
  <main class="module-page" v-if="currentConfig">
    <div class="module-page-inner">
      <ModuleBreadcrumb :items="breadcrumbItems" :route-text="routeText" />

      <ModuleDataTable
        :config="currentConfig"
        :rows="crud.pagedRows.value"
        :loading="crud.loading.value"
        :error="crud.error.value"
        :search-text="crud.searchText.value"
        :page="crud.page.value"
        :page-size="crud.pageSize.value"
        :page-count="crud.pageCount.value"
        :total="crud.total.value"
        :can-create="crud.can('create')"
        :can-edit="crud.can('update')"
        :can-delete="crud.can('delete')"
        @update:search-text="crud.searchText.value = $event"
        @update:page="crud.page.value = $event"
        @update:page-size="crud.pageSize.value = $event"
        @add="crud.openCreate"
        @edit="crud.openEdit"
        @delete="crud.remove"
        @row-click="handleViewChild"
        @view-child="handleViewChild"
      />

      <ModuleFormModal
        :show="crud.modalOpen.value"
        :config="currentConfig"
        :model-value="crud.editingRow.value"
        :context-values="crud.contextPayload.value"
        :submitting="crud.submitting.value"
        :form-error="crud.formError.value"
        @close="crud.closeModal"
        @submit="crud.submit"
      />
    </div>
  </main>
</template>

<script setup>
import { computed, watch } from 'vue';
import { useRouter } from 'vue-router';
import ModuleBreadcrumb from './ModuleBreadcrumb.vue';
import ModuleDataTable from './ModuleDataTable.vue';
import ModuleFormModal from './ModuleFormModal.vue';
import { buildChildPath, useModuleBreadcrumb } from '../composables/useModuleBreadcrumb.js';
import { useModuleCrud } from '../composables/useModuleCrud.js';

const router = useRouter();
const {
  parsedRoute,
  currentConfig,
  currentContext,
  breadcrumbItems,
  routeText,
} = useModuleBreadcrumb();

const currentConfigRef = computed(() => currentConfig.value);
const currentContextRef = computed(() => currentContext.value);
const crud = useModuleCrud(currentConfigRef, currentContextRef);

const handleViewChild = (row) => {
  const path = buildChildPath(parsedRoute.value.trail, currentConfig.value, row);
  if (path) router.push(path);
};

watch(currentConfig, (config) => {
  if (!config) router.replace('/chuong-trinh/nganh');
}, { immediate: true });
</script>

<style scoped>
.module-page {
  width: 100%;
  height: 100%;
  min-height: 0;
  overflow: auto;
  background: #f4f6f9;
}

.module-page-inner {
  height: 100%;
  min-height: 0;
  display: grid;
  grid-template-rows: auto minmax(0, 1fr);
  gap: 14px;
  padding: 18px;
}
</style>
