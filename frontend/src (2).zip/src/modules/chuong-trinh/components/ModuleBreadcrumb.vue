<template>
  <div class="module-breadcrumb-card">
    <nav class="module-breadcrumb" aria-label="breadcrumb">
      <ol>
        <li>
          <RouterLink to="/chuong-trinh/nganh">/chuong-trinh</RouterLink>
        </li>
        <li v-for="item in items" :key="item.key">
          <span class="separator">/</span>
          <RouterLink v-if="!item.active" :to="item.to">
            {{ item.title }}
            <small v-if="item.id">#{{ item.id }}</small>
          </RouterLink>
          <span v-else class="active">
            {{ item.title }}
            <small v-if="item.id">#{{ item.id }}</small>
          </span>
        </li>
      </ol>
    </nav>

    <div class="route-text">{{ routeText }}</div>
  </div>
</template>

<script setup>
defineProps({
  items: {
    type: Array,
    default: () => [],
  },
  routeText: {
    type: String,
    default: '',
  },
});
</script>

<style scoped>
.module-breadcrumb-card {
  padding: 12px 14px;
  border: 1px solid #e2e8f0;
  border-radius: 14px;
  background: #ffffff;
  box-shadow: 0 10px 28px rgba(15, 23, 42, 0.06);
}

.module-breadcrumb ol {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 4px;
  padding: 0;
  margin: 0;
  list-style: none;
  font-size: 13px;
  font-weight: 700;
}

.module-breadcrumb a {
  color: #2563eb;
  text-decoration: none;
}

.module-breadcrumb a:hover {
  text-decoration: underline;
}

.separator,
.active {
  color: #475569;
}

small {
  margin-left: 4px;
  color: #94a3b8;
  font-weight: 700;
}

.route-text {
  margin-top: 6px;
  color: #64748b;
  font-size: 12px;
  word-break: break-all;
}
</style>
