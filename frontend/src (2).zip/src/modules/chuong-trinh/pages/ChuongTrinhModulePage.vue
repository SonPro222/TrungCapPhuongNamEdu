<template>
  <ModuleCrudPage />
</template>

<script setup>
import ModuleCrudPage from '../components/ModuleCrudPage.vue';
</script>
