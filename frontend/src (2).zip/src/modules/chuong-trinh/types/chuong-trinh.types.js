// File JS này lưu tên key/field dùng chung cho module. Không dùng TypeScript để giữ đúng stack hiện tại.
export const MODULE_KEYS = Object.freeze({
  NGANH: 'nganh',
  TRINH_DO_DAO_TAO: 'trinhDoDaoTao',
  LOAI_CHUONG_TRINH: 'loaiChuongTrinh',
  CHUONG_TRINH_DAO_TAO: 'chuongTrinhDaoTao',
  VERSION_CHUONG_TRINH: 'versionChuongTrinh',
  SYLLABUS_CHUONG_TRINH: 'syllabusChuongTrinh',
  MUC_TIEU_CHUONG_TRINH: 'mucTieuChuongTrinh',
  NANG_LUC_DAU_RA: 'nangLucDauRa',
  VI_TRI_VIEC_LAM: 'viTriViecLam',
  KHUNG_KY: 'khungKy',
  NHOM_KIEN_THUC: 'nhomKienThuc',
  MON_HOC: 'monHoc',
  MON_TRONG_CHUONG_TRINH: 'monTrongChuongTrinh',
  MON_TIEN_QUYET: 'monTienQuyet',
  NHOM_TU_CHON: 'nhomTuChon',
  SYLLABUS_MON_HOC: 'syllabusMonHoc',
  CHUONG_BAI_SYLLABUS: 'chuongBaiSyllabus',
  TAI_LIEU_MON_HOC: 'taiLieuMonHoc',
  DIEU_KIEN_MON_HOC: 'dieuKienMonHoc',
  QUY_DOI_DIEM: 'quyDoiDiem',
  DIEU_KIEN_TOT_NGHIEP: 'dieuKienTotNghiep',
});

export const PRIMARY_KEY = 'id';
