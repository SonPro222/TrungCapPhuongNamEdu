import { createCrudService } from './base.service.js';

export const taiLieuMonHocService = createCrudService('/api/chuongTrinh/syllabus-tai-lieu');
export default taiLieuMonHocService;
