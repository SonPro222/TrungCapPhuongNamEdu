import { createCrudService } from './base.service.js';

export const monHocService = createCrudService('/api/chuongTrinh/mon-hoc');
export default monHocService;
