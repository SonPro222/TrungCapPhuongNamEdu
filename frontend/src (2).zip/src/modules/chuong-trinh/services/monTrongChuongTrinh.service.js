import { createCrudService } from './base.service.js';

export const monTrongChuongTrinhService = createCrudService('/api/chuongTrinh/chuong-trinh-mon');
export default monTrongChuongTrinhService;
