import { createCrudService } from './base.service.js';

export const monTienQuyetService = createCrudService('/api/chuongTrinh/mon-tien-quyet');
export default monTienQuyetService;
