import { createCrudService } from './base.service.js';

export const loaiChuongTrinhService = createCrudService('/api/dao-tao/loai-chuong-trinh');
export default loaiChuongTrinhService;
