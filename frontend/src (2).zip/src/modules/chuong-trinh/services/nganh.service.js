import { createCrudService } from './base.service.js';

export const nganhService = createCrudService('/api/dao-tao/nganh');
export default nganhService;
