import { createCrudService } from './base.service.js';

export const syllabusChuongTrinhService = createCrudService('/api/chuongTrinh/syllabus-chuong-trinh');
export default syllabusChuongTrinhService;
