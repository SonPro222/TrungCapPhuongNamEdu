import { createCrudService } from './base.service.js';

export const versionChuongTrinhService = createCrudService('/api/chuongTrinh/chuong-trinh-version');
export default versionChuongTrinhService;
