import { createCrudService } from './base.service.js';

export const dieuKienTotNghiepService = createCrudService('/api/chuongTrinh/dieu-kien-tot-nghiep');
export default dieuKienTotNghiepService;
