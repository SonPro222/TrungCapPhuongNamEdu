import { createCrudService } from './base.service.js';

export const chuongTrinhDaoTaoService = createCrudService('/api/chuongTrinh/chuong-trinh');
export default chuongTrinhDaoTaoService;
