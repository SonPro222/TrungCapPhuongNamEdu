import apiClient from '@/api/apiConfig.js';

export const createCrudService = (endpoint) => ({
  list(params = {}) {
    return apiClient.get(endpoint, { params });
  },

  getById(id) {
    return apiClient.get(`${endpoint}/${id}`);
  },

  create(payload) {
    return apiClient.post(endpoint, payload);
  },

  update(id, payload) {
    return apiClient.put(`${endpoint}/${id}`, payload);
  },

  remove(id) {
    return apiClient.delete(`${endpoint}/${id}`);
  },
});
