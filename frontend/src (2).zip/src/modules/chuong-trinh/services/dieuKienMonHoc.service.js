import { createCrudService } from './base.service.js';

export const dieuKienMonHocService = createCrudService('/api/chuongTrinh/dieu-kien-mon-hoc');
export default dieuKienMonHocService;
