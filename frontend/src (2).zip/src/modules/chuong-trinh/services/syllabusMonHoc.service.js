import { createCrudService } from './base.service.js';

export const syllabusMonHocService = createCrudService('/api/chuongTrinh/syllabus-mon-hoc');
export default syllabusMonHocService;
