import { createCrudService } from './base.service.js';

export const khungKyService = createCrudService('/api/dao-tao/khung-ky');
export default khungKyService;
