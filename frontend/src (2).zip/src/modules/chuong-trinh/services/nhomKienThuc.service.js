import { createCrudService } from './base.service.js';

export const nhomKienThucService = createCrudService('/api/chuongTrinh/nhom-kien-thuc');
export default nhomKienThucService;
