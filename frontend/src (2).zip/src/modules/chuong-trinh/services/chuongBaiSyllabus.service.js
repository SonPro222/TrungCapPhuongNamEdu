import { createCrudService } from './base.service.js';

export const chuongBaiSyllabusService = createCrudService('/api/chuongTrinh/syllabus-chuong-bai');
export default chuongBaiSyllabusService;
