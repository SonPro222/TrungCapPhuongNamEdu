import { createCrudService } from './base.service.js';

export const viTriViecLamService = createCrudService('/api/chuongTrinh/vi-tri-viec-lam');
export default viTriViecLamService;
