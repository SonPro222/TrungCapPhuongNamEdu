import { createCrudService } from './base.service.js';

export const nangLucDauRaService = createCrudService('/api/chuongTrinh/nang-luc-dau-ra');
export default nangLucDauRaService;
