import { createCrudService } from './base.service.js';

export const trinhDoDaoTaoService = createCrudService('/api/dao-tao/trinh-do-dao-tao');
export default trinhDoDaoTaoService;
