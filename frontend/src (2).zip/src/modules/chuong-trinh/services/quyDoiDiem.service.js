import { createCrudService } from './base.service.js';

export const quyDoiDiemService = createCrudService('/api/chuongTrinh/quy-doi-diem');
export default quyDoiDiemService;
