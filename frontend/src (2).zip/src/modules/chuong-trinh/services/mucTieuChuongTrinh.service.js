import { createCrudService } from './base.service.js';

export const mucTieuChuongTrinhService = createCrudService('/api/chuongTrinh/muc-tieu-chuong-trinh');
export default mucTieuChuongTrinhService;
