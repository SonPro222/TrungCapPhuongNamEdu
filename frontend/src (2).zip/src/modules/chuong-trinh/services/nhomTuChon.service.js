import { createCrudService } from './base.service.js';

export const nhomTuChonService = createCrudService('/api/chuongTrinh/nhom-tu-chon');
export default nhomTuChonService;
