import { TABLE_COLUMNS } from './table-columns.config.js';
import { FORM_FIELDS } from './form-fields.config.js';
import { MODULE_FLOW, getNextFlowItem } from './module-flow.config.js';

import nganhService from '../services/nganh.service.js';
import trinhDoDaoTaoService from '../services/trinhDoDaoTao.service.js';
import loaiChuongTrinhService from '../services/loaiChuongTrinh.service.js';
import chuongTrinhDaoTaoService from '../services/chuongTrinhDaoTao.service.js';
import versionChuongTrinhService from '../services/versionChuongTrinh.service.js';
import syllabusChuongTrinhService from '../services/syllabusChuongTrinh.service.js';
import mucTieuChuongTrinhService from '../services/mucTieuChuongTrinh.service.js';
import nangLucDauRaService from '../services/nangLucDauRa.service.js';
import viTriViecLamService from '../services/viTriViecLam.service.js';
import khungKyService from '../services/khungKy.service.js';
import nhomKienThucService from '../services/nhomKienThuc.service.js';
import monHocService from '../services/monHoc.service.js';
import monTrongChuongTrinhService from '../services/monTrongChuongTrinh.service.js';
import monTienQuyetService from '../services/monTienQuyet.service.js';
import nhomTuChonService from '../services/nhomTuChon.service.js';
import syllabusMonHocService from '../services/syllabusMonHoc.service.js';
import chuongBaiSyllabusService from '../services/chuongBaiSyllabus.service.js';
import taiLieuMonHocService from '../services/taiLieuMonHoc.service.js';
import dieuKienMonHocService from '../services/dieuKienMonHoc.service.js';
import quyDoiDiemService from '../services/quyDoiDiem.service.js';
import dieuKienTotNghiepService from '../services/dieuKienTotNghiep.service.js';

const defaultPermissions = {
  create: ['admin', 'dao_tao', 'nhan_vien'],
  update: ['admin', 'dao_tao', 'nhan_vien'],
  delete: ['admin', 'dao_tao'],
};

const withDefaults = (item) => {
  const child = getNextFlowItem(item.key);
  return {
    primaryKey: 'id',
    parentKey: null,
    parentParam: null,
    childKey: child?.key || null,
    childRoute: child?.routePath || null,
    columns: TABLE_COLUMNS[item.key] || [],
    formFields: FORM_FIELDS[item.key] || [],
    searchFields: (TABLE_COLUMNS[item.key] || []).map((column) => column.key),
    contextFields: {},
    permissions: defaultPermissions,
    ...item,
  };
};

const rawConfigs = [
  {
    key: 'nganh',
    title: 'Ngành',
    routePath: 'nganh',
    idParam: 'nganhId',
    service: nganhService,
    schemaFields: ['id', 'maNganh', 'tenNganh', 'moTa', 'createdAt', 'updatedAt'],
    searchFields: ['maNganh', 'tenNganh', 'moTa'],
  },
  {
    key: 'trinhDoDaoTao',
    title: 'Trình độ đào tạo',
    routePath: 'trinh-do-dao-tao',
    idParam: 'trinhDoId',
    service: trinhDoDaoTaoService,
    schemaFields: ['id', 'maTrinhDo', 'tenTrinhDo', 'moTa'],
    searchFields: ['maTrinhDo', 'tenTrinhDo', 'moTa'],
  },
  {
    key: 'loaiChuongTrinh',
    title: 'Loại chương trình',
    routePath: 'loai-chuong-trinh',
    idParam: 'loaiChuongTrinhId',
    service: loaiChuongTrinhService,
    schemaFields: ['id', 'maLoai', 'tenLoai', 'soThang', 'soKy', 'moTa'],
    searchFields: ['maLoai', 'tenLoai', 'moTa'],
  },
  {
    key: 'chuongTrinhDaoTao',
    title: 'Chương trình đào tạo',
    routePath: 'chuong-trinh',
    idParam: 'chuongTrinhId',
    parentKey: 'loaiChuongTrinhId',
    parentParam: 'loaiChuongTrinhId',
    contextFields: { nganhId: 'nganhId', trinhDoId: 'trinhDoId', loaiChuongTrinhId: 'loaiChuongTrinhId' },
    service: chuongTrinhDaoTaoService,
    schemaFields: ['id', 'nganhId', 'trinhDoId', 'loaiChuongTrinhId', 'maChuongTrinh', 'tenChuongTrinh', 'doiTuongTuyenSinh', 'thoiGianDaoTao', 'createdAt', 'updatedAt'],
    searchFields: ['maChuongTrinh', 'tenChuongTrinh', 'doiTuongTuyenSinh', 'thoiGianDaoTao'],
  },
  {
    key: 'versionChuongTrinh',
    title: 'Version chương trình',
    routePath: 'chuong-trinh-version',
    idParam: 'chuongTrinhVersionId',
    parentKey: 'chuongTrinhId',
    parentParam: 'chuongTrinhId',
    contextFields: { chuongTrinhId: 'chuongTrinhId' },
    service: versionChuongTrinhService,
    schemaFields: ['id', 'chuongTrinhId', 'maVersion', 'tenVersion', 'ngayApDung', 'ngayHetHieuLuc', 'soQuyetDinh', 'ngayQuyetDinh', 'nguoiKy', 'coQuanBanHanh', 'fileQuyetDinh', 'tongTinChi', 'tongSoGio', 'tongGioLyThuyet', 'tongGioThucHanh', 'tongGioKiemTra', 'laHienHanh', 'createdAt', 'updatedAt'],
    searchFields: ['maVersion', 'tenVersion', 'soQuyetDinh', 'nguoiKy', 'coQuanBanHanh'],
  },
  {
    key: 'syllabusChuongTrinh',
    title: 'Syllabus chương trình',
    routePath: 'syllabus-chuong-trinh',
    idParam: 'syllabusChuongTrinhId',
    parentKey: 'chuongTrinhVersionId',
    parentParam: 'chuongTrinhVersionId',
    contextFields: { chuongTrinhVersionId: 'chuongTrinhVersionId' },
    service: syllabusChuongTrinhService,
    schemaFields: ['id', 'chuongTrinhVersionId', 'moTaTongQuan', 'mucDich', 'yeuCauDaoTao', 'phuongPhapDaoTao', 'ghiChu'],
    searchFields: ['moTaTongQuan', 'mucDich', 'yeuCauDaoTao', 'phuongPhapDaoTao', 'ghiChu'],
  },
  {
    key: 'mucTieuChuongTrinh',
    title: 'Mục tiêu chương trình',
    routePath: 'muc-tieu-chuong-trinh',
    idParam: 'mucTieuChuongTrinhId',
    parentKey: 'chuongTrinhVersionId',
    parentParam: 'chuongTrinhVersionId',
    contextFields: { chuongTrinhVersionId: 'chuongTrinhVersionId' },
    service: mucTieuChuongTrinhService,
    schemaFields: ['id', 'chuongTrinhVersionId', 'loai', 'noiDung', 'thuTu'],
    searchFields: ['loai', 'noiDung'],
  },
  {
    key: 'nangLucDauRa',
    title: 'Năng lực đầu ra',
    routePath: 'nang-luc-dau-ra',
    idParam: 'nangLucDauRaId',
    parentKey: 'chuongTrinhVersionId',
    parentParam: 'chuongTrinhVersionId',
    contextFields: { chuongTrinhVersionId: 'chuongTrinhVersionId' },
    service: nangLucDauRaService,
    schemaFields: ['id', 'chuongTrinhVersionId', 'ma', 'noiDung', 'loai', 'thuTu'],
    searchFields: ['ma', 'noiDung', 'loai'],
  },
  {
    key: 'viTriViecLam',
    title: 'Vị trí việc làm',
    routePath: 'vi-tri-viec-lam',
    idParam: 'viTriViecLamId',
    parentKey: 'chuongTrinhVersionId',
    parentParam: 'chuongTrinhVersionId',
    contextFields: { chuongTrinhVersionId: 'chuongTrinhVersionId' },
    service: viTriViecLamService,
    schemaFields: ['id', 'chuongTrinhVersionId', 'ten', 'moTa', 'thuTu'],
    searchFields: ['ten', 'moTa'],
  },
  {
    key: 'khungKy',
    title: 'Khung kỳ',
    routePath: 'khung-ky',
    idParam: 'khungKyId',
    parentKey: 'loaiChuongTrinhId',
    parentParam: 'loaiChuongTrinhId',
    contextFields: { loaiChuongTrinhId: 'loaiChuongTrinhId' },
    service: khungKyService,
    schemaFields: ['id', 'loaiChuongTrinhId', 'maKy', 'tenKy', 'thuTu'],
    searchFields: ['maKy', 'tenKy'],
  },
  {
    key: 'nhomKienThuc',
    title: 'Nhóm kiến thức',
    routePath: 'nhom-kien-thuc',
    idParam: 'nhomKienThucId',
    parentKey: 'chuongTrinhVersionId',
    parentParam: 'chuongTrinhVersionId',
    contextFields: { chuongTrinhVersionId: 'chuongTrinhVersionId' },
    service: nhomKienThucService,
    schemaFields: ['id', 'chuongTrinhVersionId', 'ma', 'ten', 'thuTu', 'loaiNhom', 'tongTinChi', 'tongSoGio', 'tongGioLyThuyet', 'tongGioThucHanh', 'tongGioKiemTra'],
    searchFields: ['ma', 'ten', 'loaiNhom'],
  },
  {
    key: 'monHoc',
    title: 'Môn học',
    routePath: 'mon-hoc',
    idParam: 'monHocId',
    service: monHocService,
    schemaFields: ['id', 'maMon', 'tenMon', 'moTa', 'createdAt', 'updatedAt'],
    searchFields: ['maMon', 'tenMon', 'moTa'],
  },
  {
    key: 'monTrongChuongTrinh',
    title: 'Môn trong chương trình',
    routePath: 'chuong-trinh-mon',
    idParam: 'chuongTrinhMonId',
    parentKey: 'monHocId',
    parentParam: 'monHocId',
    contextFields: { chuongTrinhVersionId: 'chuongTrinhVersionId', monHocId: 'monHocId' },
    service: monTrongChuongTrinhService,
    schemaFields: ['id', 'chuongTrinhVersionId', 'monHocId', 'maMonTrongCt', 'khungKyId', 'nhomKienThucId', 'loai', 'loaiHocPhan', 'batBuoc', 'laMonDieuKien', 'thuTu', 'soTinChi', 'tongGio', 'gioLyThuyet', 'gioThucHanh', 'gioKiemTra', 'ghiChu', 'createdAt', 'updatedAt'],
    searchFields: ['maMonTrongCt', 'loai', 'loaiHocPhan', 'ghiChu'],
  },
  {
    key: 'monTienQuyet',
    title: 'Môn tiên quyết',
    routePath: 'mon-tien-quyet',
    idParam: 'monTienQuyetId',
    parentKey: 'monId',
    parentParam: 'chuongTrinhMonId',
    contextFields: { chuongTrinhMonId: 'monId' },
    service: monTienQuyetService,
    schemaFields: ['id', 'monId', 'monDieuKienId', 'loai', 'ghiChu'],
    searchFields: ['loai', 'ghiChu'],
  },
  {
    key: 'nhomTuChon',
    title: 'Nhóm tự chọn',
    routePath: 'nhom-tu-chon',
    idParam: 'nhomTuChonId',
    parentKey: 'chuongTrinhVersionId',
    parentParam: 'chuongTrinhVersionId',
    contextFields: { chuongTrinhVersionId: 'chuongTrinhVersionId' },
    service: nhomTuChonService,
    schemaFields: ['id', 'chuongTrinhVersionId', 'ten', 'soMonChon', 'soTinChiCanDat', 'ghiChu'],
    searchFields: ['ten', 'ghiChu'],
  },
  {
    key: 'syllabusMonHoc',
    title: 'Syllabus môn học',
    routePath: 'syllabus-mon-hoc',
    idParam: 'syllabusMonHocId',
    parentKey: 'chuongTrinhMonId',
    parentParam: 'chuongTrinhMonId',
    contextFields: { chuongTrinhMonId: 'chuongTrinhMonId' },
    service: syllabusMonHocService,
    schemaFields: ['id', 'chuongTrinhMonId', 'viTri', 'tinhChat', 'mucTieu', 'phuongPhapDanhGia', 'dieuKienHoanThanh', 'huongDan', 'diemDatToiThieu', 'donViDiem', 'tyLeChuyenCanToiThieu', 'batBuocDuThi', 'congThucQuyDoi', 'createdAt', 'updatedAt'],
    searchFields: ['viTri', 'tinhChat', 'mucTieu', 'phuongPhapDanhGia', 'dieuKienHoanThanh'],
  },
  {
    key: 'chuongBaiSyllabus',
    title: 'Chương/bài syllabus',
    routePath: 'syllabus-chuong-bai',
    idParam: 'chuongBaiSyllabusId',
    parentKey: 'syllabusMonId',
    parentParam: 'syllabusMonHocId',
    contextFields: { syllabusMonHocId: 'syllabusMonId' },
    service: chuongBaiSyllabusService,
    schemaFields: ['id', 'syllabusMonId', 'ten', 'tongGio', 'gioLyThuyet', 'gioThucHanh', 'gioKiemTra', 'noiDung', 'mucTieu', 'thuTu'],
    searchFields: ['ten', 'noiDung', 'mucTieu'],
  },
  {
    key: 'taiLieuMonHoc',
    title: 'Tài liệu môn học',
    routePath: 'syllabus-tai-lieu',
    idParam: 'taiLieuMonHocId',
    parentKey: 'syllabusMonId',
    parentParam: 'syllabusMonHocId',
    contextFields: { syllabusMonHocId: 'syllabusMonId' },
    service: taiLieuMonHocService,
    schemaFields: ['id', 'syllabusMonId', 'ten', 'tacGia', 'namXuatBan', 'nhaXuatBan', 'loai', 'ghiChu'],
    searchFields: ['ten', 'tacGia', 'nhaXuatBan', 'loai', 'ghiChu'],
  },
  {
    key: 'dieuKienMonHoc',
    title: 'Điều kiện môn học',
    routePath: 'dieu-kien-mon-hoc',
    idParam: 'dieuKienMonHocId',
    parentKey: 'syllabusMonId',
    parentParam: 'syllabusMonHocId',
    contextFields: { syllabusMonHocId: 'syllabusMonId' },
    service: dieuKienMonHocService,
    schemaFields: ['id', 'syllabusMonId', 'loai', 'noiDung', 'thuTu'],
    searchFields: ['loai', 'noiDung'],
  },
  {
    key: 'quyDoiDiem',
    title: 'Quy đổi điểm',
    routePath: 'quy-doi-diem',
    idParam: 'quyDoiDiemId',
    parentKey: 'chuongTrinhMonId',
    parentParam: 'chuongTrinhMonId',
    contextFields: { chuongTrinhMonId: 'chuongTrinhMonId' },
    service: quyDoiDiemService,
    schemaFields: ['id', 'chuongTrinhMonId', 'nguongTu', 'nguongDen', 'diemQuyDoi', 'ketQua', 'congThuc', 'ghiChu'],
    searchFields: ['ketQua', 'congThuc', 'ghiChu'],
  },
  {
    key: 'dieuKienTotNghiep',
    title: 'Điều kiện tốt nghiệp',
    routePath: 'dieu-kien-tot-nghiep',
    idParam: 'dieuKienTotNghiepId',
    parentKey: 'chuongTrinhVersionId',
    parentParam: 'chuongTrinhVersionId',
    contextFields: { chuongTrinhVersionId: 'chuongTrinhVersionId' },
    service: dieuKienTotNghiepService,
    schemaFields: ['id', 'chuongTrinhVersionId', 'noiDung', 'thuTu'],
    searchFields: ['noiDung'],
  },
];

export const CHUONG_TRINH_MODULE_CONFIG = rawConfigs.map(withDefaults);

export const CHUONG_TRINH_MODULE_CONFIG_BY_KEY = CHUONG_TRINH_MODULE_CONFIG.reduce((map, config) => {
  map[config.key] = config;
  return map;
}, {});

export const CHUONG_TRINH_MODULE_CONFIG_BY_ROUTE = CHUONG_TRINH_MODULE_CONFIG.reduce((map, config) => {
  map[config.routePath] = config;
  return map;
}, {});

export const getModuleConfig = (key) => CHUONG_TRINH_MODULE_CONFIG_BY_KEY[key] || null;
export const getModuleConfigByRoutePath = (routePath) => CHUONG_TRINH_MODULE_CONFIG_BY_ROUTE[routePath] || null;
export const getFlowRoutePaths = () => MODULE_FLOW.map((item) => item.routePath);
