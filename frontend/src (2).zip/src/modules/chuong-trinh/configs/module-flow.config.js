export const DEFAULT_MODULE_KEY = 'nganh';

export const MODULE_FLOW = [
  { key: 'nganh', title: 'Ngành', routePath: 'nganh', idParam: 'nganhId' },
  { key: 'trinhDoDaoTao', title: 'Trình độ đào tạo', routePath: 'trinh-do-dao-tao', idParam: 'trinhDoId' },
  { key: 'loaiChuongTrinh', title: 'Loại chương trình', routePath: 'loai-chuong-trinh', idParam: 'loaiChuongTrinhId' },
  { key: 'chuongTrinhDaoTao', title: 'Chương trình đào tạo', routePath: 'chuong-trinh', idParam: 'chuongTrinhId' },
  { key: 'versionChuongTrinh', title: 'Version chương trình', routePath: 'chuong-trinh-version', idParam: 'chuongTrinhVersionId' },
  { key: 'syllabusChuongTrinh', title: 'Syllabus chương trình', routePath: 'syllabus-chuong-trinh', idParam: 'syllabusChuongTrinhId' },
  { key: 'mucTieuChuongTrinh', title: 'Mục tiêu chương trình', routePath: 'muc-tieu-chuong-trinh', idParam: 'mucTieuChuongTrinhId' },
  { key: 'nangLucDauRa', title: 'Năng lực đầu ra', routePath: 'nang-luc-dau-ra', idParam: 'nangLucDauRaId' },
  { key: 'viTriViecLam', title: 'Vị trí việc làm', routePath: 'vi-tri-viec-lam', idParam: 'viTriViecLamId' },
  { key: 'khungKy', title: 'Khung kỳ', routePath: 'khung-ky', idParam: 'khungKyId' },
  { key: 'nhomKienThuc', title: 'Nhóm kiến thức', routePath: 'nhom-kien-thuc', idParam: 'nhomKienThucId' },
  { key: 'monHoc', title: 'Môn học', routePath: 'mon-hoc', idParam: 'monHocId' },
  { key: 'monTrongChuongTrinh', title: 'Môn trong chương trình', routePath: 'chuong-trinh-mon', idParam: 'chuongTrinhMonId' },
  { key: 'monTienQuyet', title: 'Môn tiên quyết', routePath: 'mon-tien-quyet', idParam: 'monTienQuyetId' },
  { key: 'nhomTuChon', title: 'Nhóm tự chọn', routePath: 'nhom-tu-chon', idParam: 'nhomTuChonId' },
  { key: 'syllabusMonHoc', title: 'Syllabus môn học', routePath: 'syllabus-mon-hoc', idParam: 'syllabusMonHocId' },
  { key: 'chuongBaiSyllabus', title: 'Chương/bài syllabus', routePath: 'syllabus-chuong-bai', idParam: 'chuongBaiSyllabusId' },
  { key: 'taiLieuMonHoc', title: 'Tài liệu môn học', routePath: 'syllabus-tai-lieu', idParam: 'taiLieuMonHocId' },
  { key: 'dieuKienMonHoc', title: 'Điều kiện môn học', routePath: 'dieu-kien-mon-hoc', idParam: 'dieuKienMonHocId' },
  { key: 'quyDoiDiem', title: 'Quy đổi điểm', routePath: 'quy-doi-diem', idParam: 'quyDoiDiemId' },
  { key: 'dieuKienTotNghiep', title: 'Điều kiện tốt nghiệp', routePath: 'dieu-kien-tot-nghiep', idParam: 'dieuKienTotNghiepId' },
];

export const MODULE_FLOW_BY_KEY = MODULE_FLOW.reduce((map, item, index) => {
  map[item.key] = { ...item, index };
  return map;
}, {});

export const ROUTE_PATH_TO_KEY = MODULE_FLOW.reduce((map, item) => {
  map[item.routePath] = item.key;
  return map;
}, {});

export const getNextFlowItem = (key) => {
  const current = MODULE_FLOW_BY_KEY[key];
  if (!current) return null;
  return MODULE_FLOW[current.index + 1] || null;
};
