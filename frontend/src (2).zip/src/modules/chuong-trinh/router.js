import ChuongTrinhModulePage from './pages/ChuongTrinhModulePage.vue';

const chuongTrinhRoutes = [
  {
    path: 'chuong-trinh',
    redirect: '/chuong-trinh/nganh',
    meta: { module: 'chuong-trinh', title: 'Chương trình đào tạo' },
  },
  {
    path: 'chuong-trinh/:segments(.*)*',
    name: 'chuong-trinh.module',
    component: ChuongTrinhModulePage,
    meta: { module: 'chuong-trinh', title: 'Chương trình đào tạo' },
  },
];

export default chuongTrinhRoutes;
