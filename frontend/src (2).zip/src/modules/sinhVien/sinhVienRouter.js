import { ROLES } from '@/core/constants/roles'
import { requireAuth } from '@/core/guards/authGuard'
import { requireAdmin } from '@/core/guards/adminGuard'

import SinhVienLayout from './layouts/SinhVienLayout.vue'
import AdminSinhVienPage from './pages/AdminSinhVienPage.vue'
import AdminSinhVienTheoLopHocPhan from './pages/AdminSinhVienTheoLopHocPhan.vue'
import AdminLopHanhChinhPage from './pages/AdminLopHanhChinhPage.vue'
import AdminTaoLopHocPhanPage from './pages/AdminTaoLopHocPhanPage.vue'
import AdminSinhVienBaoLuuPage from './pages/AdminSinhVienBaoLuuPage.vue'

export const sinhVienRoutes = [
    {
        path: 'sinh-vien',
        component: SinhVienLayout,
        beforeEnter: [requireAuth, requireAdmin],
        meta: {
            module: 'sinhVien',
            title: 'Sinh viên',
            roles: [ROLES.ADMIN]
        },
        children: [
            {
                path: 'lop-hanh-chinh',
                name: 'AdminLopHanhChinh',
                component: AdminLopHanhChinhPage,
                meta: {
                    title: 'Tạo lớp hành chính',
                    roles: [ROLES.ADMIN]
                }
            },
            {
                path: 'tao-lop-hoc-phan',
                name: 'AdminTaoLopHocPhan',
                component: AdminTaoLopHocPhanPage,
                meta: {
                    title: 'Tạo lớp học phần',
                    roles: [ROLES.ADMIN]
                }
            },
            {
                path: '',
                name: 'AdminSinhVien',
                component: AdminSinhVienPage,
                meta: {
                    title: 'Tạo hồ sơ sinh viên',
                    roles: [ROLES.ADMIN]
                }
            },
            {
                path: 'lop-hoc-phan',
                name: 'AdminSinhVienTheoLopHocPhan',
                component: AdminSinhVienTheoLopHocPhan,
                meta: {
                    title: 'Phân bổ lớp học phần cho sinh viên',
                    roles: [ROLES.ADMIN]
                }
            },
            {
                path: 'bao-luu',
                name: 'AdminSinhVienBaoLuu',
                component: AdminSinhVienBaoLuuPage,
                meta: {
                    title: 'Danh sách sinh viên bảo lưu',
                    roles: [ROLES.ADMIN]
                }
            }
        ]
    }
]