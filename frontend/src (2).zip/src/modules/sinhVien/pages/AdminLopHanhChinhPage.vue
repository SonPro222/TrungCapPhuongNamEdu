<template>
  <section class="sv-page">
    <div class="sv-card">
      <div class="sv-card-title">
        <h2>Tạo lớp hành chính</h2>
        <p>Tạo lớp hành chính theo ngành, chương trình và version trước khi tiếp nhận sinh viên.</p>
      </div>

      <div v-if="thongBao" class="sv-message" :class="thongBaoLoai">
        {{ thongBao }}
      </div>

      <div class="sv-grid four">
        <label>
          Ngành
          <select v-model="boLoc.nganhId" @change="doiNganh">
            <option value="">Chọn ngành</option>
            <option v-for="nganh in danhSachNganh" :key="nganh.id" :value="nganh.id">
              {{ nganh.maNganh }} - {{ nganh.tenNganh }}
            </option>
          </select>
        </label>

        <label>
          Chương trình
          <select v-model="boLoc.chuongTrinhId" @change="doiChuongTrinh">
            <option value="">Chọn chương trình</option>
            <option v-for="ct in chuongTrinhTheoNganh" :key="ct.id" :value="ct.id">
              {{ ct.maChuongTrinh }} - {{ ct.tenChuongTrinh }}
            </option>
          </select>
        </label>

        <label>
          Version chương trình
          <select v-model="boLoc.chuongTrinhVersionId">
            <option value="">Chọn version</option>
            <option v-for="item in versionTheoChuongTrinh" :key="item.id" :value="item.id">
              {{ item.maVersion }} - {{ item.tenVersion || 'Version' }}
            </option>
          </select>
        </label>

        <label>
          Trạng thái
          <select v-model="form.trangThai">
            <option value="du_kien">Dự kiến</option>
            <option value="dang_hoc">Đang học</option>
            <option value="tam_dung">Tạm dừng</option>
            <option value="da_tot_nghiep">Đã tốt nghiệp</option>
            <option value="huy">Hủy</option>
          </select>
        </label>
      </div>

      <form class="sv-grid four" @submit.prevent="taoLopHanhChinh">
        <label>
          Mã lớp hành chính
          <input v-model.trim="form.maLop" required />

        </label>

        <label>
          Tên lớp hành chính
          <input v-model.trim="form.tenLop" required />
        </label>

        <label>
          Sĩ số tối đa
          <input v-model.number="form.siSo" type="number" min="0" />
        </label>

        <label>
          Ghi chú
          <input v-model.trim="form.ghiChu" />
        </label>

        <div class="span-4 sv-actions">
          <button type="submit" :disabled="dangLuu">
            {{ dangLuu ? 'Đang lưu...' : (idDangSua ? 'Cập nhật lớp hành chính' : 'Tạo lớp hành chính') }}
          </button>
          <button type="button" class="secondary" @click="resetForm">
            Làm mới
          </button>
        </div>
      </form>
    </div>

    <div class="sv-card">
      <div class="sv-card-title">
        <h2>Danh sách lớp hành chính theo version</h2>
        <p>Chọn version để xem các lớp hành chính đã tạo.</p>
      </div>

      <div class="sv-table-wrap">
        <table class="sv-table">
          <thead>
          <tr>
            <th>Mã lớp</th>
            <th>Tên lớp</th>
            <th>Version</th>
            <th>Sĩ số</th>
            <th>Trạng thái</th>
            <th>Ghi chú</th>
            <th>Thao tác</th>
          </tr>
          </thead>
          <tbody>
          <tr v-for="lop in lopHanhChinhTheoVersion" :key="lop.id">
            <td>{{ lop.maLop }}</td>
            <td>{{ lop.tenLop }}</td>
            <td>{{ tenVersion(lop.chuongTrinhVersionId) }}</td>
            <td>{{ lop.siSo || 0 }}</td>
            <td>{{ lop.trangThai }}</td>
            <td>{{ lop.ghiChu }}</td>
            <td>
              <div class="sv-row-actions">
                <button type="button" class="secondary" @click="chonSuaLopHanhChinh(lop)">
                  Sửa
                </button>
                <button type="button" class="danger" @click="xoaLopHanhChinh(lop)">
                  Xóa
                </button>
              </div>
            </td>
          </tr>
          <tr v-if="!lopHanhChinhTheoVersion.length">
            <td colspan="7">Chưa có lớp hành chính cho version đang chọn.</td>
          </tr>
          </tbody>
        </table>
      </div>
    </div>
  </section>
</template>

<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import { sinhVienService } from '../services/sinhVienService'

const thongBao = ref('')
const thongBaoLoai = ref('success')
const dangLuu = ref(false)
const idDangSua = ref(null)
const danhSachNganh = ref([])
const danhSachChuongTrinh = ref([])
const danhSachVersion = ref([])
const danhSachLopHanhChinh = ref([])

const boLoc = reactive({
  nganhId: '',
  chuongTrinhId: '',
  chuongTrinhVersionId: ''
})

const form = reactive({
  maLop: '',
  tenLop: '',
  siSo: 0,
  trangThai: 'dang_hoc',
  ghiChu: ''
})

const chuongTrinhTheoNganh = computed(() => {
  if (!boLoc.nganhId) return []
  return danhSachChuongTrinh.value.filter(item => String(item.nganhId) === String(boLoc.nganhId))
})

const versionTheoChuongTrinh = computed(() => {
  if (!boLoc.chuongTrinhId) return []
  return danhSachVersion.value.filter(item => String(item.chuongTrinhId) === String(boLoc.chuongTrinhId))
})

const lopHanhChinhTheoVersion = computed(() => {
  if (!boLoc.chuongTrinhVersionId) return []
  return danhSachLopHanhChinh.value.filter(item => String(item.chuongTrinhVersionId) === String(boLoc.chuongTrinhVersionId))
})

onMounted(async () => {
  await taiDuLieu()
})

async function taiDuLieu() {
  try {
    const [nganh, chuongTrinh, version, lopHanhChinh] = await Promise.all([
      sinhVienService.layNganh(),
      sinhVienService.layChuongTrinh(),
      sinhVienService.layVersion(),
      sinhVienService.layLopHanhChinh()
    ])

    danhSachNganh.value = nganh
    danhSachChuongTrinh.value = chuongTrinh
    danhSachVersion.value = version
    danhSachLopHanhChinh.value = lopHanhChinh
  } catch (error) {
    baoLoi(error?.message || 'Không tải được dữ liệu lớp hành chính')
  }
}

function doiNganh() {
  boLoc.chuongTrinhId = ''
  doiChuongTrinh()
}

function doiChuongTrinh() {
  boLoc.chuongTrinhVersionId = ''
}

async function taoLopHanhChinh() {
  if (!boLoc.chuongTrinhVersionId) {
    baoLoi('Phải chọn version chương trình trước khi tạo lớp hành chính')
    return
  }

  if (!form.maLop || !form.tenLop) {
    baoLoi('Phải nhập mã lớp và tên lớp hành chính')
    return
  }

  dangLuu.value = true

  try {
    const payload = lamSachPayload({
      maLop: form.maLop,
      tenLop: form.tenLop,
      chuongTrinhVersionId: Number(boLoc.chuongTrinhVersionId),
      siSo: Number(form.siSo || 0),
      trangThai: form.trangThai,
      ghiChu: form.ghiChu
    })

    if (idDangSua.value) {
      const response = await sinhVienService.capNhatLopHanhChinh(idDangSua.value, payload)
      const lopCapNhat = layMotBanGhi(response)

      if (lopCapNhat?.id) {
        const index = danhSachLopHanhChinh.value.findIndex(item => String(item.id) === String(lopCapNhat.id))
        if (index !== -1) {
          danhSachLopHanhChinh.value[index] = lopCapNhat
        }
      } else {
        await taiDuLieu()
      }

      resetForm()
      baoThanhCong('Đã cập nhật lớp hành chính')
      return
    }

    const response = await sinhVienService.taoLopHanhChinh(payload)
    const lopMoi = layMotBanGhi(response)

    if (lopMoi?.id) {
      danhSachLopHanhChinh.value.push(lopMoi)
    } else {
      await taiDuLieu()
    }

    resetForm()
    baoThanhCong('Đã tạo lớp hành chính')
  } catch (error) {
    baoLoi(error?.message || 'Lưu lớp hành chính thất bại')
  } finally {
    dangLuu.value = false
  }
}
function chonSuaLopHanhChinh(lop) {
  idDangSua.value = lop.id
  boLoc.chuongTrinhVersionId = lop.chuongTrinhVersionId ? String(lop.chuongTrinhVersionId) : boLoc.chuongTrinhVersionId
  form.maLop = lop.maLop || ''
  form.tenLop = lop.tenLop || ''
  form.siSo = Number(lop.siSo || 0)
  form.trangThai = lop.trangThai || 'dang_hoc'
  form.ghiChu = lop.ghiChu || ''
}

async function xoaLopHanhChinh(lop) {
  const dongY = window.confirm(`Xóa lớp hành chính "${lop.maLop}"?`)
  if (!dongY) return

  try {
    await sinhVienService.xoaLopHanhChinh(lop.id)
    danhSachLopHanhChinh.value = danhSachLopHanhChinh.value.filter(item => String(item.id) !== String(lop.id))

    if (String(idDangSua.value) === String(lop.id)) {
      resetForm()
    }

    baoThanhCong('Đã xóa lớp hành chính')
  } catch (error) {
    baoLoi(error?.message || 'Không xóa được lớp hành chính')
  }
}
function resetForm() {
  idDangSua.value = null
  form.maLop = ''
  form.tenLop = ''
  form.siSo = 0
  form.trangThai = 'dang_hoc'
  form.ghiChu = ''
}
function tenVersion(id) {
  const item = danhSachVersion.value.find(version => String(version.id) === String(id))
  if (!item) return id
  return `${item.maVersion} - ${item.tenVersion || 'Version'}`
}

function layMotBanGhi(response) {
  if (response?.data && !Array.isArray(response.data)) return response.data
  if (response && !Array.isArray(response)) return response
  return null
}

function lamSachPayload(payload) {
  return Object.fromEntries(
      Object.entries(payload).filter(([, value]) => value !== '' && value !== null && value !== undefined)
  )
}
function baoThanhCong(message) {
  thongBao.value = message
  thongBaoLoai.value = 'success'
}

function baoLoi(message) {
  thongBao.value = message
  thongBaoLoai.value = 'error'
}
</script>

<style scoped>
.sv-page,
.sv-bl-page,
.sv-lhp-page,
.sv-page *,
.sv-bl-page *,
.sv-lhp-page * {
  font-family: inherit;
  letter-spacing: normal;
}

.sv-page,
.sv-bl-page,
.sv-lhp-page {
  display: grid;
  gap: 14px;
}

.sv-header,
.sv-card,
.sv-filter-card,
.sv-account-box,
.page-title,
.panel {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 14px;
  padding: 14px;
  box-shadow: 0 8px 22px rgba(15, 23, 42, 0.05);
}

.sv-header {
  background: linear-gradient(135deg, #f8fafc, #eff6ff);
  border-color: #bfdbfe;
}

.sv-header h1,
.page-title h2,
.sv-card-title h2,
.panel-title h2,
.sv-card h2,
.modal-header h2,
.sv-modal-header h2 {
  margin: 0;
  color: #0f172a;
  font-size: 18px;
  font-weight: 700;
  line-height: 1.35;
  letter-spacing: normal;
}

.sv-header p,
.page-title p,
.sv-card-title p,
.panel-title p,
.panel-subtitle,
.sv-card p,
.modal-header p,
.sv-modal-header p {
  margin: 5px 0 0;
  color: #64748b;
  font-size: 13px;
  font-weight: 400;
  line-height: 1.45;
  letter-spacing: normal;
}

.sv-eyebrow {
  margin: 0 0 4px;
  color: #1d4ed8 !important;
  font-size: 13px;
  font-weight: 700;
  text-transform: none;
  letter-spacing: normal;
}

.sv-card-title,
.panel-title {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 12px;
  margin-bottom: 12px;
}

.panel-title span {
  color: #64748b;
  font-size: 13px;
  font-weight: 600;
}

.sv-grid,
.form-grid,
.filter-grid {
  display: grid;
  gap: 10px;
}

.sv-grid.two,
.form-grid {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}

.sv-grid.three {
  grid-template-columns: repeat(3, minmax(0, 1fr));
}

.sv-grid.four,
.filter-grid,
.bao-luu-filter {
  grid-template-columns: repeat(4, minmax(0, 1fr));
}

.sv-filter-card {
  display: grid;
  grid-template-columns: 1fr 1.2fr 1.2fr 1.2fr auto;
  gap: 10px;
  align-items: end;
}

.content-grid {
  display: grid;
  grid-template-columns: minmax(360px, 0.9fr) minmax(0, 1.35fr);
  gap: 14px;
}

.span-2 {
  grid-column: span 2;
}

.span-3 {
  grid-column: span 3;
}

.span-4 {
  grid-column: span 4;
}

label {
  display: grid;
  gap: 5px;
  color: #334155;
  font-size: 13px;
  font-weight: 600;
  letter-spacing: normal;
}

input,
select,
textarea {
  width: 100%;
  min-height: 38px;
  border: 1px solid #cbd5e1;
  border-radius: 10px;
  padding: 8px 10px;
  background: #ffffff;
  color: #0f172a;
  font: inherit;
  font-size: 14px;
  font-weight: 400;
  letter-spacing: normal;
  outline: none;
  transition: border-color 0.15s ease, box-shadow 0.15s ease;
}

textarea {
  min-height: 76px;
  resize: vertical;
}

input:focus,
select:focus,
textarea:focus {
  border-color: #2563eb;
  box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.12);
}

input:disabled,
select:disabled,
textarea:disabled {
  background: #f8fafc;
  color: #64748b;
  cursor: not-allowed;
}

.sv-actions,
.actions,
.form-actions,
.row-actions,
.sv-row-actions,
.sv-modal-actions {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}

button,
.sv-action-link {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-height: 36px;
  border: 0;
  border-radius: 10px;
  padding: 8px 12px;
  background: #1d4ed8;
  color: #ffffff;
  font-size: 14px;
  font-weight: 700;
  letter-spacing: normal;
  text-transform: none;
  line-height: 1;
  text-decoration: none;
  cursor: pointer;
  transition: transform 0.12s ease, filter 0.12s ease, background 0.12s ease;
}

button:hover,
.sv-action-link:hover {
  filter: brightness(0.97);
  transform: translateY(-1px);
}

button:disabled {
  opacity: 0.6;
  cursor: not-allowed;
  transform: none;
}

button.secondary {
  background: #e2e8f0;
  color: #334155;
}

button.danger {
  background: #dc2626;
  color: #ffffff;
}

button.small {
  min-height: 30px;
  padding: 6px 9px;
  font-size: 13px;
}

button.selected {
  background: #047857;
  color: #ffffff;
}

.sv-action-link {
  background: #f59e0b;
  color: #ffffff;
}

.sv-tabs {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.sv-tabs button {
  background: #e2e8f0;
  color: #334155;
}

.sv-tabs button.active {
  background: #1d4ed8;
  color: #ffffff;
}

.sv-message,
.message {
  border-radius: 12px;
  padding: 10px 12px;
  font-size: 13px;
  font-weight: 600;
  letter-spacing: normal;
}

.sv-message.success,
.message.success {
  background: #ecfdf5;
  color: #047857;
  border: 1px solid #a7f3d0;
}

.sv-message.error,
.message.error {
  background: #fef2f2;
  color: #b91c1c;
  border: 1px solid #fecaca;
}

.sv-account-box {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
  background: #fffbeb;
  border-color: #fbbf24;
  color: #78350f;
}

.sv-class-summary {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 10px;
  margin-bottom: 12px;
}

.sv-class-summary div,
.sv-flow-item,
.sv-selected,
.sinh-vien-da-chon {
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  padding: 10px;
  background: #f8fafc;
}

.sv-class-summary span {
  color: #64748b;
  font-size: 12px;
  font-weight: 400;
}

.sv-class-summary strong {
  color: #0f172a;
  font-size: 14px;
  font-weight: 700;
}

.sv-flow {
  display: grid;
  grid-template-columns: repeat(6, minmax(0, 1fr));
  gap: 10px;
}

.sv-flow-item {
  display: grid;
  gap: 5px;
}

.sv-flow-item.active {
  border-color: #93c5fd;
  background: #eff6ff;
}

.sv-list-filter {
  display: flex;
  justify-content: flex-end;
  margin-bottom: 10px;
}

.sv-table-wrap,
.table-wrap {
  width: 100%;
  overflow: auto;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  background: #ffffff;
}

.sv-table,
table {
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
}

.bang-lop-hoc-phan {
  min-width: 1500px;
}

th,
td,
.sv-table th,
.sv-table td {
  border-bottom: 1px solid #e2e8f0;
  padding: 8px 10px;
  text-align: left;
  vertical-align: top;
}

th,
.sv-table th {
  position: sticky;
  top: 0;
  z-index: 1;
  background: #f8fafc;
  color: #334155;
  font-size: 13px;
  font-weight: 700;
  text-transform: none;
  letter-spacing: normal;
  white-space: nowrap;
}

td,
.sv-table td {
  color: #334155;
  font-size: 13px;
  font-weight: 400;
  letter-spacing: normal;
}

td.diem,
td.cot-diem,
td[data-label*='Điểm'],
td[data-label*='điểm'],
.sv-table td.diem,
.sv-table td.cot-diem,
.sv-table td[data-label*='Điểm'],
.sv-table td[data-label*='điểm'] {
  font-weight: 700;
  color: #0f172a;
}

tbody tr:hover td,
.clickable-row:hover td {
  background: #f8fafc;
}

tr.selected td,
.sv-table tr.selected td {
  background: #eff6ff;
}

.clickable-row {
  cursor: pointer;
}

.empty {
  text-align: center;
  color: #64748b;
  padding: 18px;
  font-weight: 600;
}

.sv-avatar {
  width: 42px;
  height: 42px;
  object-fit: cover;
  border: 1px solid #e2e8f0;
  border-radius: 10px;
  background: #f8fafc;
}

.sv-status,
.status {
  display: inline-flex;
  align-items: center;
  border-radius: 999px;
  padding: 4px 9px;
  font-size: 12px;
  font-weight: 600;
  letter-spacing: normal;
  white-space: nowrap;
}

.sv-status.done,
.status.da_di_hoc_lai {
  background: #ecfdf5;
  color: #047857;
}

.sv-status.partial,
.status.dang_bao_luu {
  background: #fffbeb;
  color: #b45309;
}

.sv-status.pending,
.status.da_huy {
  background: #fef2f2;
  color: #b91c1c;
}

.tim-sinh-vien-box {
  display: grid;
  grid-template-columns: minmax(260px, 1fr) auto;
  gap: 10px;
  align-items: end;
}

.sinh-vien-da-chon {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
  border-color: #bfdbfe;
  background: #eff6ff;
  color: #1e3a8a;
}

.modal-overlay,
.sv-modal-overlay {
  position: fixed;
  inset: 0;
  z-index: 9999;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
  background: rgba(15, 23, 42, 0.55);
}

.modal,
.sv-modal {
  width: min(900px, 100%);
  max-height: calc(100vh - 40px);
  overflow: auto;
  border-radius: 16px;
  padding: 16px;
  background: #ffffff;
  box-shadow: 0 24px 80px rgba(15, 23, 42, 0.32);
}

.modal-header,
.sv-modal-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 14px;
  margin-bottom: 14px;
}

.modal-close,
.sv-modal-close {
  width: 34px;
  height: 34px;
  min-height: 34px;
  border-radius: 999px;
  padding: 0;
  background: #e2e8f0;
  color: #0f172a;
  font-size: 22px;
  font-weight: 400;
  line-height: 1;
}

@media (max-width: 1200px) {
  .sv-filter-card,
  .sv-grid.four,
  .filter-grid,
  .form-grid,
  .bao-luu-filter,
  .content-grid,
  .sv-class-summary,
  .sv-flow {
    grid-template-columns: 1fr;
  }

  .span-2,
  .span-3,
  .span-4 {
    grid-column: span 1;
  }
}

@media (max-width: 700px) {
  .sv-header,
  .sv-card,
  .sv-filter-card,
  .sv-account-box,
  .page-title,
  .panel {
    padding: 12px;
    border-radius: 12px;
  }

  .sv-card-title,
  .panel-title {
    display: grid;
  }

  .sv-actions,
  .actions,
  .form-actions,
  .row-actions,
  .sv-row-actions,
  .sv-modal-actions {
    justify-content: stretch;
  }

  button,
  .sv-action-link {
    width: 100%;
  }

  .tim-sinh-vien-box {
    grid-template-columns: 1fr;
  }
}
</style>