<template>
    <section class="sv-lhp-page">
      <div class="page-title">
        <div>
          <h2>Sinh viên theo lớp học phần</h2>
          <p>Chọn ngành, chương trình, version, kỳ, môn và lớp học phần để xem hoặc phân sinh viên.</p>
        </div>
      </div>

    <div v-if="thongBao" class="message" :class="thongBaoLoai">
      {{ thongBao }}
    </div>

    <section class="panel">
      <div class="filter-grid">
        <label>
          Ngành
          <select v-model="boLoc.nganhId" @change="doiNganh">
            <option value="">Chọn ngành</option>
            <option v-for="nganh in danhSachNganh" :key="nganh.id" :value="nganh.id">
              {{ nganh.maNganh }} - {{ nganh.tenNganh }}
            </option>
          </select>
        </label>

        <label>
          Chương trình
          <select v-model="boLoc.chuongTrinhId" @change="doiChuongTrinh">
            <option value="">Chọn chương trình</option>
            <option v-for="ct in chuongTrinhTheoNganh" :key="ct.id" :value="ct.id">
              {{ ct.maChuongTrinh }} - {{ ct.tenChuongTrinh }}
            </option>
          </select>
        </label>

        <label>
          Version
          <select v-model="boLoc.chuongTrinhVersionId" @change="doiVersion">
            <option value="">Chọn version</option>
            <option v-for="version in versionTheoChuongTrinh" :key="version.id" :value="version.id">
              {{ version.maVersion }} - {{ version.tenVersion || 'Version' }}
            </option>
          </select>
        </label>

        <label>
          Kỳ / khung kỳ
          <select v-model="boLoc.khungKyId" @change="doiKhungKy">
            <option value="">Chọn kỳ</option>
            <option v-for="ky in khungKyTheoVersion" :key="ky.id" :value="ky.id">
              {{ ky.maKy }} - {{ ky.tenKy }}
            </option>
          </select>
        </label>
      </div>
    </section>

    <section class="content-grid">
      <div class="panel">
        <div class="panel-title">
          <h2>Môn trong kỳ</h2>
          <span>{{ monTrongKy.length }} môn</span>
        </div>

        <table>
          <thead>
          <tr>
            <th>Thứ tự</th>
            <th>Mã môn CT</th>
            <th>Tín chỉ</th>
            <th></th>
          </tr>
          </thead>
          <tbody>
          <tr v-for="mon in monTrongKy" :key="mon.id" :class="{ selected: monDangChon?.id === mon.id }">
            <td>{{ mon.thuTu }}</td>
            <td>{{ mon.maMonTrongCt }}</td>
            <td>{{ mon.soTinChi }}</td>
            <td><button type="button" @click="chonMon(mon)">Chọn</button></td>
          </tr>
          <tr v-if="!monTrongKy.length">
            <td colspan="4" class="empty">Chưa có môn trong kỳ đã chọn</td>
          </tr>
          </tbody>
        </table>
      </div>

      <div class="panel">
        <div class="panel-title">
          <h2>Lớp học phần</h2>
          <span>{{ lopHocPhanTheoMon.length }} lớp</span>
        </div>

        <table>
          <thead>
          <tr>
            <th>Mã lớp</th>
            <th>Tên lớp</th>
            <th>Sĩ số</th>
            <th>Trạng thái</th>
            <th></th>
          </tr>
          </thead>
          <tbody>
          <tr v-for="lop in lopHocPhanTheoMon" :key="lop.id" :class="{ selected: lopDangChon?.id === lop.id }">
            <td>{{ lop.maLop }}</td>
            <td>{{ lop.tenLop }}</td>
            <td>{{ lop.soLuongHienTai || 0 }}/{{ lop.soLuongToiDa || '-' }}</td>
            <td>{{ lop.trangThai }}</td>
            <td><button type="button" @click="chonLop(lop)">Xem</button></td>
          </tr>
          <tr v-if="!lopHocPhanTheoMon.length">
            <td colspan="5" class="empty">Chưa có lớp học phần cho môn đã chọn</td>
          </tr>
          </tbody>
        </table>
      </div>
    </section>

    <section v-if="lopDangChon" class="content-grid">
      <div class="panel">
        <div class="panel-title">
          <h2>Sinh viên trong lớp</h2>
          <span>{{ sinhVienTrongLop.length }} sinh viên</span>
        </div>

        <table>
          <thead>
          <tr>
            <th>Mã SV</th>
            <th>Họ tên</th>
            <th>Gmail</th>
            <th>Trạng thái</th>
            <th></th>
          </tr>
          </thead>
          <tbody>
          <tr v-for="sv in sinhVienTrongLop" :key="sv.id">
            <td>{{ sv.maSinhVien }}</td>
            <td>{{ sv.hoTen }}</td>
            <td>{{ sv.email }}</td>
            <td>{{ sv.trangThai }}</td>
            <td>
              <button type="button" class="danger" @click="xoaSinhVienKhoiLop(sv)">
                Xóa khỏi lớp
              </button>
            </td>
          </tr>
          <tr v-if="!sinhVienTrongLop.length">
            <td colspan="5" class="empty">Lớp học phần chưa có sinh viên</td>
          </tr>
          </tbody>
        </table>
      </div>

      <div class="panel">
        <div class="panel-title">
          <h2>Sinh viên chưa vào lớp này</h2>
          <span>{{ sinhVienChuaVaoLop.length }} sinh viên</span>
        </div>

        <table>
          <thead>
          <tr>
            <th>Mã SV</th>
            <th>Họ tên</th>
            <th>Gmail</th>
            <th></th>
          </tr>
          </thead>
          <tbody>
          <tr v-for="sv in sinhVienChuaVaoLop" :key="sv.id">
            <td>{{ sv.maSinhVien }}</td>
            <td>{{ sv.hoTen }}</td>
            <td>{{ sv.email }}</td>
            <td>
              <button type="button" @click="themSinhVienVaoLop(sv)">
                Thêm vào lớp
              </button>
            </td>
          </tr>
          <tr v-if="!sinhVienChuaVaoLop.length">
            <td colspan="4" class="empty">Không còn sinh viên phù hợp để thêm</td>
          </tr>
          </tbody>
        </table>
      </div>
    </section>
  </section>
</template>

<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import { sinhVienApi } from '../api/sinhVienApi'

const danhSachNganh = ref([])
const danhSachChuongTrinh = ref([])
const danhSachVersion = ref([])
const danhSachKhungKy = ref([])
const danhSachChuongTrinhMon = ref([])
const danhSachLopHocPhan = ref([])
const danhSachLopHocPhanChuongTrinhMon = ref([])
const danhSachDangKyLop = ref([])
const monDangChon = ref(null)
const lopDangChon = ref(null)
const sinhVienTrongLop = ref([])
const sinhVienChuaVaoLop = ref([])

const thongBao = ref('')
const thongBaoLoai = ref('success')

const boLoc = reactive({
  nganhId: '',
  chuongTrinhId: '',
  chuongTrinhVersionId: '',
  khungKyId: ''
})

const chuongTrinhTheoNganh = computed(() => {
  if (!boLoc.nganhId) return []
  return danhSachChuongTrinh.value.filter(item => String(item.nganhId) === String(boLoc.nganhId))
})

const versionTheoChuongTrinh = computed(() => {
  if (!boLoc.chuongTrinhId) return []
  return danhSachVersion.value.filter(item => String(item.chuongTrinhId) === String(boLoc.chuongTrinhId))
})

const khungKyTheoVersion = computed(() => {
  if (!boLoc.chuongTrinhVersionId) return []
  return danhSachKhungKy.value
      .filter(item => String(item.chuongTrinhVersionId) === String(boLoc.chuongTrinhVersionId))
      .sort((a, b) => Number(a.thuTu || 0) - Number(b.thuTu || 0))
})

const monTrongKy = computed(() => {
  if (!boLoc.chuongTrinhVersionId || !boLoc.khungKyId) return []
  return danhSachChuongTrinhMon.value
      .filter(item =>
          String(item.chuongTrinhVersionId) === String(boLoc.chuongTrinhVersionId)
          && String(item.khungKyId) === String(boLoc.khungKyId)
      )
      .sort((a, b) => Number(a.thuTu || 0) - Number(b.thuTu || 0))
})

const lopHocPhanTheoMon = computed(() => {
  if (!monDangChon.value?.id) return []

  return danhSachLopHocPhan.value.filter(lop => {
    if (laLopHocChung(lop)) {
      return danhSachLopHocPhanChuongTrinhMon.value.some(item => {
        return String(item.lopHocPhanId) === String(lop.id)
            && String(item.chuongTrinhMonId) === String(monDangChon.value.id)
      })
    }

    return String(lop.chuongTrinhMonId) === String(monDangChon.value.id)
  })
})
onMounted(async () => {
  await taiDuLieuBanDau()
})

async function taiDuLieuBanDau() {
  try {
    const [nganh, chuongTrinh, version, khungKy, chuongTrinhMon, lopHocPhan, lopHocPhanChuongTrinhMon, dangKyLop] = await Promise.all([
      sinhVienApi.nganh.getAll({ size: 1000 }),
      sinhVienApi.chuongTrinh.getAll({ size: 1000 }),
      sinhVienApi.chuongTrinhVersion.getAll({ size: 1000 }),
      sinhVienApi.khungKy.getAll({ size: 1000 }),
      sinhVienApi.chuongTrinhMon.getAll({ size: 1000 }),
      sinhVienApi.lopHocPhan.getAll({ size: 1000 }),
      sinhVienApi.lopHocPhanChuongTrinhMon.getAll({ size: 1000 }),
      sinhVienApi.sinhVienLopHocPhan.getAll({ size: 1000 })
    ])

    danhSachNganh.value = layDanhSach(nganh)
    danhSachChuongTrinh.value = layDanhSach(chuongTrinh)
    danhSachVersion.value = layDanhSach(version)
    danhSachKhungKy.value = layDanhSach(khungKy)
    danhSachChuongTrinhMon.value = layDanhSach(chuongTrinhMon)
    danhSachLopHocPhan.value = layDanhSach(lopHocPhan)
    danhSachLopHocPhanChuongTrinhMon.value = layDanhSach(lopHocPhanChuongTrinhMon)
    danhSachDangKyLop.value = layDanhSach(dangKyLop)
  } catch (error) {
    baoLoi(error?.message || 'Không tải được dữ liệu phân lớp học phần')
  }
}
function laLopHocChung(lop) {
  return String(lop?.loaiLopHocPhan || '').toUpperCase() === 'HOC_CHUNG'
}
function doiNganh() {
  boLoc.chuongTrinhId = ''
  doiChuongTrinh()
}

function doiChuongTrinh() {
  boLoc.chuongTrinhVersionId = ''
  doiVersion()
}

function doiVersion() {
  boLoc.khungKyId = ''
  doiKhungKy()
}

function doiKhungKy() {
  monDangChon.value = null
  lopDangChon.value = null
  sinhVienTrongLop.value = []
  sinhVienChuaVaoLop.value = []
}

function chonMon(mon) {
  monDangChon.value = mon
  lopDangChon.value = null
  sinhVienTrongLop.value = []
  sinhVienChuaVaoLop.value = []
}

async function chonLop(lop) {
  lopDangChon.value = lop
  await taiSinhVienTheoLop()
}

async function taiSinhVienTheoLop() {
  if (!lopDangChon.value?.id || !boLoc.chuongTrinhVersionId) return

  try {
    const [trongLop, chuaVaoLop, dangKyLop, lopHocPhan, lopHocPhanChuongTrinhMon] = await Promise.all([
      sinhVienApi.sinhVienLopHocPhan.getSinhVienTrongLop(lopDangChon.value.id),
      sinhVienApi.sinhVienLopHocPhan.getSinhVienChuaVaoLop(lopDangChon.value.id, boLoc.chuongTrinhVersionId),
      sinhVienApi.sinhVienLopHocPhan.getTheoLopHocPhan(lopDangChon.value.id),
      sinhVienApi.lopHocPhan.getAll({ size: 1000 }),
      sinhVienApi.lopHocPhanChuongTrinhMon.getAll({ size: 1000 })
    ])

    sinhVienTrongLop.value = layDanhSach(trongLop)
    sinhVienChuaVaoLop.value = layDanhSach(chuaVaoLop)
    danhSachDangKyLop.value = [
      ...danhSachDangKyLop.value.filter(item => String(item.lopHocPhanId) !== String(lopDangChon.value.id)),
      ...layDanhSach(dangKyLop)
    ]
    danhSachLopHocPhan.value = layDanhSach(lopHocPhan)
    danhSachLopHocPhanChuongTrinhMon.value = layDanhSach(lopHocPhanChuongTrinhMon)
    capNhatLopDangChon()
  } catch (error) {
    baoLoi(error?.message || 'Không tải được danh sách sinh viên theo lớp học phần')
  }
}

async function themSinhVienVaoLop(sinhVien) {
  if (!lopDangChon.value?.id) {
    baoLoi('Chưa chọn lớp học phần')
    return
  }

  try {
    await sinhVienApi.sinhVienLopHocPhan.create({
      sinhVienId: sinhVien.id,
      lopHocPhanId: lopDangChon.value.id,
      trangThai: 'da_dang_ky',
      laHocLai: false,
      ghiChu: ''
    })

    baoThanhCong('Đã thêm sinh viên vào lớp học phần')
    await taiSinhVienTheoLop()
  } catch (error) {
    baoLoi(error?.message || 'Không thêm được sinh viên vào lớp học phần')
  }
}

async function xoaSinhVienKhoiLop(sinhVien) {
  const dangKy = danhSachDangKyLop.value.find(item =>
      String(item.sinhVienId) === String(sinhVien.id)
      && String(item.lopHocPhanId) === String(lopDangChon.value?.id)
  )

  if (!dangKy?.id) {
    baoLoi('Không tìm thấy bản ghi sinh viên trong lớp học phần')
    return
  }

  if (!window.confirm(`Xóa sinh viên ${sinhVien.hoTen} khỏi lớp học phần này?`)) {
    return
  }

  try {
    await sinhVienApi.sinhVienLopHocPhan.delete(dangKy.id)
    baoThanhCong('Đã xóa sinh viên khỏi lớp học phần')
    await taiSinhVienTheoLop()
  } catch (error) {
    baoLoi(error?.message || 'Không xóa được sinh viên khỏi lớp học phần')
  }
}

function capNhatLopDangChon() {
  if (!lopDangChon.value?.id) return
  const lopMoi = danhSachLopHocPhan.value.find(item => String(item.id) === String(lopDangChon.value.id))
  if (lopMoi) lopDangChon.value = lopMoi
}

function layDanhSach(response) {
  if (Array.isArray(response)) return response
  if (Array.isArray(response?.content)) return response.content
  if (Array.isArray(response?.data?.content)) return response.data.content
  if (Array.isArray(response?.data)) return response.data
  return []
}

function baoThanhCong(message) {
  thongBao.value = message
  thongBaoLoai.value = 'success'
}

function baoLoi(message) {
  thongBao.value = message
  thongBaoLoai.value = 'error'
}
</script>

<style scoped>
.sv-page,
.sv-bl-page,
.sv-lhp-page,
.sv-page *,
.sv-bl-page *,
.sv-lhp-page * {
  font-family: inherit;
  letter-spacing: normal;
}

.sv-page,
.sv-bl-page,
.sv-lhp-page {
  display: grid;
  gap: 14px;
}

.sv-header,
.sv-card,
.sv-filter-card,
.sv-account-box,
.page-title,
.panel {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 14px;
  padding: 14px;
  box-shadow: 0 8px 22px rgba(15, 23, 42, 0.05);
}

.sv-header {
  background: linear-gradient(135deg, #f8fafc, #eff6ff);
  border-color: #bfdbfe;
}

.sv-header h1,
.page-title h2,
.sv-card-title h2,
.panel-title h2,
.sv-card h2,
.modal-header h2,
.sv-modal-header h2 {
  margin: 0;
  color: #0f172a;
  font-size: 18px;
  font-weight: 700;
  line-height: 1.35;
  letter-spacing: normal;
}

.sv-header p,
.page-title p,
.sv-card-title p,
.panel-title p,
.panel-subtitle,
.sv-card p,
.modal-header p,
.sv-modal-header p {
  margin: 5px 0 0;
  color: #64748b;
  font-size: 13px;
  font-weight: 400;
  line-height: 1.45;
  letter-spacing: normal;
}

.sv-eyebrow {
  margin: 0 0 4px;
  color: #1d4ed8 !important;
  font-size: 13px;
  font-weight: 700;
  text-transform: none;
  letter-spacing: normal;
}

.sv-card-title,
.panel-title {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 12px;
  margin-bottom: 12px;
}

.panel-title span {
  color: #64748b;
  font-size: 13px;
  font-weight: 600;
}

.sv-grid,
.form-grid,
.filter-grid {
  display: grid;
  gap: 10px;
}

.sv-grid.two,
.form-grid {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}

.sv-grid.three {
  grid-template-columns: repeat(3, minmax(0, 1fr));
}

.sv-grid.four,
.filter-grid,
.bao-luu-filter {
  grid-template-columns: repeat(4, minmax(0, 1fr));
}

.sv-filter-card {
  display: grid;
  grid-template-columns: 1fr 1.2fr 1.2fr 1.2fr auto;
  gap: 10px;
  align-items: end;
}

.content-grid {
  display: grid;
  grid-template-columns: minmax(360px, 0.9fr) minmax(0, 1.35fr);
  gap: 14px;
}

.span-2 {
  grid-column: span 2;
}

.span-3 {
  grid-column: span 3;
}

.span-4 {
  grid-column: span 4;
}

label {
  display: grid;
  gap: 5px;
  color: #334155;
  font-size: 13px;
  font-weight: 600;
  letter-spacing: normal;
}

input,
select,
textarea {
  width: 100%;
  min-height: 38px;
  border: 1px solid #cbd5e1;
  border-radius: 10px;
  padding: 8px 10px;
  background: #ffffff;
  color: #0f172a;
  font: inherit;
  font-size: 14px;
  font-weight: 400;
  letter-spacing: normal;
  outline: none;
  transition: border-color 0.15s ease, box-shadow 0.15s ease;
}

textarea {
  min-height: 76px;
  resize: vertical;
}

input:focus,
select:focus,
textarea:focus {
  border-color: #2563eb;
  box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.12);
}

input:disabled,
select:disabled,
textarea:disabled {
  background: #f8fafc;
  color: #64748b;
  cursor: not-allowed;
}

.sv-actions,
.actions,
.form-actions,
.row-actions,
.sv-row-actions,
.sv-modal-actions {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}

button,
.sv-action-link {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-height: 36px;
  border: 0;
  border-radius: 10px;
  padding: 8px 12px;
  background: #1d4ed8;
  color: #ffffff;
  font-size: 14px;
  font-weight: 700;
  letter-spacing: normal;
  text-transform: none;
  line-height: 1;
  text-decoration: none;
  cursor: pointer;
  transition: transform 0.12s ease, filter 0.12s ease, background 0.12s ease;
}

button:hover,
.sv-action-link:hover {
  filter: brightness(0.97);
  transform: translateY(-1px);
}

button:disabled {
  opacity: 0.6;
  cursor: not-allowed;
  transform: none;
}

button.secondary {
  background: #e2e8f0;
  color: #334155;
}

button.danger {
  background: #dc2626;
  color: #ffffff;
}

button.small {
  min-height: 30px;
  padding: 6px 9px;
  font-size: 13px;
}

button.selected {
  background: #047857;
  color: #ffffff;
}

.sv-action-link {
  background: #f59e0b;
  color: #ffffff;
}

.sv-tabs {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.sv-tabs button {
  background: #e2e8f0;
  color: #334155;
}

.sv-tabs button.active {
  background: #1d4ed8;
  color: #ffffff;
}

.sv-message,
.message {
  border-radius: 12px;
  padding: 10px 12px;
  font-size: 13px;
  font-weight: 600;
  letter-spacing: normal;
}

.sv-message.success,
.message.success {
  background: #ecfdf5;
  color: #047857;
  border: 1px solid #a7f3d0;
}

.sv-message.error,
.message.error {
  background: #fef2f2;
  color: #b91c1c;
  border: 1px solid #fecaca;
}

.sv-account-box {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
  background: #fffbeb;
  border-color: #fbbf24;
  color: #78350f;
}

.sv-class-summary {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 10px;
  margin-bottom: 12px;
}

.sv-class-summary div,
.sv-flow-item,
.sv-selected,
.sinh-vien-da-chon {
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  padding: 10px;
  background: #f8fafc;
}

.sv-class-summary span {
  color: #64748b;
  font-size: 12px;
  font-weight: 400;
}

.sv-class-summary strong {
  color: #0f172a;
  font-size: 14px;
  font-weight: 700;
}

.sv-flow {
  display: grid;
  grid-template-columns: repeat(6, minmax(0, 1fr));
  gap: 10px;
}

.sv-flow-item {
  display: grid;
  gap: 5px;
}

.sv-flow-item.active {
  border-color: #93c5fd;
  background: #eff6ff;
}

.sv-list-filter {
  display: flex;
  justify-content: flex-end;
  margin-bottom: 10px;
}

.sv-table-wrap,
.table-wrap {
  width: 100%;
  overflow: auto;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  background: #ffffff;
}

.sv-table,
table {
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
}

.bang-lop-hoc-phan {
  min-width: 1500px;
}

th,
td,
.sv-table th,
.sv-table td {
  border-bottom: 1px solid #e2e8f0;
  padding: 8px 10px;
  text-align: left;
  vertical-align: top;
}

th,
.sv-table th {
  position: sticky;
  top: 0;
  z-index: 1;
  background: #f8fafc;
  color: #334155;
  font-size: 13px;
  font-weight: 700;
  text-transform: none;
  letter-spacing: normal;
  white-space: nowrap;
}

td,
.sv-table td {
  color: #334155;
  font-size: 13px;
  font-weight: 400;
  letter-spacing: normal;
}

td.diem,
td.cot-diem,
td[data-label*='Điểm'],
td[data-label*='điểm'],
.sv-table td.diem,
.sv-table td.cot-diem,
.sv-table td[data-label*='Điểm'],
.sv-table td[data-label*='điểm'] {
  font-weight: 700;
  color: #0f172a;
}

tbody tr:hover td,
.clickable-row:hover td {
  background: #f8fafc;
}

tr.selected td,
.sv-table tr.selected td {
  background: #eff6ff;
}

.clickable-row {
  cursor: pointer;
}

.empty {
  text-align: center;
  color: #64748b;
  padding: 18px;
  font-weight: 600;
}

.sv-avatar {
  width: 42px;
  height: 42px;
  object-fit: cover;
  border: 1px solid #e2e8f0;
  border-radius: 10px;
  background: #f8fafc;
}

.sv-status,
.status {
  display: inline-flex;
  align-items: center;
  border-radius: 999px;
  padding: 4px 9px;
  font-size: 12px;
  font-weight: 600;
  letter-spacing: normal;
  white-space: nowrap;
}

.sv-status.done,
.status.da_di_hoc_lai {
  background: #ecfdf5;
  color: #047857;
}

.sv-status.partial,
.status.dang_bao_luu {
  background: #fffbeb;
  color: #b45309;
}

.sv-status.pending,
.status.da_huy {
  background: #fef2f2;
  color: #b91c1c;
}

.tim-sinh-vien-box {
  display: grid;
  grid-template-columns: minmax(260px, 1fr) auto;
  gap: 10px;
  align-items: end;
}

.sinh-vien-da-chon {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
  border-color: #bfdbfe;
  background: #eff6ff;
  color: #1e3a8a;
}

.modal-overlay,
.sv-modal-overlay {
  position: fixed;
  inset: 0;
  z-index: 9999;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
  background: rgba(15, 23, 42, 0.55);
}

.modal,
.sv-modal {
  width: min(900px, 100%);
  max-height: calc(100vh - 40px);
  overflow: auto;
  border-radius: 16px;
  padding: 16px;
  background: #ffffff;
  box-shadow: 0 24px 80px rgba(15, 23, 42, 0.32);
}

.modal-header,
.sv-modal-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 14px;
  margin-bottom: 14px;
}

.modal-close,
.sv-modal-close {
  width: 34px;
  height: 34px;
  min-height: 34px;
  border-radius: 999px;
  padding: 0;
  background: #e2e8f0;
  color: #0f172a;
  font-size: 22px;
  font-weight: 400;
  line-height: 1;
}

@media (max-width: 1200px) {
  .sv-filter-card,
  .sv-grid.four,
  .filter-grid,
  .form-grid,
  .bao-luu-filter,
  .content-grid,
  .sv-class-summary,
  .sv-flow {
    grid-template-columns: 1fr;
  }

  .span-2,
  .span-3,
  .span-4 {
    grid-column: span 1;
  }
}

@media (max-width: 700px) {
  .sv-header,
  .sv-card,
  .sv-filter-card,
  .sv-account-box,
  .page-title,
  .panel {
    padding: 12px;
    border-radius: 12px;
  }

  .sv-card-title,
  .panel-title {
    display: grid;
  }

  .sv-actions,
  .actions,
  .form-actions,
  .row-actions,
  .sv-row-actions,
  .sv-modal-actions {
    justify-content: stretch;
  }

  button,
  .sv-action-link {
    width: 100%;
  }

  .tim-sinh-vien-box {
    grid-template-columns: 1fr;
  }
}
</style>