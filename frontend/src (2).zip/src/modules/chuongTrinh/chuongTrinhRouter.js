import ChuongTrinhDanhSach from '@/modules/chuongTrinh/pages/admin/danhSach/ChuongTrinhDanhSach.vue';
import ChuongTrinhDaoTaoHome from '@/modules/chuongTrinh/pages/luongChuongTrinh/ChuongTrinhDaoTaoHome.vue';
import ChiTietChuongTrinhDaoTao from '@/modules/chuongTrinh/pages/luongChuongTrinh/ChiTietChuongTrinhDaoTao.vue';
import DanhSachPhienBanChuongTrinh from '@/modules/chuongTrinh/pages/luongChuongTrinh/DanhSachPhienBanChuongTrinh.vue';
import ChiTietPhienBanChuongTrinh from '@/modules/chuongTrinh/pages/luongChuongTrinh/ChiTietPhienBanChuongTrinh.vue';
import KhungChuongTrinhDaoTao from '@/modules/chuongTrinh/pages/luongChuongTrinh/KhungChuongTrinhDaoTao.vue';
import ChiTietMonHocChuongTrinh from '@/modules/chuongTrinh/pages/luongChuongTrinh/ChiTietMonHocChuongTrinh.vue';
import { CHUONG_TRINH_RESOURCES } from '@/modules/chuongTrinh/constants/trangThaiChuongTrinh.js';

export default [
  {
    path: '/chuong-trinh',
    name: 'chuong-trinh-dao-tao-home',
    component: ChuongTrinhDaoTaoHome,
    meta: { moduleKey: 'chuongTrinh', title: 'Chương trình đào tạo' },
  },
  {
    path: '/chuong-trinh/danh-sach',
    redirect: '/chuong-trinh',
  },
  {
    path: '/chuong-trinh/:chuongTrinhId',
    name: 'chi-tiet-chuong-trinh-dao-tao',
    component: ChiTietChuongTrinhDaoTao,
    meta: { moduleKey: 'chuongTrinh', title: 'Chi tiết chương trình đào tạo' },
  },
  {
    path: '/chuong-trinh/:chuongTrinhId/phien-ban',
    name: 'danh-sach-phien-ban-chuong-trinh',
    component: DanhSachPhienBanChuongTrinh,
    meta: { moduleKey: 'chuongTrinh', title: 'Phiên bản chương trình' },
  },
  {
    path: '/chuong-trinh/:chuongTrinhId/phien-ban/:versionId',
    name: 'chi-tiet-phien-ban-chuong-trinh',
    component: ChiTietPhienBanChuongTrinh,
    meta: { moduleKey: 'chuongTrinh', title: 'Chi tiết phiên bản chương trình' },
  },
  {
    path: '/chuong-trinh/:chuongTrinhId/phien-ban/:versionId/khung-chuong-trinh',
    name: 'khung-chuong-trinh-dao-tao',
    component: KhungChuongTrinhDaoTao,
    meta: { moduleKey: 'chuongTrinh', title: 'Khung chương trình đào tạo' },
  },
  {
    path: '/chuong-trinh/:chuongTrinhId/phien-ban/:versionId/mon-hoc/:chuongTrinhMonId',
    name: 'chi-tiet-mon-hoc-chuong-trinh',
    component: ChiTietMonHocChuongTrinh,
    meta: { moduleKey: 'chuongTrinh', title: 'Chi tiết môn học trong chương trình' },
  },
  ...CHUONG_TRINH_RESOURCES.map((resource) => ({
    path: `/chuong-trinh/quan-ly/${resource.segment}`,
    name: `quan-ly-${resource.segment}`,
    component: ChuongTrinhDanhSach,
    meta: { moduleKey: 'chuongTrinh', resourceKey: resource.key, title: resource.title },
  })),
];
