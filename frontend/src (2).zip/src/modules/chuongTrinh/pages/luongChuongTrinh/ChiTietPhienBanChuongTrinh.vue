<template>
  <section class="ct-screen">
    <div class="ct-shell">
      <header class="ct-page-head">
        <div class="ct-head-main"><div class="ct-kicker">Phiên bản chương trình</div><h1 class="ct-title">{{ title }}</h1><p class="ct-desc">Quản lý mục tiêu, chuẩn đầu ra và điều kiện tốt nghiệp của phiên bản chương trình.</p></div>
        <div class="ct-actions"><RouterLink class="ct-btn light" :to="`/chuong-trinh/${chuongTrinhId}`">Quay về chi tiết chương trình</RouterLink><RouterLink class="ct-btn" :to="`/chuong-trinh/${chuongTrinhId}/phien-ban/${versionId}/khung-chuong-trinh`">Xem khung chương trình</RouterLink></div>
      </header>
      <main class="ct-main">
        <div v-if="loading" class="ct-loading">Đang tải dữ liệu...</div><div v-else-if="error" class="ct-error">{{ error }}</div>
        <template v-else>
          <section class="ct-info-grid"><article class="ct-info"><b>Mã version</b><span>{{ detail.maVersion || '—' }}</span></article><article class="ct-info"><b>Ngày áp dụng</b><span>{{ detail.ngayApDung || '—' }}</span></article><article class="ct-info"><b>Tổng tín chỉ</b><span>{{ detail.tongTinChi || '—' }}</span></article><article class="ct-info"><b>Trạng thái</b><span>{{ detail.laHienHanh ? 'Hiện hành' : 'Lưu trữ' }}</span></article></section>
          <section class="ct-panel"><div class="ct-tabs"><button v-for="tab in tabs" :key="tab.key" :class="['ct-tab',{active:activeTab===tab.key}]" type="button" @click="activeTab=tab.key">{{ tab.label }}</button></div><div class="ct-panel-head"><div><h2 class="ct-panel-title">{{ currentTitle }}</h2><p class="ct-panel-subtitle">{{ currentRows.length }} bản ghi</p></div><button class="ct-btn" type="button" @click="openCreateRelated">Thêm mới</button></div><div class="ct-list"><article v-for="item in currentRows" :key="layIdBanGhi(item)" class="ct-list-item"><b>{{ labelRelated(item) }}</b><div class="ct-muted">{{ item.noiDung || item.moTa || item.ten || item.ma || '—' }}</div><div class="ct-actions" style="margin-top:10px"><button class="ct-btn small light" type="button" @click="openEditRelated(item)">Sửa</button><button class="ct-btn small danger" type="button" @click="removeRelated(item)">Xóa</button></div></article><div v-if="!currentRows.length" class="ct-empty">Chưa có dữ liệu.</div></div></section>
        </template>
      </main>
    </div>
    <BieuMauQuanLyModal v-model="versionForm" :open="versionModal" mode="edit" :fields="versionFields" :saving="saving" title="Phiên bản chương trình" @close="versionModal=false" @submit="saveVersion" />
    <BieuMauQuanLyModal v-model="relatedForm" :open="relatedModal" :mode="relatedMode" :fields="currentFields" :saving="saving" :title="currentTitle" @close="relatedModal=false" @submit="saveRelated" />
  </section>
</template>
<script setup>
import { computed, onMounted, ref } from 'vue';
import { useRoute } from 'vue-router';
import './luongChuongTrinh.css';
import BieuMauQuanLyModal from '@/modules/chuongTrinh/components/modal/BieuMauQuanLyModal.vue';
import { CHUONG_TRINH_RESOURCE_MAP } from '@/modules/chuongTrinh/constants/trangThaiChuongTrinh.js';
import { API_LUONG_CHUONG_TRINH, capNhatBanGhi, layChiTietPhienBan, layDanhSachDieuKienTotNghiep, layDanhSachMucTieu, layDanhSachNangLucDauRa, layDanhSachViTriViecLam, layIdBanGhi, locTheoGiaTri, taoBanGhi, taoNhanPhienBan, xoaBanGhi } from '@/modules/chuongTrinh/services/luongChuongTrinhDaoTaoService.js';
const route=useRoute(); const chuongTrinhId=computed(()=>route.params.chuongTrinhId); const versionId=computed(()=>route.params.versionId); const detail=ref({}); const loading=ref(false); const saving=ref(false); const error=ref(''); const activeTab=ref('mucTieu'); const title=computed(()=>taoNhanPhienBan(detail.value));
const rows=ref({mucTieu:[],nangLuc:[],dieuKien:[],viecLam:[]});
const tabs=[{key:'mucTieu',label:'Mục tiêu',resource:'muc-tieu-chuong-trinh',endpoint:API_LUONG_CHUONG_TRINH.MUC_TIEU},{key:'nangLuc',label:'Năng lực đầu ra',resource:'nang-luc-dau-ra',endpoint:API_LUONG_CHUONG_TRINH.NANG_LUC_DAU_RA},{key:'dieuKien',label:'Điều kiện tốt nghiệp',resource:'dieu-kien-tot-nghiep',endpoint:API_LUONG_CHUONG_TRINH.DIEU_KIEN_TOT_NGHIEP},{key:'viecLam',label:'Vị trí việc làm',resource:'vi-tri-viec-lam',endpoint:API_LUONG_CHUONG_TRINH.VI_TRI_VIEC_LAM}];
const currentTab=computed(()=>tabs.find(t=>t.key===activeTab.value)||tabs[0]); const currentTitle=computed(()=>CHUONG_TRINH_RESOURCE_MAP[currentTab.value.resource]?.title||currentTab.value.label); const currentFields=computed(()=>CHUONG_TRINH_RESOURCE_MAP[currentTab.value.resource]?.fields||[]); const currentRows=computed(()=>rows.value[activeTab.value]||[]); const versionFields=CHUONG_TRINH_RESOURCE_MAP['chuong-trinh-version'].fields;
const versionModal=ref(false); const relatedModal=ref(false); const relatedMode=ref('create'); const versionForm=ref({}); const relatedForm=ref({});
const labelRelated=(item)=>item.ma||item.ten||item.loai||item.noiDung||item.moTa||`#${layIdBanGhi(item)}`;
const loadData=async()=>{loading.value=true;error.value='';try{const [v,mt,nl,dk,vl]=await Promise.all([layChiTietPhienBan(versionId.value),layDanhSachMucTieu({chuongTrinhVersionId:versionId.value}),layDanhSachNangLucDauRa({chuongTrinhVersionId:versionId.value}),layDanhSachDieuKienTotNghiep({chuongTrinhVersionId:versionId.value}),layDanhSachViTriViecLam({chuongTrinhVersionId:versionId.value})]); detail.value=v||{}; rows.value={mucTieu:locTheoGiaTri(mt,'chuongTrinhVersionId',versionId.value),nangLuc:locTheoGiaTri(nl,'chuongTrinhVersionId',versionId.value),dieuKien:locTheoGiaTri(dk,'chuongTrinhVersionId',versionId.value),viecLam:locTheoGiaTri(vl,'chuongTrinhVersionId',versionId.value)};}catch(err){error.value=err?.message||'Không tải được chi tiết phiên bản.';}finally{loading.value=false;}};
const openEditVersion=()=>{versionForm.value={...detail.value};versionModal.value=true;}; const saveVersion=async()=>{saving.value=true;try{await capNhatBanGhi(API_LUONG_CHUONG_TRINH.PHIEN_BAN,versionId.value,versionForm.value);versionModal.value=false;await loadData();}finally{saving.value=false;}};
const openCreateRelated=()=>{relatedMode.value='create';relatedForm.value={chuongTrinhVersionId:Number(versionId.value)};relatedModal.value=true;}; const openEditRelated=(item)=>{relatedMode.value='edit';relatedForm.value={...item};relatedModal.value=true;};
const saveRelated=async()=>{saving.value=true;try{const id=layIdBanGhi(relatedForm.value);if(relatedMode.value==='edit'&&id)await capNhatBanGhi(currentTab.value.endpoint,id,relatedForm.value);else await taoBanGhi(currentTab.value.endpoint,relatedForm.value);relatedModal.value=false;await loadData();}finally{saving.value=false;}};
const removeRelated=async(item)=>{const id=layIdBanGhi(item);if(id&&confirm('Xóa bản ghi này?')){await xoaBanGhi(currentTab.value.endpoint,id);await loadData();}};
onMounted(loadData);
</script>
