import { useModuleCrud } from '@/modules/chuong-trinh/composables/useModuleCrud.js';

// Backward compatibility cho code cũ đang import useModuleTable.
export const useModuleTable = useModuleCrud;
