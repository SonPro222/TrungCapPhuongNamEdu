<template>
  <div class="pn-main-layout">
    <AppNav />
    <AppBreadcrumb />
    <div class="pn-layout-body">
      <aside class="pn-side-rail" aria-label="Điều hướng chính">
        <RouterLink class="pn-rail-item" to="/dashboard">
          <span>⌂</span>
          <b>Dashboard</b>
        </RouterLink>
      </aside>

      <main class="pn-page-area">
        <router-view />
      </main>
    </div>
  </div>
</template>

<script setup>
import AppNav from '@/components/nav/AppNav.vue';
import AppBreadcrumb from '@/components/breadcrumb/AppBreadcrumb.vue';
</script>

<style scoped>
.pn-main-layout{width:100vw;height:100vh;display:flex;flex-direction:column;overflow:hidden;background:#f4f6fa;color:#111827}.pn-layout-body{display:grid;grid-template-columns:82px minmax(0,1fr);flex:1;min-height:0}.pn-side-rail{background:#1f242b;border-right:1px solid #111827;padding:14px 8px;display:flex;flex-direction:column;gap:8px}.pn-rail-item{height:74px;border-radius:8px;color:#f8fafc;text-decoration:none;display:flex;align-items:center;justify-content:center;gap:7px;flex-direction:column;text-align:center;font-weight:800}.pn-rail-item span{font-size:20px;line-height:1}.pn-rail-item b{font-size:11px;line-height:1.2}.pn-rail-item:hover,.pn-rail-item.router-link-active{background:#0f172a;color:#fff}.pn-page-area{min-width:0;min-height:0;overflow:auto;background:#f4f6fa;width:100%}@media(max-width:900px){.pn-layout-body{grid-template-columns:1fr}.pn-side-rail{display:none}}
</style>
