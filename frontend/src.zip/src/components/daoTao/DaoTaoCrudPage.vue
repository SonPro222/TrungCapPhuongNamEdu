<template>
  <section class="crud-page">
    <header class="hero">
      <div>
        <p class="eyebrow">Luồng đào tạo</p>
        <h1>{{ pageConfig.title }}</h1>
        <p class="hero-text">{{ pageConfig.subtitle }}</p>
      </div>

      <div class="hero-actions">
        <button class="ghost-btn" type="button" @click="reloadAll" :disabled="loading">Tải lại</button>
        <button class="primary-btn" type="button" @click="openCreate">Thêm mới</button>
      </div>
    </header>

    <section class="filters">
      <label class="field wide">
        <span>Tìm kiếm</span>
        <input v-model.trim="keyword" type="text" :placeholder="`Tìm trong ${pageConfig.title.toLowerCase()}...`" />
      </label>

      <label v-if="showLoaiFilter" class="field">
        <span>Loại chương trình</span>
        <select v-model="filters.loaiChuongTrinhId">
          <option value="">Tất cả</option>
          <option v-for="item in dataStore.loaiChuongTrinh" :key="item.id" :value="String(item.id)">
            {{ loaiLabel(item) }}
          </option>
        </select>
      </label>
    </section>

    <section class="stats">
      <article class="stat-card">
        <span class="stat-label">Ngành đang chọn</span>
        <strong>{{ selectedContextLabel('nganhId', nganhLabelById) }}</strong>
      </article>
      <article class="stat-card">
        <span class="stat-label">Trình độ đang chọn</span>
        <strong>{{ selectedContextLabel('trinhDoId', trinhDoLabelById) }}</strong>
      </article>
      <article class="stat-card">
        <span class="stat-label">Loại CT đang chọn</span>
        <strong>{{ selectedContextLabel('loaiChuongTrinhId', loaiLabelById) }}</strong>
      </article>
      <article class="stat-card">
        <span class="stat-label">Khớp bộ lọc</span>
        <strong>{{ filteredRecords.length }}</strong>
      </article>
    </section>

    <section class="flow-strip">
      <button
        v-for="step in flowSteps"
        :key="step.key"
        class="flow-chip"
        :class="{ active: step.key === route.meta.pageKey, disabled: !canOpenStep(step) }"
        type="button"
        :disabled="!canOpenStep(step)"
        @click="goFlowStep(step)"
      >
        {{ step.label }}
      </button>
    </section>

    <div v-if="error" class="feedback error">{{ error }}</div>
    <div v-if="success" class="feedback success">{{ success }}</div>

    <section class="content">
      <article class="table-panel">
        <div class="panel-head">
          <div>
            <p class="mini-label">CRUD + lọc</p>
            <h2>{{ pageConfig.title }}</h2>
          </div>
        </div>

        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                <th v-for="column in pageConfig.columns" :key="column.key">{{ column.label }}</th>
                <th class="actions-col">Thao tác</th>
              </tr>
            </thead>
            <tbody>
              <tr
                v-for="item in filteredRecords"
                :key="item.id"
                :class="{ selected: String(item.id) === selectedRecordId }"
              >
                <td v-for="column in pageConfig.columns" :key="column.key">
                  {{ formatCell(item, column) }}
                </td>
                <td class="row-actions">
                  <button class="table-btn" type="button" @click="openEdit(item)">Sửa</button>
                  <button class="table-btn danger" type="button" @click="removeItem(item)">Xóa</button>
                  <button class="table-btn accent" type="button" @click="goNext(item)">
                    {{ pageConfig.nextLabel }}
                  </button>
                </td>
              </tr>
              <tr v-if="!filteredRecords.length">
                <td :colspan="pageConfig.columns.length + 1" class="empty-row">
                  Không có dữ liệu phù hợp với bộ lọc hiện tại.
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </article>
    </section>

    <div v-if="showForm" class="modal-backdrop" @click.self="closeForm">
      <div class="modal">
        <div class="modal-head">
          <div>
            <p class="mini-label">Biểu mẫu</p>
            <h2>{{ editingId ? `Cập nhật ${pageConfig.title.toLowerCase()}` : `Thêm ${pageConfig.title.toLowerCase()}` }}</h2>
          </div>
          <button class="icon-close" type="button" @click="closeForm">Đóng</button>
        </div>

        <form class="form-grid" @submit.prevent="saveItem">
          <label
            v-for="field in pageConfig.fields"
            :key="field.key"
            class="field"
            :class="{ wide: field.wide }"
          >
            <span>{{ field.label }}</span>

            <select v-if="field.type === 'select'" v-model="form[field.key]" :required="field.required">
              <option value="">Chọn {{ field.label.toLowerCase() }}</option>
              <option v-for="option in getFieldOptions(field)" :key="option.value" :value="option.value">
                {{ option.label }}
              </option>
            </select>

            <textarea
              v-else-if="field.type === 'textarea'"
              v-model.trim="form[field.key]"
              :required="field.required"
              rows="4"
            />

            <input
              v-else
              v-model="form[field.key]"
              :type="field.type === 'number' ? 'number' : 'text'"
              :required="field.required"
              :step="field.type === 'number' ? '1' : undefined"
            />
          </label>

          <div class="modal-actions wide">
            <button class="primary-btn" type="submit" :disabled="saving">
              {{ saving ? 'Đang lưu...' : 'Lưu dữ liệu' }}
            </button>
            <button class="ghost-btn" type="button" @click="closeForm">Hủy</button>
          </div>
        </form>
      </div>
    </div>
  </section>
</template>

<script setup>
import { computed, onMounted, reactive, ref, watch } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { getErrorMessage, matchKeyword, toNumberOrNull, unwrapApiList } from '@/api/apiResponse.js';
import { DAO_TAO_DATA_SOURCES, DAO_TAO_PAGE_CONFIG } from '@/config/daoTao/daoTaoCrudConfig.js';
import { CHUONG_TRINH_FLOW_STEPS, pickRouteContext } from '@/config/chuongTrinh/chuongTrinhFlowConfig.js';

const route = useRoute();
const router = useRouter();

const loading = ref(false);
const saving = ref(false);
const error = ref('');
const success = ref('');
const keyword = ref('');
const showForm = ref(false);
const editingId = ref(null);

const filters = reactive({
  loaiChuongTrinhId: '',
});

const form = reactive({});

const dataStore = reactive({
  nganh: [],
  trinhDoDaoTao: [],
  loaiChuongTrinh: [],
  khungKy: [],
});

const flowSteps = CHUONG_TRINH_FLOW_STEPS;
const pageConfig = computed(() => DAO_TAO_PAGE_CONFIG[route.meta.pageKey] || DAO_TAO_PAGE_CONFIG.nganh);
const records = computed(() => dataStore[pageConfig.value.dataKey] || []);
const showLoaiFilter = computed(() => route.meta.pageKey === 'khung-ky' || Boolean(filters.loaiChuongTrinhId));
const selectedRecordId = computed(() => {
  const key = pageConfig.value.contextKey;
  return key ? String(currentRouteContext()[key] || '') : '';
});

const filteredRecords = computed(() => records.value
  .filter((item) => {
    if (route.meta.pageKey !== 'khung-ky') return true;
    if (!filters.loaiChuongTrinhId) return true;
    return Number(item.loaiChuongTrinhId) === Number(filters.loaiChuongTrinhId);
  })
  .filter((item) => matchKeyword(item, keyword.value, pageConfig.value.searchFields || [])));

watch(() => route.meta.pageKey, () => {
  resetFilters();
  applyRouteContextToFilters();
  closeForm();
});

watch(() => route.query, () => {
  applyRouteContextToFilters();
}, { deep: true });

onMounted(async () => {
  applyRouteContextToFilters();
  await reloadAll();
});

async function reloadAll() {
  loading.value = true;
  error.value = '';

  try {
    const responses = await Promise.all(Object.values(DAO_TAO_DATA_SOURCES).map((loader) => loader()));
    Object.keys(DAO_TAO_DATA_SOURCES).forEach((key, index) => {
      dataStore[key] = unwrapApiList(responses[index]);
    });
  } catch (err) {
    error.value = getErrorMessage(err);
  } finally {
    loading.value = false;
  }
}

function resetFilters() {
  keyword.value = '';
  filters.loaiChuongTrinhId = '';
}

function applyRouteContextToFilters() {
  const context = pickRouteContext(route.query);
  filters.loaiChuongTrinhId = context.loaiChuongTrinhId ? String(context.loaiChuongTrinhId) : '';
}

function currentRouteContext() {
  return {
    ...pickRouteContext(route.query),
    ...(filters.loaiChuongTrinhId ? { loaiChuongTrinhId: filters.loaiChuongTrinhId } : {}),
  };
}

function selectedContextLabel(key, formatter) {
  const value = currentRouteContext()[key];
  return value ? formatter(value) : 'Chưa chọn';
}

function canOpenStep(step) {
  const context = currentRouteContext();
  return !step.needs || Boolean(context[step.needs]);
}

function goFlowStep(step) {
  if (!canOpenStep(step)) return;
  router.push({ name: step.routeName, query: currentRouteContext() });
}

function goNext(item) {
  const contextKey = pageConfig.value.contextKey;
  const query = {
    ...currentRouteContext(),
    [contextKey]: item.id,
  };

  if (route.meta.pageKey === 'khung-ky') {
    query.loaiChuongTrinhId = item.loaiChuongTrinhId;
  }

  router.push({
    name: pageConfig.value.nextRouteName,
    query,
  });
}

function openCreate() {
  editingId.value = null;
  resetForm();
  applyContextDefaultsToForm();
  showForm.value = true;
}

function openEdit(item) {
  editingId.value = item.id;
  resetForm();
  pageConfig.value.fields.forEach((field) => {
    form[field.key] = normalizeFormValue(item[field.key], field.type);
  });
  showForm.value = true;
}

function closeForm() {
  showForm.value = false;
  editingId.value = null;
  resetForm();
}

function resetForm() {
  pageConfig.value.fields.forEach((field) => {
    form[field.key] = '';
  });
}

function applyContextDefaultsToForm() {
  if ('loaiChuongTrinhId' in form && filters.loaiChuongTrinhId) {
    form.loaiChuongTrinhId = filters.loaiChuongTrinhId;
  }
}

async function saveItem() {
  saving.value = true;
  error.value = '';
  success.value = '';

  try {
    const payload = buildPayload();
    if (editingId.value) {
      await pageConfig.value.update(editingId.value, payload);
      success.value = `Đã cập nhật ${pageConfig.value.title.toLowerCase()}.`;
    } else {
      await pageConfig.value.create(payload);
      success.value = `Đã thêm ${pageConfig.value.title.toLowerCase()}.`;
    }

    closeForm();
    await reloadAll();
  } catch (err) {
    error.value = getErrorMessage(err);
  } finally {
    saving.value = false;
  }
}

async function removeItem(item) {
  if (!item?.id) return;
  if (!window.confirm(`Xóa bản ghi trong ${pageConfig.value.title.toLowerCase()}?`)) return;

  try {
    await pageConfig.value.remove(item.id);
    success.value = `Đã xóa dữ liệu trong ${pageConfig.value.title.toLowerCase()}.`;
    await reloadAll();
  } catch (err) {
    error.value = getErrorMessage(err);
  }
}

function buildPayload() {
  return Object.fromEntries(
    pageConfig.value.fields
      .map((field) => [field.key, convertFieldValue(form[field.key], field.type)])
      .filter(([, value]) => value !== '' && value !== undefined)
  );
}

function normalizeFormValue(value) {
  if (value === null || value === undefined) return '';
  return String(value);
}

function convertFieldValue(value, type) {
  if (type === 'number') return toNumberOrNull(value);
  if (type === 'select') return toNumberOrNull(value) ?? value;
  return String(value ?? '').trim();
}

function getFieldOptions(field) {
  if (field.optionKey === 'loaiChuongTrinh') {
    return dataStore.loaiChuongTrinh.map((item) => ({
      value: String(item.id),
      label: loaiLabel(item),
    }));
  }

  return [];
}

function formatCell(item, column) {
  if (column.format === 'loaiChuongTrinh') {
    return loaiLabelById(item[column.key]);
  }

  return item[column.key] ?? '-';
}

function loaiLabel(item) {
  return `${item.maLoai || '---'} - ${item.tenLoai || 'Chưa có tên loại'}`;
}

function nganhLabelById(id) {
  const item = dataStore.nganh.find((entry) => Number(entry.id) === Number(id));
  return item ? `${item.maNganh} - ${item.tenNganh}` : '-';
}

function trinhDoLabelById(id) {
  const item = dataStore.trinhDoDaoTao.find((entry) => Number(entry.id) === Number(id));
  return item ? `${item.maTrinhDo} - ${item.tenTrinhDo}` : '-';
}

function loaiLabelById(id) {
  const item = dataStore.loaiChuongTrinh.find((entry) => Number(entry.id) === Number(id));
  return item ? loaiLabel(item) : '-';
}
</script>

<style scoped>
.crud-page {
  padding: 24px;
  display: grid;
  gap: 18px;
  color: #123046;
}

.hero,
.filters,
.stats,
.table-panel,
.modal,
.flow-strip {
  background: rgba(255, 255, 255, 0.9);
  border: 1px solid rgba(18, 72, 104, 0.08);
  border-radius: 20px;
  box-shadow: 0 16px 40px rgba(19, 57, 79, 0.08);
}

.hero {
  display: flex;
  justify-content: space-between;
  gap: 16px;
  padding: 24px;
}

.eyebrow,
.mini-label {
  margin: 0 0 8px;
  font-size: 12px;
  font-weight: 800;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: #27739e;
}

.hero h1,
.panel-head h2,
.modal-head h2 {
  margin: 0;
}

.hero-text {
  max-width: 760px;
  margin: 10px 0 0;
  line-height: 1.6;
  color: #4d6780;
}

.hero-actions,
.modal-actions,
.row-actions {
  display: flex;
  gap: 10px;
}

.filters,
.stats,
.flow-strip {
  padding: 18px;
}

.filters {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 14px;
}

.stats {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 14px;
}

.stat-card {
  padding: 16px;
  border-radius: 16px;
  background: linear-gradient(180deg, #f7fbfe 0%, #eef6fb 100%);
}

.stat-label {
  display: block;
  color: #587085;
  font-size: 12px;
}

.stat-card strong {
  display: block;
  margin-top: 8px;
  word-break: break-word;
}

.flow-strip {
  display: flex;
  gap: 10px;
  overflow-x: auto;
}

.flow-chip {
  border: 0;
  border-radius: 999px;
  padding: 10px 14px;
  background: #e9f3fa;
  color: #123046;
  font-weight: 800;
  cursor: pointer;
  white-space: nowrap;
}

.flow-chip.active {
  background: #0f766e;
  color: #fff;
}

.flow-chip.disabled {
  opacity: 0.45;
  cursor: not-allowed;
}

.field {
  display: grid;
  gap: 8px;
}

.field span {
  font-size: 13px;
  font-weight: 700;
  color: #2e4b60;
}

.field input,
.field select,
.field textarea {
  width: 100%;
  border: 1px solid #c9d9e6;
  border-radius: 14px;
  padding: 11px 13px;
  font: inherit;
  background: #fff;
  color: #123046;
}

.field.wide {
  grid-column: 1 / -1;
}

.feedback {
  padding: 14px 16px;
  border-radius: 14px;
  font-weight: 600;
}

.feedback.error {
  background: #fff1f2;
  color: #b42318;
}

.feedback.success {
  background: #ecfdf3;
  color: #027a48;
}

.panel-head,
.modal-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}

.table-panel {
  padding: 20px;
}

.table-wrap {
  margin-top: 16px;
  overflow: auto;
}

table {
  width: 100%;
  border-collapse: collapse;
}

th,
td {
  padding: 14px 12px;
  border-bottom: 1px solid #e5edf3;
  text-align: left;
  vertical-align: top;
}

th {
  font-size: 13px;
  color: #496176;
  background: #f7fbfe;
  position: sticky;
  top: 0;
}

tr.selected {
  background: #effcf6;
}

.actions-col,
.row-actions {
  white-space: nowrap;
}

.empty-row {
  text-align: center;
  color: #60788c;
}

.primary-btn,
.ghost-btn,
.table-btn,
.icon-close {
  border: 0;
  border-radius: 12px;
  padding: 10px 14px;
  font: inherit;
  cursor: pointer;
}

.primary-btn {
  background: #0f766e;
  color: #fff;
}

.ghost-btn,
.table-btn,
.icon-close {
  background: #e9f3fa;
  color: #123046;
}

.table-btn.accent {
  background: #dff7ea;
  color: #0f766e;
}

.table-btn.danger {
  background: #fff1f2;
  color: #b42318;
}

.modal-backdrop {
  position: fixed;
  inset: 0;
  background: rgba(10, 28, 40, 0.42);
  display: grid;
  place-items: center;
  padding: 20px;
  z-index: 30;
}

.modal {
  width: min(920px, 100%);
  max-height: 90vh;
  overflow: auto;
  padding: 22px;
}

.form-grid {
  margin-top: 18px;
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 14px;
}

.modal-actions {
  margin-top: 4px;
}

@media (max-width: 1100px) {
  .filters,
  .stats {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}

@media (max-width: 720px) {
  .hero {
    flex-direction: column;
  }

  .filters,
  .stats,
  .form-grid {
    grid-template-columns: 1fr;
  }
}
</style>
