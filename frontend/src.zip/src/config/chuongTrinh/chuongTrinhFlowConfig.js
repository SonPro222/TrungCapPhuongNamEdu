export const CHUONG_TRINH_FLOW_STEPS = [
    { key: 'nganh', label: 'Ngành', routeName: 'chuong-trinh-nganh' },
    { key: 'trinh-do-dao-tao', label: 'Trình độ đào tạo', routeName: 'chuong-trinh-trinh-do-dao-tao', needs: 'nganhId' },
    { key: 'loai-chuong-trinh', label: 'Loại chương trình', routeName: 'chuong-trinh-loai-chuong-trinh', needs: 'trinhDoId' },
    { key: 'chuong-trinh', label: 'Chương trình đào tạo', routeName: 'chuong-trinh-chuong-trinh', needs: 'loaiChuongTrinhId' },
    { key: 'chuong-trinh-version', label: 'Phiên bản chương trình', routeName: 'chuong-trinh-chuong-trinh-version', needs: 'programId' },
    { key: 'syllabus-chuong-trinh', label: 'Đề cương chương trình', routeName: 'chuong-trinh-syllabus-chuong-trinh', needs: 'versionId' },
    { key: 'muc-tieu-chuong-trinh', label: 'Mục tiêu chương trình', routeName: 'chuong-trinh-muc-tieu-chuong-trinh', needs: 'versionId' },
    { key: 'nang-luc-dau-ra', label: 'Năng lực đầu ra', routeName: 'chuong-trinh-nang-luc-dau-ra', needs: 'versionId' },
    { key: 'vi-tri-viec-lam', label: 'Vị trí việc làm', routeName: 'chuong-trinh-vi-tri-viec-lam', needs: 'versionId' },
    { key: 'khung-ky', label: 'Khung kỳ', routeName: 'chuong-trinh-khung-ky', needs: 'loaiChuongTrinhId' },
    { key: 'nhom-kien-thuc', label: 'Nhóm kiến thức', routeName: 'chuong-trinh-nhom-kien-thuc', needs: 'versionId' },
    { key: 'mon-hoc', label: 'Môn học', routeName: 'chuong-trinh-mon-hoc' },
    { key: 'chuong-trinh-mon', label: 'Môn trong chương trình', routeName: 'chuong-trinh-chuong-trinh-mon', needs: 'versionId' },
    { key: 'mon-tien-quyet', label: 'Môn tiên quyết', routeName: 'chuong-trinh-mon-tien-quyet', needs: 'courseId' },
    { key: 'nhom-tu-chon', label: 'Nhóm tự chọn', routeName: 'chuong-trinh-nhom-tu-chon', needs: 'versionId' },
    { key: 'syllabus-mon-hoc', label: 'Syllabus môn học', routeName: 'chuong-trinh-syllabus-mon-hoc', needs: 'courseId' },
    { key: 'syllabus-chuong-bai', label: 'Chương/bài syllabus', routeName: 'chuong-trinh-syllabus-chuong-bai', needs: 'syllabusMonId' },
    { key: 'syllabus-tai-lieu', label: 'Tài liệu môn học', routeName: 'chuong-trinh-syllabus-tai-lieu', needs: 'syllabusMonId' },
    { key: 'dieu-kien-mon-hoc', label: 'Điều kiện môn', routeName: 'chuong-trinh-dieu-kien-mon-hoc', needs: 'courseId' },
    { key: 'quy-doi-diem', label: 'Quy đổi điểm', routeName: 'chuong-trinh-quy-doi-diem', needs: 'courseId' },
    { key: 'dieu-kien-tot-nghiep', label: 'Điều kiện tốt nghiệp', routeName: 'chuong-trinh-dieu-kien-tot-nghiep', needs: 'versionId' },
];

export const CHUONG_TRINH_ROUTE_CONTEXT_KEYS = [
    'nganhId',
    'trinhDoId',
    'loaiChuongTrinhId',
    'khungKyId',
    'programId',
    'versionId',
    'courseId',
    'syllabusMonId',
];

export function pickRouteContext(query = {}) {
    return Object.fromEntries(
        CHUONG_TRINH_ROUTE_CONTEXT_KEYS
            .map((key) => [key, query[key]])
            .filter(([, value]) => value !== undefined && value !== null && value !== '')
    );
}
