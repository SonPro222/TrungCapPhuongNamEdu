export const daoTaoModuleConfig = {
    title: 'Đào tạo',
    description: 'Luồng nghiệp vụ đi từ ngoài vào trong: ngành, trình độ, loại chương trình và khung kỳ trước khi đi sâu sang module chương trình.',
    basePath: 'dao-tao',
    navGroups: [
        {
            title: 'Luồng đầu vào',
            items: [
                { label: 'Ngành đào tạo', to: '/dao-tao/nganh', path: 'dao-tao/nganh' },
                { label: 'Trình độ đào tạo', to: '/dao-tao/trinh-do-dao-tao', path: 'dao-tao/trinh-do-dao-tao' },
                { label: 'Loại chương trình', to: '/dao-tao/loai-chuong-trinh', path: 'dao-tao/loai-chuong-trinh' },
                { label: 'Khung kỳ', to: '/dao-tao/khung-ky', path: 'dao-tao/khung-ky' },
            ],
        },
    ],
};
