<template>
  <div class="xem-tep-syllabus-page">
    <div class="page-head">
      <div>
        <h2>Tệp đã lưu của tài liệu syllabus môn</h2>
        <p>Chọn một dòng tài liệu để xem nội dung tệp ngay trong trang này.</p>
      </div>

      <div class="head-actions">
        <button type="button" class="btn" @click="quayLaiSyllabus">
          ← Quay lại syllabus môn
        </button>
        <button type="button" class="btn primary" :disabled="loading" @click="taiDuLieu">
          Tải lại
        </button>
      </div>
    </div>

    <div v-if="thongBao" :class="['notice', loaiThongBao]">
      {{ thongBao }}
    </div>

    <section class="info-box">
      <div>
        <span>Môn trong chương trình</span>
        <b>{{ tenMonTrongChuongTrinh }}</b>
      </div>
      <div>
        <span>Syllabus môn</span>
        <b>{{ tenSyllabusMon }}</b>
      </div>
      <div>
        <span>Số tệp đã lưu</span>
        <b>{{ danhSachTep.length }}</b>
      </div>
    </section>

    <section class="file-view-layout">
      <section class="table-card">
        <div class="table-title">
          Danh sách tệp tài liệu đã lưu
        </div>

        <div class="table-wrap">
          <table>
            <thead>
            <tr>
              <th>Mã tài liệu</th>
              <th>Tên tài liệu</th>
              <th>Loại</th>
              <th>Tác giả</th>
              <th>Năm</th>
              <th class="col-action">Xem</th>
            </tr>
            </thead>

            <tbody>
            <tr v-if="loading">
              <td colspan="6" class="empty-cell">Đang tải dữ liệu...</td>
            </tr>

            <tr v-else-if="!danhSachTep.length">
              <td colspan="6" class="empty-cell">
                Chưa có tệp nào được lưu cho syllabus môn này.
              </td>
            </tr>

            <tr
                v-for="item in danhSachTep"
                :key="item.id"
                :class="{ selected: tepDangXem?.id === item.id }"
            >
              <td>{{ item.ma || '-' }}</td>
              <td>{{ item.ten || '-' }}</td>
              <td>{{ item.loai || '-' }}</td>
              <td>{{ item.tacGia || '-' }}</td>
              <td>{{ item.namXuatBan || '-' }}</td>
              <td class="col-action">
                <button
                    type="button"
                    class="btn tiny view-file-btn"
                    :disabled="!item.duongDan || loadingTep"
                    @click="xemTepTrongTrang(item)"
                >
                  Xem trong trang
                </button>
              </td>
            </tr>
            </tbody>
          </table>
        </div>
      </section>

      <section class="preview-card">
        <div class="preview-head">
          <div>
            <h3>{{ tepDangXem?.ten || 'Chưa chọn tệp' }}</h3>
            <p v-if="tepDangXem">
              {{ tepDangXem.ma || '-' }} | {{ tepDangXem.loai || '-' }} | {{ tepDangXem.tacGia || '-' }}
            </p>
            <p v-else>Chọn một tệp ở bảng bên trái để xem nội dung.</p>
          </div>

          <button
              v-if="tepDangXem?.duongDan"
              type="button"
              class="btn tiny"
              @click="moTepBangTrinhDuyet"
          >
            Mở tab riêng
          </button>
        </div>

        <div v-if="loadingTep" class="preview-loading">
          Đang tải tệp...
        </div>

        <div v-else-if="!tepDangXem" class="preview-empty">
          Chưa chọn tệp để xem.
        </div>

        <div v-else-if="previewError" class="preview-error">
          {{ previewError }}
        </div>

        <div v-else class="preview-body">
          <img
              v-if="loaiPreview === 'image'"
              :src="previewUrl"
              class="preview-image"
              alt="Tệp hình ảnh"
          />

          <video
              v-else-if="loaiPreview === 'video'"
              :src="previewUrl"
              class="preview-video"
              controls
          />

          <audio
              v-else-if="loaiPreview === 'audio'"
              :src="previewUrl"
              class="preview-audio"
              controls
          />

          <iframe
              v-else-if="loaiPreview === 'pdf' || loaiPreview === 'text' || loaiPreview === 'other'"
              :src="previewUrl"
              class="preview-frame"
              title="Xem tệp syllabus"
          />

          <div v-else class="preview-empty">
            Loại tệp này trình duyệt không xem trực tiếp tốt. Bấm “Mở tab riêng” để kiểm tra tệp.
          </div>
        </div>
      </section>
    </section>
  </div>
</template>

<script setup>
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import apiClient from '@/core/api/apiClient'
import { ENV } from '@/core/config/env'
import { daoTaoXemChuongTrinhService } from '../services/daoTaoXemChuongTrinhService'
import { layThongBaoLoi } from '../utils/layThongBaoLoi'

const route = useRoute()
const router = useRouter()

const loading = ref(false)
const loadingTep = ref(false)
const thongBao = ref('')
const loaiThongBao = ref('success')

const syllabusMonHoc = ref(null)
const chuongTrinhMon = ref(null)
const danhSachTaiLieu = ref([])

const tepDangXem = ref(null)
const previewUrl = ref('')
const previewError = ref('')
const loaiPreview = ref('')

const syllabusMonId = computed(() => route.query.syllabusMonId || route.params.syllabusMonId || null)
const chuongTrinhMonId = computed(() => route.params.chuongTrinhMonId || route.query.chuongTrinhMonId || null)

const tenMonTrongChuongTrinh = computed(() => {
  const mon = chuongTrinhMon.value

  if (!mon) return chuongTrinhMonId.value || '-'

  return [
    mon.maMonTrongCt,
    mon.tenMon,
    mon.tenMonHoc
  ].filter(Boolean).join(' - ') || mon.id || '-'
})

const tenSyllabusMon = computed(() => {
  const syllabus = syllabusMonHoc.value

  if (!syllabus) return syllabusMonId.value || '-'

  return [
    syllabus.ma,
    syllabus.ten,
    syllabus.tenSyllabusMonHocGoc,
    syllabus.maSyllabusMonHocGoc,
    syllabus.mucTieu
  ].filter(Boolean)[0] || syllabus.id || '-'
})

const danhSachTep = computed(() => {
  return (danhSachTaiLieu.value || []).filter((item) => {
    return item?.duongDan !== null && item?.duongDan !== undefined && item?.duongDan !== ''
  })
})

function baoTin(message, type = 'success') {
  thongBao.value = message
  loaiThongBao.value = type

  setTimeout(() => {
    if (thongBao.value === message) thongBao.value = ''
  }, 5000)
}

function layDanhSach(result) {
  if (Array.isArray(result)) return result
  if (Array.isArray(result?.items)) return result.items
  if (Array.isArray(result?.content)) return result.content
  if (Array.isArray(result?.data)) return result.data
  if (Array.isArray(result?.data?.items)) return result.data.items
  if (Array.isArray(result?.data?.content)) return result.data.content
  return []
}

function layMotDong(result) {
  if (!result) return null
  if (result?.id) return result
  if (result?.data?.id) return result.data
  if (result?.data?.data?.id) return result.data.data
  return result?.data || result
}

function layBackendOrigin() {
  return String(ENV.API_BASE_URL || '')
      .replace(/\/api\/?$/, '')
      .replace(/\/$/, '')
}

function taoUrlDayDu(duongDan) {
  if (!duongDan) return ''

  const url = String(duongDan)

  if (url.startsWith('http://') || url.startsWith('https://')) return url

  if (url.startsWith('/api/')) {
    return `${layBackendOrigin()}${url}`
  }

  return url
}

function taoApiPathTuDuongDan(duongDan) {
  if (!duongDan) return ''

  const url = String(duongDan)

  if (url.startsWith('/api/')) {
    return url.replace(/^\/api/, '')
  }

  const apiBase = String(ENV.API_BASE_URL || '').replace(/\/$/, '')

  if (url.startsWith(apiBase)) {
    return url.slice(apiBase.length)
  }

  const origin = layBackendOrigin()
  const fullApiPrefix = `${origin}/api`

  if (url.startsWith(fullApiPrefix)) {
    return url.slice(fullApiPrefix.length)
  }

  return url
}

function layExtension(item) {
  const source = [
    item?.duongDan,
    item?.ten,
    item?.ma
  ].filter(Boolean).join(' ')

  const clean = String(source).split('?')[0].toLowerCase()
  const match = clean.match(/\.([a-z0-9]+)(?:$|[\/\s])/)

  return match?.[1] || ''
}

function xacDinhLoaiPreview(item, blob) {
  const contentType = String(blob?.type || '').toLowerCase()
  const extension = layExtension(item)

  if (contentType.startsWith('image/') || ['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp', 'svg'].includes(extension)) {
    return 'image'
  }

  if (contentType.startsWith('video/') || ['mp4', 'mov', 'avi', 'mkv', 'webm'].includes(extension)) {
    return 'video'
  }

  if (contentType.startsWith('audio/') || ['mp3', 'wav', 'm4a', 'ogg'].includes(extension)) {
    return 'audio'
  }

  if (contentType.includes('pdf') || extension === 'pdf') {
    return 'pdf'
  }

  if (contentType.startsWith('text/') || ['txt', 'csv'].includes(extension)) {
    return 'text'
  }

  if (['doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx'].includes(extension)) {
    return 'office'
  }

  return 'other'
}

function xoaPreviewUrlCu() {
  if (previewUrl.value && previewUrl.value.startsWith('blob:')) {
    URL.revokeObjectURL(previewUrl.value)
  }

  previewUrl.value = ''
}

async function xemTepTrongTrang(item) {
  if (!item?.duongDan) return

  loadingTep.value = true
  previewError.value = ''
  tepDangXem.value = item
  loaiPreview.value = ''
  xoaPreviewUrlCu()

  try {
    const apiPath = taoApiPathTuDuongDan(item.duongDan)

    const blob = await apiClient.get(apiPath, {
      responseType: 'blob'
    })

    loaiPreview.value = xacDinhLoaiPreview(item, blob)

    if (loaiPreview.value === 'office') {
      previewError.value = 'File Word/Excel/PowerPoint hiện chưa xem trực tiếp trong trình duyệt được. Bấm “Mở tab riêng” để mở hoặc tải tệp.'
      return
    }

    previewUrl.value = URL.createObjectURL(blob)
  } catch (error) {
    previewError.value = layThongBaoLoi(error, 'Không xem được tệp trong trang.')
  } finally {
    loadingTep.value = false
  }
}

function moTepBangTrinhDuyet() {
  if (!tepDangXem.value?.duongDan) return
  window.open(taoUrlDayDu(tepDangXem.value.duongDan), '_blank')
}

async function taiSyllabusMonHoc() {
  if (!syllabusMonId.value) {
    syllabusMonHoc.value = null
    return
  }

  const result = await daoTaoXemChuongTrinhService.syllabusMonHoc.getById(syllabusMonId.value)
  syllabusMonHoc.value = layMotDong(result)
}

async function taiChuongTrinhMon() {
  if (!chuongTrinhMonId.value) {
    chuongTrinhMon.value = null
    return
  }

  const result = await daoTaoXemChuongTrinhService.chuongTrinhMon.getById(chuongTrinhMonId.value)
  chuongTrinhMon.value = layMotDong(result)
}

async function taiTaiLieuSyllabus() {
  if (!syllabusMonId.value) {
    danhSachTaiLieu.value = []
    return
  }

  const result = await daoTaoXemChuongTrinhService.syllabusTaiLieu.getAll({
    syllabusMonId: syllabusMonId.value,
    size: 500
  })

  danhSachTaiLieu.value = layDanhSach(result)
}

async function taiDuLieu() {
  loading.value = true

  try {
    await Promise.all([
      taiSyllabusMonHoc(),
      taiChuongTrinhMon(),
      taiTaiLieuSyllabus()
    ])

    if (danhSachTep.value.length) {
      await xemTepTrongTrang(danhSachTep.value[0])
    }
  } catch (error) {
    baoTin(layThongBaoLoi(error, 'Không tải được danh sách tệp syllabus môn.'), 'error')
  } finally {
    loading.value = false
  }
}

function quayLaiSyllabus() {
  router.push({
    name: 'DaoTao.XemChuongTrinh.SyllabusApDung',
    params: {
      nganhId: route.params.nganhId,
      chuongTrinhId: route.params.chuongTrinhId,
      versionId: route.params.versionId,
      chuongTrinhMonId: route.params.chuongTrinhMonId
    },
    query: {
      syllabusMonId: syllabusMonId.value,
      khungKyId: route.query.khungKyId,
      nhomKienThucId: route.query.nhomKienThucId
    }
  })
}

onMounted(() => {
  taiDuLieu()
})

onBeforeUnmount(() => {
  xoaPreviewUrlCu()
})
</script>

<style scoped>
.xem-tep-syllabus-page {
  padding: 24px;
}

.page-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 16px;
}

.page-head h2 {
  margin: 0;
  font-size: 22px;
  color: #111827;
}

.page-head p {
  margin: 6px 0 0;
  color: #6b7280;
  font-size: 13px;
}

.head-actions {
  display: flex;
  gap: 8px;
}

.notice {
  margin-bottom: 12px;
  padding: 10px 12px;
  border: 1px solid #bbf7d0;
  border-radius: 6px;
  background: #f0fdf4;
  color: #166534;
  font-size: 13px;
}

.notice.error {
  border-color: #fecaca;
  background: #fef2f2;
  color: #b91c1c;
}

.info-box {
  display: grid;
  grid-template-columns: 1.4fr 1.4fr 0.5fr;
  gap: 10px;
  margin-bottom: 14px;
}

.info-box div {
  border: 1px solid #bfdbfe;
  border-radius: 6px;
  background: #eff6ff;
  padding: 10px;
}

.info-box span {
  display: block;
  color: #1d4ed8;
  font-size: 12px;
  margin-bottom: 4px;
}

.info-box b {
  color: #111827;
  font-size: 13px;
}

.file-view-layout {
  display: grid;
  grid-template-columns: 520px minmax(0, 1fr);
  gap: 14px;
  align-items: stretch;
}

.table-card,
.preview-card {
  border: 1px solid #d1d5db;
  border-radius: 6px;
  background: #ffffff;
  overflow: hidden;
}

.table-title {
  padding: 10px 12px;
  border-bottom: 1px solid #e5e7eb;
  background: #f9fafb;
  color: #111827;
  font-size: 14px;
  font-weight: 700;
}

.table-wrap {
  width: 100%;
  max-height: 650px;
  overflow: auto;
}

table {
  width: 100%;
  min-width: 700px;
  border-collapse: collapse;
  font-size: 12px;
}

th,
td {
  border-top: 1px solid #e5e7eb;
  padding: 7px 8px;
  text-align: left;
  vertical-align: top;
}

th {
  position: sticky;
  top: 0;
  z-index: 1;
  background: #f3f4f6;
  color: #374151;
  font-size: 11px;
  font-weight: 700;
}

tr.selected {
  background: #eff6ff;
}

.col-action {
  width: 96px;
  text-align: center;
  white-space: nowrap;
}

.empty-cell {
  text-align: center;
  color: #6b7280;
  padding: 20px;
}

.preview-card {
  min-height: 650px;
  display: flex;
  flex-direction: column;
}

.preview-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
  padding: 10px 12px;
  border-bottom: 1px solid #e5e7eb;
  background: #f9fafb;
}

.preview-head h3 {
  margin: 0;
  color: #111827;
  font-size: 15px;
}

.preview-head p {
  margin: 4px 0 0;
  color: #6b7280;
  font-size: 12px;
}

.preview-body {
  flex: 1;
  min-height: 0;
  background: #f8fafc;
}

.preview-frame {
  width: 100%;
  height: 650px;
  border: 0;
  background: #ffffff;
}

.preview-image {
  display: block;
  max-width: 100%;
  max-height: 650px;
  margin: 0 auto;
  object-fit: contain;
}

.preview-video {
  width: 100%;
  height: 650px;
  background: #000000;
}

.preview-audio {
  width: calc(100% - 24px);
  margin: 24px 12px;
}

.preview-loading,
.preview-empty,
.preview-error {
  padding: 24px;
  color: #6b7280;
  font-size: 13px;
  text-align: center;
}

.preview-error {
  color: #b91c1c;
}

.btn {
  min-height: 30px;
  border: 1px solid #cbd5e1;
  border-radius: 4px;
  background: #ffffff;
  color: #111827;
  padding: 5px 10px;
  font-size: 12px;
  cursor: pointer;
  white-space: nowrap;
}

.btn:hover {
  background: #f8fafc;
}

.btn:disabled {
  cursor: not-allowed;
  opacity: 0.65;
}

.btn.primary {
  border-color: #2563eb;
  background: #2563eb;
  color: #ffffff;
}

.btn.tiny {
  min-height: 24px;
  padding: 3px 8px;
  font-size: 11px;
}

.view-file-btn {
  white-space: nowrap;
}

@media (max-width: 1100px) {
  .file-view-layout {
    grid-template-columns: 1fr;
  }

  .preview-frame,
  .preview-video {
    height: 520px;
  }
}
</style>