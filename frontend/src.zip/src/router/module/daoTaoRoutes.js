import DaoTaoLayout from '@/components/daoTao/DaoTaoLayout.vue';
import DaoTaoCrudPage from '@/components/daoTao/DaoTaoCrudPage.vue';

const daoTaoChildren = [
    {
        path: '',
        redirect: '/dao-tao/nganh',
    },
    {
        path: 'nganh',
        name: 'dao-tao-nganh',
        component: DaoTaoCrudPage,
        meta: { pageKey: 'nganh' },
    },
    {
        path: 'trinh-do-dao-tao',
        name: 'dao-tao-trinh-do',
        component: DaoTaoCrudPage,
        meta: { pageKey: 'trinh-do-dao-tao' },
    },
    {
        path: 'loai-chuong-trinh',
        name: 'dao-tao-loai-chuong-trinh',
        component: DaoTaoCrudPage,
        meta: { pageKey: 'loai-chuong-trinh' },
    },
    {
        path: 'khung-ky',
        name: 'dao-tao-khung-ky',
        component: DaoTaoCrudPage,
        meta: { pageKey: 'khung-ky' },
    },
];

const daoTaoRoutes = [
    {
        path: '/dao-tao',
        component: DaoTaoLayout,
        children: daoTaoChildren,
    },
];

export default daoTaoRoutes;
